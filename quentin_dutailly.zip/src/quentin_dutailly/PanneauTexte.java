package quentin_dutailly;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PanneauTexte extends JPanel {
    private JTextArea textArea;
    private JButton clearButton, colorTextButton, backgroundButton;

    public PanneauTexte() {
        setLayout(new BorderLayout());

        // Zone de texte avec défilement
        textArea = new JTextArea();
        textArea.setBackground(Color.WHITE);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setForeground(Color.BLACK);  // Couleur du texte initiale

        // Ajout du JTextArea dans un JScrollPane
        JScrollPane scrollPane = new JScrollPane(textArea);
        add(scrollPane, BorderLayout.CENTER);

        // Panneau de contrôle pour les boutons
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new FlowLayout());

        // Bouton pour effacer le texte
        clearButton = new JButton("Effacer le texte");
        clearButton.addActionListener(e -> clearText());
        controlPanel.add(clearButton);

        // Bouton pour changer la couleur du texte
        colorTextButton = new JButton("Couleur du texte");
        colorTextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Color newColor = JColorChooser.showDialog(null, "Choisir une couleur pour le texte", textArea.getForeground());
                if (newColor != null) {
                    textArea.setForeground(newColor);
                }
            }
        });
        controlPanel.add(colorTextButton);

        // Bouton pour changer la couleur de fond
        backgroundButton = new JButton("Couleur du fond");
        backgroundButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Color newBackgroundColor = JColorChooser.showDialog(null, "Choisir une couleur pour le fond", textArea.getBackground());
                if (newBackgroundColor != null) {
                    textArea.setBackground(newBackgroundColor);
                }
            }
        });
        controlPanel.add(backgroundButton);

        // Ajouter le panneau de contrôle au bas du PanneauTexte
        add(controlPanel, BorderLayout.NORTH);
    }

    // Méthode pour effacer le texte
    public void clearText() {
        textArea.setText(""); // Vide le texte
    }
}
