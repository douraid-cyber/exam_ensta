package quentin_dutailly;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class NouvelleInterface extends JFrame {

    private JLabel labelSurprise;
    private JButton boutonSurprise;

    public NouvelleInterface() {
        setTitle("Super Interface Surprise Extrême !");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Création d'un panneau principal avec fond coloré
        JPanel panel = new JPanel();
        panel.setBackground(new Color(255, 255, 255));
        panel.setLayout(new BorderLayout());

        // Ajout d'un texte changeant de couleur et qui "clignote"
        labelSurprise = new JLabel("<html><div style='text-align: center; font-size: 30px;'>Prépare-toi... à la SURPRISE !</div></html>");
        labelSurprise.setFont(new Font("Comic Sans MS", Font.BOLD, 30));
        labelSurprise.setHorizontalAlignment(SwingConstants.CENTER);
        labelSurprise.setForeground(new Color(0, 0, 255));
        panel.add(labelSurprise, BorderLayout.CENTER);

        // Animation du texte
        new Timer(500, new ActionListener() {
            private boolean changeColor = true;
            public void actionPerformed(ActionEvent e) {
                labelSurprise.setForeground(changeColor ? new Color(255, 0, 0) : new Color(0, 0, 255));
                changeColor = !changeColor;
            }
        }).start();

        // Créer le bouton qui "s'échappe"
        boutonSurprise = new JButton("Clique si tu oses !");
        boutonSurprise.setFont(new Font("Arial", Font.BOLD, 20));
        boutonSurprise.setBackground(new Color(255, 255, 102));
        boutonSurprise.setForeground(Color.BLACK);
        boutonSurprise.setFocusPainted(false);
        boutonSurprise.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "🎉 Surprise 🎉\nTu viens de cliquer ! Mais regarde bien la suite...", 
                                              "Super surprise", JOptionPane.INFORMATION_MESSAGE);
                // Faites "s'échapper" le bouton après 1 seconde
                new Timer(1000, new ActionListener() {
                    private int deltaX = 10, deltaY = 10;
                    public void actionPerformed(ActionEvent e) {
                        Point currentLocation = boutonSurprise.getLocation();
                        boutonSurprise.setLocation(currentLocation.x + deltaX, currentLocation.y + deltaY);
                        deltaX = -deltaX; // Change direction
                        deltaY = -deltaY; // Change direction
                    }
                }).start();
            }
        });

        // Panneau avec le bouton qui peut être déplacé
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(255, 204, 204));
        buttonPanel.add(boutonSurprise);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        // Ajouter une forme géométrique (cercle, carré, triangle) en remplacement de l'avatar
        JPanel shapePanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Dessiner un cercle amusant
                g.setColor(new Color(255, 100, 100));
                g.fillOval(50, 50, 100, 100); // Cercle rouge

                // Dessiner un carré
                g.setColor(new Color(100, 255, 100));
                g.fillRect(200, 50, 100, 100); // Carré vert

                // Dessiner un triangle
                g.setColor(new Color(100, 100, 255));
                g.fillPolygon(new int[]{350, 400, 450}, new int[]{150, 100, 150}, 3); // Triangle bleu
            }
        };
        shapePanel.setPreferredSize(new Dimension(500, 200));
        panel.add(shapePanel, BorderLayout.NORTH);

        // Ajouter ce panneau principal
        add(panel);

        // Visibilité de la fenêtre
        setVisible(true);
    }

    public static void main(String[] args) {
        new NouvelleInterface();
    }
}
