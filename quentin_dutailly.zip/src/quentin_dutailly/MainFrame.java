package quentin_dutailly;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    public MainFrame() {
        setTitle("Application Java");
        setSize(1000, 800); // Agrandir la taille de la fenêtre
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);  // Utilisation de "null layout" pour positionnement manuel des composants

        // Création des panneaux
        PanneauBoutons panneauBoutons = new PanneauBoutons();
        DrawingPanel panneauDessin = new DrawingPanel();
        PanneauTexte panneauTexte = new PanneauTexte();
        Panneau100Boutons panneau100Boutons = new Panneau100Boutons();
        
        // Panneaux vides avec couleur différente
        JPanel panneauHaut = new JPanel();
        panneauHaut.setBackground(Color.CYAN);
        JPanel panneauDroite = new JPanel();
        panneauDroite.setBackground(Color.ORANGE);
        
        // Positionnement des panneaux manuellement avec taille augmentée
        panneauHaut.setBounds(0, 0, 1000, 60);     // Zone Haut (plus grande)
        panneauBoutons.setBounds(0, 60, 250, 700); // Zone Gauche (plus large et plus haut)
        panneauDessin.setBounds(250, 60, 700, 500); // Zone Centre (plus grande)
        panneauTexte.setBounds(250, 560, 700, 200); // Zone Bas (plus grande)
        panneauDroite.setBounds(900, 60, 100, 700); // Zone Droite (plus haute)

        // Création des onglets
        JTabbedPane tabbedPane = new JTabbedPane();
        JPanel accueilPanel = new JPanel();
        accueilPanel.setLayout(null); // Nécessaire pour les positions manuelles à l'intérieur de l'onglet
        
        // Ajout des panneaux à l'accueil
        accueilPanel.add(panneauHaut);
        accueilPanel.add(panneauBoutons);
        accueilPanel.add(panneauDessin);
        accueilPanel.add(panneauTexte);
        accueilPanel.add(panneauDroite);

        // Ajout des panneaux aux onglets
        tabbedPane.addTab("Accueil", accueilPanel);
        tabbedPane.addTab("100 Boutons", panneau100Boutons); // Onglet 100 Boutons

        // Ajout des onglets à la fenêtre principale
        setContentPane(tabbedPane);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}
