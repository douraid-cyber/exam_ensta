package quentin_dutailly;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PanneauBoutons extends JPanel {
    private JButton bouton1, bouton2, bouton3;
    private Point clickPoint = null;

    public PanneauBoutons() {
        setLayout(null); // Position libre
        setBackground(Color.LIGHT_GRAY);
        
        // Création des boutons
        bouton1 = createButton("Bouton 1", 20, 30);
        bouton2 = createButton("Bouton 2", 20, 80);
        bouton3 = createButton("Bouton 3", 20, 130);

        // Action de Bouton 1
        bouton1.addActionListener(e -> new FenetreInfos().setVisible(true));
        
        // Action de Bouton 2
        bouton2.addActionListener(e -> {
            FenetreCouleur fenetre = new FenetreCouleur();
            fenetre.setVisible(true);
        });

        add(bouton1);
        add(bouton2);
        add(bouton3);
    }

    // Méthode pour créer un bouton
    private JButton createButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 100, 30);
        
        // Déplacement des boutons
        button.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) { clickPoint = e.getPoint(); }
        });
        button.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) {
                int newX = button.getX() + e.getX() - clickPoint.x;
                int newY = button.getY() + e.getY() - clickPoint.y;
                button.setLocation(newX, newY);
            }
        });
        return button;
    }
}
