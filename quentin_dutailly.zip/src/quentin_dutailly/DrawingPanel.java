package quentin_dutailly;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.BasicStroke;
import java.util.ArrayList;
import java.util.List;

public class DrawingPanel extends JPanel {
    private int lastX, lastY;
    private List<Shape> shapes = new ArrayList<>();
    private Color currentColor = Color.BLACK;
    private int currentThickness = 2;
    private boolean dashed = false;

    public DrawingPanel() {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());
        JPanel controlPanel = new JPanel();

        // Sélecteur de couleur
        String[] colorNames = {"Noir", "Rouge", "Vert", "Bleu", "Jaune", "Gris"};
        Color[] colorValues = {Color.BLACK, Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.GRAY};
        JComboBox<String> colorChooser = new JComboBox<>(colorNames);
        colorChooser.addActionListener(e -> currentColor = colorValues[colorChooser.getSelectedIndex()]);

        // Sélecteur d'épaisseur
        JSlider thicknessSlider = new JSlider(1, 10, 2);
        thicknessSlider.setMajorTickSpacing(1);
        thicknessSlider.setPaintTicks(true);
        thicknessSlider.setPaintLabels(true);
        thicknessSlider.addChangeListener(e -> currentThickness = thicknessSlider.getValue());

        // Sélecteur de style de trait
        JComboBox<String> styleChooser = new JComboBox<>(new String[]{"Continu", "Pointillé"});
        styleChooser.addActionListener(e -> dashed = styleChooser.getSelectedItem().equals("Pointillé"));

        // Bouton pour effacer
        JButton clearButton = new JButton("Effacer");
        clearButton.addActionListener(e -> {
            shapes.clear();  // Efface la liste des formes
            repaint();       // Redessine le panneau sans formes
        });

        controlPanel.add(new JLabel("Couleur :"));
        controlPanel.add(colorChooser);
        controlPanel.add(new JLabel("Épaisseur :"));
        controlPanel.add(thicknessSlider);
        controlPanel.add(new JLabel("Style :"));
        controlPanel.add(styleChooser);
        controlPanel.add(clearButton);  // Ajouter le bouton "Effacer"
        add(controlPanel, BorderLayout.NORTH);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                lastX = e.getX();
                lastY = e.getY();
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                shapes.add(new Shape(lastX, lastY, x, y, currentColor, currentThickness, dashed));
                lastX = x;
                lastY = y;
                repaint();
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        for (Shape shape : shapes) {
            g2d.setColor(shape.color);
            if (shape.dashed) {
                float[] dashPattern = {5, 5};
                g2d.setStroke(new BasicStroke(shape.thickness, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10, dashPattern, 0));
            } else {
                g2d.setStroke(new BasicStroke(shape.thickness));
            }
            g2d.drawLine(shape.x1, shape.y1, shape.x2, shape.y2);
        }
    }

    private static class Shape {
        int x1, y1, x2, y2;
        Color color;
        int thickness;
        boolean dashed;

        public Shape(int x1, int y1, int x2, int y2, Color color, int thickness, boolean dashed) {
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
            this.color = color;
            this.thickness = thickness;
            this.dashed = dashed;
        }
    }
}
