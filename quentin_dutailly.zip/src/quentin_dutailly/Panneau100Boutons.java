package quentin_dutailly;

import javax.swing.*;
import java.awt.*;

public class Panneau100Boutons extends JPanel {
    public Panneau100Boutons() {
        setLayout(new GridLayout(10, 10));
        
        for (int i = 1; i <= 100; i++) {
            JButton button = new JButton("Btn " + i);
            if (i == 22) {
                button.addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseEntered(java.awt.event.MouseEvent evt) { button.setBackground(Color.RED); }
                    public void mouseExited(java.awt.event.MouseEvent evt) { button.setBackground(null); }
                });
                button.addActionListener(e -> new NouvelleInterface().setVisible(true));
            }
            add(button);
        }
    }
}
