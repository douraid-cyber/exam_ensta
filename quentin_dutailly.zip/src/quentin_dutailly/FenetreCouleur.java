package quentin_dutailly;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;

public class FenetreCouleur extends JFrame {
    private JButton fermerButton;
    private JSlider slider;
    private JCheckBox checkBoxR, checkBoxG, checkBoxB, checkBoxAlpha;
    private JPanel colorPanel;
    private Color selectedColor = Color.WHITE;

    public FenetreCouleur() {
        setTitle("Fenêtre Circulaire");
        setSize(300, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);  // Centrer la fenêtre
        setLayout(null);
        setUndecorated(true); // Pour supprimer les bords de la fenêtre, la rendant circulaire
        setShape(new Ellipse2D.Double(0, 0, getWidth(), getHeight())); // Définir une forme circulaire

        // Panel pour afficher la couleur modifiable
        colorPanel = new JPanel();
        colorPanel.setBounds(50, 50, 200, 200);
        colorPanel.setBackground(selectedColor);
        add(colorPanel);

        // Slider pour modifier la couleur (luminosité ou teinte)
        slider = new JSlider(0, 255, 255);
        slider.setBounds(50, 270, 200, 30);
        slider.addChangeListener(e -> updateColor());
        add(slider);

        // Checkboxes pour chaque composant de couleur
        checkBoxR = new JCheckBox("Rouge");
        checkBoxR.setBounds(50, 310, 100, 30);
        checkBoxR.setSelected(true);  // Par défaut, R est activé
        add(checkBoxR);

        checkBoxG = new JCheckBox("Vert");
        checkBoxG.setBounds(150, 310, 100, 30);
        checkBoxG.setSelected(true);  // Par défaut, G est activé
        add(checkBoxG);

        checkBoxB = new JCheckBox("Bleu");
        checkBoxB.setBounds(50, 340, 100, 30);
        checkBoxB.setSelected(true);  // Par défaut, B est activé
        add(checkBoxB);

        checkBoxAlpha = new JCheckBox("Alpha");
        checkBoxAlpha.setBounds(150, 340, 100, 30);
        checkBoxAlpha.setSelected(true);  // Par défaut, Alpha est activé
        add(checkBoxAlpha);

        // Bouton de fermeture
        fermerButton = new JButton("Fermer");
        fermerButton.setBounds(100, 370, 100, 30);
        fermerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();  // Fermer la fenêtre
            }
        });
        add(fermerButton);
    }

    private void updateColor() {
        // Récupérer les valeurs RGB du slider et des checkboxes
        int red = checkBoxR.isSelected() ? slider.getValue() : 0;
        int green = checkBoxG.isSelected() ? slider.getValue() : 0;
        int blue = checkBoxB.isSelected() ? slider.getValue() : 0;
        int alpha = checkBoxAlpha.isSelected() ? slider.getValue() : 255;

        // Appliquer la couleur à la fenêtre
        selectedColor = new Color(red, green, blue, alpha);
        colorPanel.setBackground(selectedColor);
    }
}
