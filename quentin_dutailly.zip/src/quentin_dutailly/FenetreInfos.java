package quentin_dutailly;

import javax.swing.*;
import java.awt.*;

public class FenetreInfos extends JFrame {
    public FenetreInfos() {
        setTitle("Saisie d'informations");
        setSize(300, 200);
        setLayout(new GridLayout(5, 2));

        add(new JLabel("Nom:"));
        add(new JTextField());
        add(new JLabel("Prénom:"));
        add(new JTextField());
        add(new JLabel("Âge:"));
        add(new JTextField());
        add(new JLabel("École:"));
        add(new JTextField());
        
        JButton okButton = new JButton("OK");
        okButton.addActionListener(e -> dispose());
        add(okButton);
    }
}
