import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;






// Classe principale qui créer les onglets et les panels
public class Classe1 extends JFrame {
    public Classe1() {
    	// Paramètres de base
        setTitle("BE ETIENNE HORNER");
        setSize(800, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        createTabbedPane();

        setVisible(true);
    }
    
    private void createTabbedPane() {
        JTabbedPane tabbedPane = new JTabbedPane();
        
        // Pour le premier onglet avec les 5 zones
        JPanel mPanel = new JPanel(new BorderLayout());
        mPanel.add(new TPanel(), BorderLayout.NORTH);
        mPanel.add(new BPanel(), BorderLayout.SOUTH);
        mPanel.add(new DragBoutonPanel(), BorderLayout.WEST);
        mPanel.add(new TextPanel(), BorderLayout.EAST);
        mPanel.add(new DessinPanel(), BorderLayout.CENTER);
        
        // Onglet avec les 100 boutons
        JPanel centBoutonPanel = new CentBoutonPanel(this);
        
        tabbedPane.addTab("Premier Onglet", mPanel);
        tabbedPane.addTab("Deuxième Onglet", centBoutonPanel);
        
        setContentPane(tabbedPane);
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Classe1());
    }
}



// On crée une classe pour chaque panel afin de rendre le code lisible
// Et de distinguer les questions du sujet
// Chaque classes est une sous-classe de JPanel 
// (Idée de ChatGPT pour rendre le code lisible)
// J'ai choisi de tout laissé dans le même fichier pour faciliter la correction
// Mais sinon j'aurai fait 1 fichier par classe






/* 
 * 
 * 
 * 
 * On commence par les deux panels inutiles en haut et en bas
 * 
 * 
 * 
 * 
 * */

// Panel du Haut
class TPanel extends JPanel {
    public TPanel() {
        setBackground(Color.LIGHT_GRAY);
    }
}

// Panel du Bad
class BPanel extends JPanel {
    public BPanel() {
        setBackground(Color.DARK_GRAY);
    }
}



/* 
 * 
 * 
 * 
 * On continue avec le panel à gauche, avec les trois boutons déplaçables
 * 
 * 
 * 
 * 
 * */



class DragBoutonPanel extends JPanel {
    public DragBoutonPanel() {
        setLayout(null); // Positionnement de base 
        setPreferredSize(new Dimension(150, 600));
        setBackground(Color.PINK);
        
        // Création des 3 boutons pour la suite
        JButton bouton1 = new JButton("Bouton 1");
        JButton bouton2 = new JButton("Bouton 2");
        JButton bouton3 = new JButton("Bouton 3");
        
        // Positionnement sur la même colone
        bouton1.setBounds(20, 50, 100, 30);
        bouton2.setBounds(20, 100, 100, 30);
        bouton3.setBounds(20, 150, 100, 30);
        
        // Ajout au panel
        add(bouton1);
        add(bouton2);
        add(bouton3);
        
        // Ajout de la possibilité de déplacement, implémenté dans la méthode de classe addDragFeature
        addDragFeature(bouton1);
        addDragFeature(bouton2);
        addDragFeature(bouton3);
        
        // Actions sur les boutons pour afficher les fenêtres personnalisées
        bouton1.addActionListener(e -> new Bouton1Diagog(SwingUtilities.getWindowAncestor(this)));
        bouton2.addActionListener(e -> new CircularDialog(SwingUtilities.getWindowAncestor(this)));
        bouton3.addActionListener(e -> new PolygonalDialog(SwingUtilities.getWindowAncestor(this)));
    }
    
    
    // Méthode de déplacement des boutons avec les listener
    private void addDragFeature(JButton button) {
        button.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                button.setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
            }
        });
        button.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) {
                Point newLocation = SwingUtilities.convertPoint(button, e.getPoint(), DragBoutonPanel.this);
                int x = newLocation.x;
                int y = newLocation.y;
                
                // Limites pour rester dans l'appli
                if (x < 0) x = 0;
                if (y < 0) y = 0;
                if (x > getWidth() - button.getWidth()) x = getWidth() - button.getWidth();
                if (y > getHeight() - button.getHeight()) y = getHeight() - button.getHeight();
                button.setLocation(x, y);
            }
        });
        
        button.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                button.setCursor(Cursor.getDefaultCursor());
            }
        });
    }
}



/*
 * 
 * 
 * Implémentation des trois boutons (partie 2), on utilise JDialog.
 * 
 */



// Bouton 1, fenetre rectangulaire avec bords arrondis, hérite de JDialog car on ou
class Bouton1Diagog extends JDialog {
	public Bouton1Diagog(Window parent) {
		// SuperInit de JDialog, MODAL pour que l'utilisateur soit oblige de ferme la fenetre avant la suite
		super(parent, "Informations", ModalityType.APPLICATION_MODAL);
		setUndecorated(true); // Pour bords rond
		setSize(400, 300);
		setLocationRelativeTo(parent); // Centrage
	    setLayout(new BorderLayout());
	    setShape(new RoundRectangle2D.Double(0, 0, 400, 300, 30, 30));
	     
	    // Ajout des panels pour rentrer les information (De base mes infos)
	    JPanel inputPanel = new JPanel(new GridLayout(5, 2, 5, 5));
	    inputPanel.add(new JLabel("Nom:"));
	    JTextField nomField = new JTextField("Horner");
	    inputPanel.add(nomField);
	     
	    inputPanel.add(new JLabel("Prénom:"));
	    JTextField prenomField = new JTextField("Etienne");
	    inputPanel.add(prenomField);
	     
	    inputPanel.add(new JLabel("Age:"));
	    JTextField ageField = new JTextField("22");
	    inputPanel.add(ageField);
	     
	    inputPanel.add(new JLabel("École:"));
	    JTextField ecoleField = new JTextField("Ensta");
	    inputPanel.add(ecoleField);
	     
	    JButton okButton = new JButton("OK");
	    inputPanel.add(okButton);
	    JLabel infoLabel = new JLabel("");
	    inputPanel.add(infoLabel);
	     
	    // Bouton pour fermer
	    JPanel closePanel = new JPanel();
	    JButton closeButton = new JButton("Fermer");
	    closePanel.add(closeButton);
	     
	    // Affichage des infos à la fin
	    okButton.addActionListener(e -> {
	        String info = "[" + nomField.getText() + ", " + prenomField.getText() + ", " +
	                       ageField.getText() + ", " + ecoleField.getText() + "]";
	        infoLabel.setText(info);
	    });
	    closeButton.addActionListener(e -> dispose());
	     
	    add(inputPanel, BorderLayout.CENTER);
	    add(closePanel, BorderLayout.SOUTH);
	     
	    setVisible(true);
	 }
}

// Bouton 2, le bouton en forme de cercle meme principe que bouton 1
class CircularDialog extends JDialog {
 public CircularDialog(Window parent) {
     super(parent, "Couleur", ModalityType.APPLICATION_MODAL);
     setUndecorated(true);
     int diameter = 500;
     setSize(diameter, diameter);
     setLocationRelativeTo(parent);
     setLayout(new BorderLayout());
     setShape(new Ellipse2D.Double(0, 0, diameter, diameter));
     
     // On met un slider
     JPanel centerPanel = new JPanel(new BorderLayout());
     JSlider slider = new JSlider(0, 255, 128);
     centerPanel.add(slider, BorderLayout.CENTER);
     
     // Les panels pour le choix des couleurs
     JPanel checkPanel = new JPanel();
     JCheckBox redCheck = new JCheckBox("R");
     JCheckBox greenCheck = new JCheckBox("G");
     JCheckBox blueCheck = new JCheckBox("B");
     JCheckBox alphaCheck = new JCheckBox("Alpha");
     checkPanel.add(redCheck);
     checkPanel.add(greenCheck);
     checkPanel.add(blueCheck);
     checkPanel.add(alphaCheck);
     
     // Le panel pour fermer la fenêtre
     JPanel closePanel = new JPanel();
     JButton closeButton = new JButton("Fermer");
     closePanel.add(closeButton);
     
     Color initialColor = new Color(128, 122, 128, 255);
     getContentPane().setBackground(initialColor);
     
     // Pour le changement de couleur
     slider.addChangeListener(e -> {
         int value = slider.getValue();
         System.out.println(value);

         int r = redCheck.isSelected() ? value : initialColor.getRed();
         int g = greenCheck.isSelected() ? value : initialColor.getGreen();
         int b = blueCheck.isSelected() ? value : initialColor.getBlue();
         int a = alphaCheck.isSelected() ? value : initialColor.getAlpha();
         Color newColor = new Color(r, g, b, a);

         
         System.out.println(newColor);
         
         // Ca ne marche pas ici
         getContentPane().setBackground(newColor);
         getContentPane().repaint();
     });
     closeButton.addActionListener(e -> dispose());
     
     add(checkPanel, BorderLayout.NORTH);
     add(centerPanel, BorderLayout.CENTER);
     add(closePanel, BorderLayout.SOUTH);
     
     setVisible(true);
 }
}

class PolygonalDialog extends JDialog {
    public PolygonalDialog(Window parent) {
        super(parent, "Fenêtre Polygone", ModalityType.APPLICATION_MODAL);
        setUndecorated(true);
        setSize(400, 400);
        setLocationRelativeTo(parent);
        int squareSize = 120;
        int squareX = (getWidth() - squareSize) / 2;
        int squareY = (getHeight() - squareSize) / 2;
        
        // Panneau personnalisé pour dessiner la forme et les boutons
        JPanel polygonPanel = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Couleur de fond
                g2d.setColor(Color.DARK_GRAY);
                
                // carré central
                int squareSize = 120;
                int squareX = (getWidth() - squareSize) / 2;
                int squareY = (getHeight() - squareSize) / 2;
                g2d.fill(new Rectangle2D.Double(squareX, squareY, squareSize, squareSize));
                
                // iner les cercles
                int circleSize = 100;
                int[][] circlePositions = {
                    {squareX - circleSize / 2, squareY + squareSize - circleSize / 2}, // Bas
                    {squareX + squareSize - circleSize / 2, squareY - circleSize / 2}, // Haut droit
                    {squareX + squareSize, squareY - circleSize }  // Haut gauche
                };
                
                for (int[] pos : circlePositions) {
                    g2d.fill(new Ellipse2D.Double(pos[0], pos[1], circleSize, circleSize));
                }
            }
        };
        polygonPanel.setLayout(null);

        // Ajout des boutons X, Y, O qui changent de couleur au survol
        JButton buttonX = createHoverButton("X");
        buttonX.setBounds(120, 220, 30, 30);

        JButton buttonY = createHoverButton("Y");
        buttonY.setBounds(280, 70, 30, 30);

        JButton buttonO = createHoverButton("O");
        buttonO.setBounds(170, 150, 30, 30);

        // Bouton central : Une simple étoile jaune
        JButton centerButton = new JButton("★") {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Dessiner une étoile jaune sur toute la surface du bouton
                g2d.setColor(Color.YELLOW);
                g2d.fillOval(0, 0, getWidth(), getHeight());

                //  étoile noire au centre
                g2d.setColor(Color.BLACK);
                Font font = new Font("Arial", Font.BOLD, 60);
                g2d.setFont(font);
                FontMetrics fm = g2d.getFontMetrics();
                int x = (getWidth() - fm.stringWidth("★")) / 2;
                int y = (getHeight() + fm.getAscent()) / 2 - 5;
                g2d.drawString("★", x, y);
            }
        };

        centerButton.setBounds(140, 140, 80, 80);
        centerButton.setFocusPainted(false);
        centerButton.setContentAreaFilled(false);
        centerButton.setBorderPainted(false);
        centerButton.addActionListener(e -> dispose());


        // Ajouter les composants au panneau
        polygonPanel.add(buttonX);
        polygonPanel.add(buttonY);
        polygonPanel.add(buttonO);
        polygonPanel.add(centerButton);

        add(polygonPanel);
        setVisible(true);
    }

    // Création d'un bouton qui change de couleur au survol
    private JButton createHoverButton(String text) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);
        button.setBackground(Color.LIGHT_GRAY);
        button.setForeground(Color.BLACK);
        button.setBorder(BorderFactory.createRaisedBevelBorder());

        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(Color.YELLOW);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(Color.LIGHT_GRAY);
            }
        });

        return button;
    }
}




/* 
 * 
 * 
 * 
 * 
 * 
 * 
 * Ensuite le panel à droite, celui où l'on fait l'éditeur de texte
 * 
 * 
 * 
 * 
 * 
 * */


class TextPanel extends JPanel {
    // Zone de texte
    private JTextArea textArea;

    public TextPanel() {
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(200, 600));
        setBackground(Color.LIGHT_GRAY);

        textArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(textArea);

        // Options de modifs
        JPanel optionsPanel = new JPanel(new GridLayout(2, 2, 5, 5)); // Meilleur alignement

        // Pour le fond
        String[] bgColors = {"Blanc", "Jaune", "Rouge"};
        JComboBox<String> bgBox = new JComboBox<>(bgColors);

        // Pour le texte
        String[] textColors = {"Noir", "Rouge", "Vert"};
        JComboBox<String> textBox = new JComboBox<>(textColors);

        optionsPanel.add(new JLabel("Fond:"));
        optionsPanel.add(bgBox);
        optionsPanel.add(new JLabel("Texte:"));
        optionsPanel.add(textBox);

        add(optionsPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        // Modification de couleur fond
        bgBox.addActionListener(e -> {
            String selected = (String) bgBox.getSelectedItem();
            switch (selected) {
                case "Jaune":
                    textArea.setBackground(Color.YELLOW);
                    break;
                case "Rouge":
                    textArea.setBackground(Color.RED);
                    break;
                default:
                    textArea.setBackground(Color.WHITE);
                    break;
            }
            textArea.repaint();
        });

        // Modification de la couleur du texte 
        textBox.addActionListener(e -> {
            String selected = (String) textBox.getSelectedItem();
            switch (selected) {
                case "Rouge":
                    textArea.setForeground(Color.RED);
                    break;
                case "Vert":
                    textArea.setForeground(Color.GREEN);
                    break;
                default:
                    textArea.setForeground(Color.BLACK);
                    break;
            }
            textArea.repaint(); // Ca ne marchait pas sans 
        });
    }
}


/* 
 * 
 * 
 * 
 * 
 * 
 * 
 * Ensuite le panel central, avec la zone de dessin
 * 
 * 
 * 
 * 
 * 
 * */

class DessinPanel extends JPanel {
	// Paramètres
    private Color currentColor = Color.BLACK;
    private boolean pointillé = false;
    private int strokeWidth = 2;
    private Point lastPoint = null;
    
    public DessinPanel() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        
        // Options de dessin
        JPanel optionsPanel = new JPanel();
        String[] colors = {"Noir", "Rouge", "Bleu", "Vert"};
        JComboBox<String> colorBox = new JComboBox<>(colors);
        String[] styles = {"Continu", "Pointillé"};
        JComboBox<String> styleBox = new JComboBox<>(styles);
        String[] widths = {"1", "2", "3", "5", "8"};
        JComboBox<String> widthBox = new JComboBox<>(widths);
        
        optionsPanel.add(new JLabel("Couleur:"));
        optionsPanel.add(colorBox);
        optionsPanel.add(new JLabel("Style:"));
        optionsPanel.add(styleBox);
        optionsPanel.add(new JLabel("Épaisseur:"));
        optionsPanel.add(widthBox);
        
        add(optionsPanel, BorderLayout.NORTH);
        
        // Zone de dessin
        JPanel drawingArea = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
            }
        };
        drawingArea.setBackground(Color.WHITE);
        add(drawingArea, BorderLayout.CENTER);
        
        // Gestion du dessin avec la souriss
        drawingArea.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                if (lastPoint != null) {
                    Graphics2D g2d = (Graphics2D) drawingArea.getGraphics();
                    g2d.setColor(currentColor);
                    Stroke stroke;
                    if (pointillé) {
                    	// Pointillé
                        float[] dashPattern = {5, 5};
                        stroke = new BasicStroke(strokeWidth, BasicStroke.CAP_ROUND,
                                BasicStroke.JOIN_ROUND, 10, dashPattern, 0);
                    } else {
                        stroke = new BasicStroke(strokeWidth);
                    }
                    g2d.setStroke(stroke);
                    g2d.draw(new Line2D.Float(lastPoint.x, lastPoint.y, e.getX(), e.getY()));
                }
                lastPoint = e.getPoint();
            }
        });
        
        drawingArea.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                lastPoint = null;
            }
        });
        
        // Modification des options de dessin
        colorBox.addActionListener(e -> {
            String selected = (String) colorBox.getSelectedItem();
            switch (selected) {
                case "Rouge": currentColor = Color.RED; break;
                case "Bleu": currentColor = Color.BLUE; break;
                case "Vert": currentColor = Color.GREEN; break;
                default: currentColor = Color.BLACK;
            }
        });
        
        styleBox.addActionListener(e -> {
            String selected = (String) styleBox.getSelectedItem();
            pointillé = "Pointillé".equals(selected);
        });
        
        // Taille du trait 
        widthBox.addActionListener(e -> {
            strokeWidth = Integer.parseInt((String) widthBox.getSelectedItem());
        });
    }
}

/* 
 * 
 * 
 * 
 * 
 * 
 * 
 * Enfin le panel du deuxième onglet, avec les 100 boutons
 * 
 * 
 * 
 * 
 * 
 * */
class CentBoutonPanel extends JPanel {
    public CentBoutonPanel(JFrame parent) {
        setLayout(new GridLayout(10, 10, 5, 5));
        setBackground(Color.WHITE);
        
        for (int i = 1; i <= 100; i++) {
            JButton button = new JButton("Bouton " + i);
            if (i == 22) {
                // Pour le 22ème bouton : effet au survol et ouverture d'une nouvelle IHM
                button.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseEntered(MouseEvent e) {
                        button.setBackground(Color.RED);
                    }
                    @Override // Poiur fermer
                    public void mouseExited(MouseEvent e) {
                        button.setBackground(UIManager.getColor("Button.background"));
                    }
                });
                button.addActionListener(e -> new CustomWindow(parent));
            }
            add(button);
        }
    }
}

//Fenêtre lancée depuis le 22ème bouton, on modifie la couleur du fond aléatoirement en cliquant sur un bouton
class CustomWindow extends JFrame {
 public CustomWindow(JFrame parent) {
     setTitle("Nouvelle IHM Originale");
     setSize(400, 300);
     setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
     setLocationRelativeTo(parent);

     // Création du panel principal avec BorderLayout et une marge interne
     JPanel panel = new JPanel(new BorderLayout());
     panel.setBackground(Color.LIGHT_GRAY);
     panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

     // Label avec un message de bienvenue et un style personnalisé
     JLabel label = new JLabel("OUUHHHHH !", JLabel.CENTER);
     label.setFont(new Font("Arial", Font.BOLD, 16));
     label.setForeground(Color.BLUE);

    
     JPanel buttonPanel = new JPanel();
     buttonPanel.setBackground(Color.LIGHT_GRAY);

     // Bouton pour changer la couleur de fond de la fenêtre
     JButton changeColorButton = new JButton("Changer couleur");
     changeColorButton.addActionListener(e -> {
         // Génération d'une couleur aléatoire
         int r = (int) (Math.random() * 256);
         int g = (int) (Math.random() * 256);
         int b = (int) (Math.random() * 256);
         Color randomColor = new Color(r, g, b);
         panel.setBackground(randomColor);
         buttonPanel.setBackground(randomColor);
     });

     JButton closeButton = new JButton("Fermer");
     closeButton.addActionListener(e -> dispose());

     buttonPanel.add(changeColorButton);
     buttonPanel.add(closeButton);

     panel.add(label, BorderLayout.CENTER);
     panel.add(buttonPanel, BorderLayout.SOUTH);
     add(panel);

     setVisible(true);
 }
}

