package gibbes_kemy;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class mainApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Projet Java IHM");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(1000, 700);
            
            JTabbedPane tabbedPane = new JTabbedPane();
            
            JPanel mainPanel = new JPanel(new BorderLayout());
            mainPanel.add(new TopPanel(), BorderLayout.NORTH);
            mainPanel.add(new BottomPanel(), BorderLayout.SOUTH);
            mainPanel.add(new LeftPanel(), BorderLayout.WEST);  // Panneau de gauche ajouté
            mainPanel.add(new RightPanel(), BorderLayout.EAST);
            mainPanel.add(new CenterPanel(), BorderLayout.CENTER);
            
            // Ajout du premier onglet avec l'IHM principale
            tabbedPane.addTab("Main", mainPanel);
            
            // Ajout du second onglet avec les 100 boutons
            tabbedPane.addTab("100 Buttons", create100ButtonsPanel());
            
            frame.add(tabbedPane);
            frame.setVisible(true);
        });
    }
    
    // Fonction pour créer le panneau avec 100 boutons
    private static JPanel create100ButtonsPanel() {
        JPanel panel = new JPanel(new GridLayout(10, 10));

        for (int i = 1; i <= 100; i++) {
            JButton btn = new JButton("Btn " + i);

            if (i == 22) {
                btn.addMouseListener(new java.awt.event.MouseAdapter() {
                    @Override
                    public void mouseEntered(java.awt.event.MouseEvent e) {
                        btn.setBackground(Color.RED); // Change la couleur du bouton au survol
                    }

                    @Override
                    public void mouseExited(java.awt.event.MouseEvent e) {
                        btn.setBackground(null); // Remet la couleur par défaut
                    }

                    @Override
                    public void mouseClicked(java.awt.event.MouseEvent e) {
                        new SpecialWindow(); // Ouvre la fenêtre spéciale
                    }
                });
            }

            panel.add(btn);
        }

        return panel;
    }
}

class TopPanel extends JPanel {
    private int mouseX, mouseY;

    public TopPanel() {
        setBackground(Color.LIGHT_GRAY);
        setPreferredSize(new Dimension(1000, 100));
        setLayout(null); // Utilisation d'un layout nul pour gérer les positions manuellement

        // Création du Bouton 1
        JButton button1 = new JButton("Button 1");
        button1.setBounds(50, 20, 100, 30); // Position initiale du bouton

        // Action du Bouton 1 pour ouvrir la fenêtre de saisie
        button1.addActionListener(e -> new InformationWindow());

        // Gestion du drag du Bouton 1
        button1.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
            }
        });

        button1.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int dx = e.getX() - mouseX;
                int dy = e.getY() - mouseY;
                button1.setLocation(button1.getX() + dx, button1.getY() + dy);
            }
        });

        // Ajout du Bouton 1 dans le panel
        add(button1);

        // Création du Bouton 2
        JButton button2 = new JButton("Button 2");
        button2.setBounds(200, 20, 100, 30); // Position initiale du bouton

        // Action du Bouton 2 pour ouvrir la fenêtre circulaire
        button2.addActionListener(e -> new CircularWindow());

        // Gestion du drag du Bouton 2
        button2.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
            }
        });

        button2.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int dx = e.getX() - mouseX;
                int dy = e.getY() - mouseY;
                button2.setLocation(button2.getX() + dx, button2.getY() + dy);
            }
        });

        // Ajout du Bouton 2 dans le panel
        add(button2);
        
     // Création du Bouton 3
        JButton button3 = new JButton("Button 3");
        button3.setBounds(350, 20, 100, 30); // Position initiale du bouton

        // Gestion du drag du Bouton 3
        button3.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
            }
            
        });

        button3.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int dx = e.getX() - mouseX;
                int dy = e.getY() - mouseY;
                button3.setLocation(button3.getX() + dx, button3.getY() + dy);
            }
        });

        // Ajout du Bouton 3 dans le panel
        add(button3);
    }
    }


class CircularWindow extends JFrame {
    private JSlider colorSlider;
    private JPanel panel;

    public CircularWindow() {
        setTitle("Fenêtre Circulaire");
        setSize(300, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setUndecorated(true); // Retirer les bordures de la fenêtre
        setShape(new java.awt.geom.Ellipse2D.Double(0, 0, 300, 300)); // Fenêtre circulaire

        // Panneau pour la fenêtre circulaire
        panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBackground(new Color(0, 0, 0)); // Couleur de fond initiale (noir)

        // Slider pour changer la couleur de la fenêtre
        colorSlider = new JSlider(0, 255, 0); // Plage de 0 à 255 pour changer la couleur
        colorSlider.setMajorTickSpacing(50);
        colorSlider.setPaintTicks(true);
        colorSlider.setPaintLabels(true);
        colorSlider.addChangeListener(e -> changeWindowColor());

        // Ajouter le slider au centre du panneau
        panel.add(colorSlider, BorderLayout.CENTER);

        // Bouton pour fermer la fenêtre
        JButton closeButton = new JButton("Fermer");
        closeButton.addActionListener(e -> dispose());

        // Ajouter le bouton au bas de la fenêtre
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(closeButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        add(panel);
        setVisible(true);
    }

    private void changeWindowColor() {
        int value = colorSlider.getValue();
        panel.setBackground(new Color(value, value, value)); // Modifie la couleur du panneau central
    }
}





class InformationWindow extends JFrame {
    private JTextField nameField, surnameField, ageField, schoolField;
    private JLabel infoLabel;
    
    public InformationWindow() {
        setTitle("Formulaire d'information");
        setSize(400, 300);
        setLocationRelativeTo(null); // Centrer la fenêtre
        setLayout(new GridLayout(6, 1, 10, 10)); // Utilisation d'un GridLayout pour organiser les champs
        
        // Champs à remplir
        JPanel namePanel = new JPanel(new FlowLayout());
        namePanel.add(new JLabel("Nom:"));
        nameField = new JTextField(20);
        namePanel.add(nameField);
        
        JPanel surnamePanel = new JPanel(new FlowLayout());
        surnamePanel.add(new JLabel("Prénom:"));
        surnameField = new JTextField(20);
        surnamePanel.add(surnameField);
        
        JPanel agePanel = new JPanel(new FlowLayout());
        agePanel.add(new JLabel("Âge:"));
        ageField = new JTextField(5);
        agePanel.add(ageField);
        
        JPanel schoolPanel = new JPanel(new FlowLayout());
        schoolPanel.add(new JLabel("École:"));
        schoolField = new JTextField(20);
        schoolPanel.add(schoolField);
        
        // Label pour afficher les informations
        infoLabel = new JLabel("Informations: ", JLabel.CENTER);
        
        // Bouton OK pour afficher les informations
        JButton okButton = new JButton("OK");
        okButton.addActionListener(e -> displayInformation());
        
        // Bouton pour fermer la fenêtre
        JButton closeButton = new JButton("Fermer");
        closeButton.addActionListener(e -> dispose()); // Fermer la fenêtre
        
        add(namePanel);
        add(surnamePanel);
        add(agePanel);
        add(schoolPanel);
        add(okButton);
        add(infoLabel);
        add(closeButton);
        
        setVisible(true);
    }
    
    // Méthode pour afficher les informations saisies
    private void displayInformation() {
        String name = nameField.getText();
        String surname = surnameField.getText();
        String age = ageField.getText();
        String school = schoolField.getText();
        
        infoLabel.setText("Nom: " + name + ", Prénom: " + surname + ", Âge: " + age + ", École: " + school);
    }
}

class BottomPanel extends JPanel {
    public BottomPanel() {
        setBackground(Color.GREEN); // Changement de la couleur de fond en vert
        setPreferredSize(new Dimension(1000, 100));
        // Espace laissé vide
    }
}

class LeftPanel extends JPanel {
    public LeftPanel() {
        setBackground(Color.YELLOW); // Changer la couleur de fond en jaune
        setPreferredSize(new Dimension(150, 500));
        setLayout(new BorderLayout());

        // Suppression du JLabel pour enlever l'écriture
        // Aucun composant de texte n'est ajouté au panneau gauche maintenant
    }
}


class RightPanel extends JPanel {
    private JTextArea textArea;

    public RightPanel() {
        setBackground(Color.RED); // Changement de la couleur de fond en rouge
        setPreferredSize(new Dimension(150, 500));
        setLayout(new BorderLayout());

        // Ajout du panneau de saisie de texte
        textArea = new JTextArea(10, 20);
        JScrollPane scrollPane = new JScrollPane(textArea);
        add(scrollPane, BorderLayout.CENTER);

        // Panneau pour les options de personnalisation
        JPanel optionsPanel = new JPanel(new GridLayout(2, 2, 10, 10));

        // Liste déroulante pour la couleur du fond
        JLabel backgroundColorLabel = new JLabel("Couleur du fond:");
        JComboBox<String> backgroundColorComboBox = new JComboBox<>(new String[] {"Blanc", "Noir", "Gris clair", "Bleu"});
        backgroundColorComboBox.addActionListener(e -> changeBackgroundColor((String) backgroundColorComboBox.getSelectedItem()));

        // Liste déroulante pour la couleur du texte
        JLabel textColorLabel = new JLabel("Couleur du texte:");
        JComboBox<String> textColorComboBox = new JComboBox<>(new String[] {"Noir", "Blanc", "Rouge", "Vert", "Bleu"});
        textColorComboBox.addActionListener(e -> changeTextColor((String) textColorComboBox.getSelectedItem()));

        // Ajouter les options au panneau
        optionsPanel.add(backgroundColorLabel);
        optionsPanel.add(backgroundColorComboBox);
        optionsPanel.add(textColorLabel);
        optionsPanel.add(textColorComboBox);

        add(optionsPanel, BorderLayout.SOUTH); // Ajouter le panneau d'options en bas
    }

    // Méthode pour changer la couleur du fond de la zone de texte
    private void changeBackgroundColor(String color) {
        switch (color) {
            case "Blanc":
                textArea.setBackground(Color.WHITE);
                break;
            case "Noir":
                textArea.setBackground(Color.BLACK);
                break;
            case "Gris clair":
                textArea.setBackground(Color.LIGHT_GRAY);
                break;
            case "Bleu":
                textArea.setBackground(Color.BLUE);
                break;
            default:
                textArea.setBackground(Color.WHITE);
        }
    }

    // Méthode pour changer la couleur du texte dans la zone de texte
    private void changeTextColor(String color) {
        switch (color) {
            case "Noir":
                textArea.setForeground(Color.BLACK);
                break;
            case "Blanc":
                textArea.setForeground(Color.WHITE);
                break;
            case "Rouge":
                textArea.setForeground(Color.RED);
                break;
            case "Vert":
                textArea.setForeground(Color.GREEN);
                break;
            case "Bleu":
                textArea.setForeground(Color.BLUE);
                break;
            default:
                textArea.setForeground(Color.BLACK);
        }
    }
}


class CenterPanel extends JPanel {
    private Color color = Color.RED;
    private String strokeStyle = "Continu";
    private int lineWidth = 1;
    private int lastX, lastY;
    
    private JComboBox<String> colorComboBox;
    private JComboBox<String> strokeStyleComboBox;
    private JComboBox<Integer> lineWidthComboBox;

    public CenterPanel() {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(500, 500)); // Taille du panel de dessin
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                lastX = e.getX();
                lastY = e.getY();
            }
        });
        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                Graphics g = getGraphics();
                g.setColor(color);
                if ("Pointillé".equals(strokeStyle)) {
                    ((Graphics2D) g).setStroke(new BasicStroke(lineWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1, new float[]{9}, 0));
                } else {
                    ((Graphics2D) g).setStroke(new BasicStroke(lineWidth));
                }
                g.drawLine(lastX, lastY, e.getX(), e.getY());
                lastX = e.getX();
                lastY = e.getY();
            }
        });
        
        // Panneau pour les options de personnalisation
        JPanel optionsPanel = new JPanel(new GridLayout(3, 2));
        
        // Liste déroulante pour la couleur
        JLabel colorLabel = new JLabel("Couleur du trait:");
        colorComboBox = new JComboBox<>(new String[] {"Rouge", "Bleu", "Vert", "Noir"});
        colorComboBox.addActionListener(e -> {
            switch (colorComboBox.getSelectedItem().toString()) {
                case "Rouge":
                    color = Color.RED;
                    break;
                case "Bleu":
                    color = Color.BLUE;
                    break;
                case "Vert":
                    color = Color.GREEN;
                    break;
                default:
                    color = Color.BLACK;
            }
        });

        // Liste déroulante pour la forme du trait
        JLabel strokeStyleLabel = new JLabel("Style du trait:");
        strokeStyleComboBox = new JComboBox<>(new String[] {"Continu", "Pointillé"});
        strokeStyleComboBox.addActionListener(e -> strokeStyle = (String) strokeStyleComboBox.getSelectedItem());

        // Liste déroulante pour la largeur du trait
        JLabel lineWidthLabel = new JLabel("Largeur du trait:");
        lineWidthComboBox = new JComboBox<>(new Integer[] {1, 2, 3, 4, 5});
        lineWidthComboBox.addActionListener(e -> lineWidth = (Integer) lineWidthComboBox.getSelectedItem());
        
        // Ajouter les options au panneau
        optionsPanel.add(colorLabel);
        optionsPanel.add(colorComboBox);
        optionsPanel.add(strokeStyleLabel);
        optionsPanel.add(strokeStyleComboBox);
        optionsPanel.add(lineWidthLabel);
        optionsPanel.add(lineWidthComboBox);
        
        add(optionsPanel, BorderLayout.NORTH);
    }
}

class SpecialWindow extends JFrame {
    public SpecialWindow() {
        setTitle("Fenêtre Spéciale");
        setSize(400, 300);
        setLocationRelativeTo(null); // Centrer la fenêtre
        getContentPane().setBackground(Color.CYAN); // Changer la couleur de fond

        JLabel label = new JLabel("La meute a encore frappé ...", JLabel.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 16));
        label.setForeground(Color.WHITE);

        add(label, BorderLayout.CENTER);
        setVisible(true);
    }
}
