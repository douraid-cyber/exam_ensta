import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;

public class MainFrame extends JFrame {
    private DrawingPanel drawingPanel;

    public MainFrame() {
        setTitle("Application Swing Projet");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        
        
        // Create the tabbed pane
        JTabbedPane tabbedPane = new JTabbedPane();

        // *TAB 1: Drawing Panel + Controls*
        JPanel drawingTab = new JPanel(new BorderLayout());
        
        tabbedPane.setBackground(Color.BLUE);


        // Initialiser les différentes zones/panels
        DraggableButtonsPanel dragPanel = new DraggableButtonsPanel();
        drawingPanel = new DrawingPanel();
        TextPanel2 textPanel = new TextPanel2();

        // Panneau supérieur (Haut) avec les contrôles de dessin (couleur, style, largeur)
        JPanel controlsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        controlsPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        // Contrôle couleur (combo box)
        JLabel colorLabel = new JLabel("Couleur:");
        String[] colors = {"Noir", "Rouge", "Vert", "Bleu"};
        Color[] colorValues = { Color.BLACK, Color.RED, Color.GREEN, Color.BLUE };
        JComboBox<String> colorCombo = new JComboBox<>(colors);
        colorCombo.setSelectedIndex(0);
        
        JLabel styleLabel = new JLabel("Style:");
        String[] styles = {"Continu", "Pointillé"};
        JComboBox<String> styleCombo = new JComboBox<>(styles);
        styleCombo.setSelectedIndex(0);
        
        
        // Contrôle style (radio boutons pour continu/pointillé)

        // Contrôle largeur (spinner numérique)
        JLabel widthLabel = new JLabel(" Largeur:");
        String[] width = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
        JComboBox<String> widthCombo = new JComboBox<>(width);
        widthCombo.setSelectedIndex(0);
        
        SpinnerNumberModel widthModel = new SpinnerNumberModel(2, 1, 10, 1);
        JSpinner widthSpinner = new JSpinner(widthModel);

        // Ajouter les contrôles au panneau supérieur
        controlsPanel.add(colorLabel);
        controlsPanel.add(colorCombo);
        controlsPanel.add(styleLabel);
        controlsPanel.add(styleCombo);
        controlsPanel.add(widthLabel);
        controlsPanel.add(widthCombo);

        // Écouteurs pour mettre à jour la zone de dessin selon les contrôles
        colorCombo.addActionListener(e -> {
            int index = colorCombo.getSelectedIndex();
            if (index >= 0) {
                drawingPanel.setCurrentColor(colorValues[index]);
            }
        });
        
        styleCombo.addActionListener(e -> {
            int index = styleCombo.getSelectedIndex();
            if (index == 0) {
            	drawingPanel.setDashed(false);
            }
            else if(index == 1) {
            	drawingPanel.setDashed(true);
            }
        });
        

        widthCombo.addActionListener(e -> {
            int w = widthCombo.getSelectedIndex() + 1;
            if(w>=0)
            	drawingPanel.setStrokeWidth(w);
        });

        // Panneau inférieur (Bas) avec le bouton pour ouvrir l'interface 2
        JButton openSecondBtn = new JButton("Ouvrir la deuxième interface");
        openSecondBtn.addActionListener(e -> {
            ButtonGridFrame gridFrame = new ButtonGridFrame();
            gridFrame.setVisible(true);
        });
        JPanel bottomPanel = new JPanel();
        bottomPanel.add(openSecondBtn);

     // *Add Components to Drawing Tab*
        drawingTab.add(controlsPanel, BorderLayout.NORTH);
        drawingTab.add(dragPanel, BorderLayout.WEST);
        drawingTab.add(textPanel, BorderLayout.EAST);
        drawingTab.add(drawingPanel, BorderLayout.CENTER);


        // *TAB 2: Button Grid Panel*
        ButtonGridFrame gridPanel = new ButtonGridFrame();
        tabbedPane.addTab("Dessin", drawingTab);
        tabbedPane.addTab("Boutons", gridPanel.getContentPane());

        // Add the tabbed pane to the main frame
        add(tabbedPane, BorderLayout.CENTER);

        // Set frame size and show
        setSize(1000, 600);
        setLocationRelativeTo(null);
    }


    

    
}
