import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DraggableButtonsPanel extends JPanel {
    public DraggableButtonsPanel() {
        // Zone avec 3 boutons déplaçables
        setLayout(null);
        setBorder(BorderFactory.createTitledBorder("Zone de boutons"));

        // Création des boutons
        JButton b1 = new JButton("1");
        JButton b2 = new JButton("2");
        JButton b3 = new JButton("3");
        
        b1.addActionListener(e -> {
            RoundedWindow gridFrame = new RoundedWindow();
            gridFrame.setVisible(true);
        });
        
        b2.addActionListener(e -> {
            CircularWindow gridFrame = new CircularWindow();
            gridFrame.setVisible(true);
        });

        b3.addActionListener(e -> {
            PolygonWindow gridFrame = new PolygonWindow();
            gridFrame.setVisible(true);
        });

        // Position initiale et taille des boutons dans la zone (position absolue)
        b1.setBounds(20, 20, 80, 30);
        b2.setBounds(20, 60, 80, 30);
        b3.setBounds(20, 100, 80, 30);

        // Listener pour gérer le glisser-déposer des boutons
        MouseAdapter dragListener = new MouseAdapter() {
            private Point offset = null;
            @Override
            public void mousePressed(MouseEvent e) {
                // Enregistrer le décalage entre le point cliqué et l'origine du bouton
                JButton btn = (JButton) e.getSource();
                offset = e.getPoint();
            }
            @Override
            public void mouseDragged(MouseEvent e) {
                JButton btn = (JButton) e.getSource();
                if (offset != null) {
                    // Convertir le point de la souris relatif au bouton en coordonnées relatives au panel
                    Point p = SwingUtilities.convertPoint(btn, e.getPoint(), DraggableButtonsPanel.this);
                    int newX = p.x - offset.x;
                    int newY = p.y - offset.y;
                    // Empêcher le bouton de sortir des limites du panel
                    if (newX < 0) newX = 0;
                    if (newY < 0) newY = 0;
                    if (newX + btn.getWidth() > getWidth()) {
                        newX = getWidth() - btn.getWidth();
                    }
                    if (newY + btn.getHeight() > getHeight()) {
                        newY = getHeight() - btn.getHeight();
                    }
                    btn.setLocation(newX, newY);
                }
            }
        };
        // Attacher le listener de drag à chaque bouton
        b1.addMouseListener(dragListener);
        b1.addMouseMotionListener(dragListener);
        b2.addMouseListener(dragListener);
        b2.addMouseMotionListener(dragListener);
        b3.addMouseListener(dragListener);
        b3.addMouseMotionListener(dragListener);

        // Ajouter les boutons au panel
        add(b1);
        add(b2);
        add(b3);
        // Définir une taille préférée pour la zone (largeur fixe, hauteur variable)
        setPreferredSize(new Dimension(150, 0));
    }
}
