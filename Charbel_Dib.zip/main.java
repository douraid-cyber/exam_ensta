
public class main {

	public static void main(String[] args) {
		MainFrame mf = new MainFrame();
		mf.setVisible(true);

	}

}
