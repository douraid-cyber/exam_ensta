import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.ArrayList;
import java.util.List;

public class DrawingPanel extends JPanel {
    private Color currentColor = Color.BLACK;
    private float currentWidth = 2f;
    private boolean dashed = false;
    private Stroke currentStroke;
    private Path2D currentPath;
    // Liste des formes tracées (chemins, couleurs et styles)
    private final List<DrawnShape> shapes = new ArrayList<>();

    // Classe interne pour stocker une forme dessinée avec sa couleur et son trait
    private static class DrawnShape {
        Shape shape;
        Color color;
        Stroke stroke;
        DrawnShape(Shape shape, Color color, Stroke stroke) {
            this.shape = shape;
            this.color = color;
            this.stroke = stroke;
        }
    }

    public DrawingPanel() {
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createTitledBorder("Zone de dessin"));
        // (Optionnel) Taille préférée en hauteur pour la zone de dessin
        setPreferredSize(new Dimension(0, 400));

        // Gestion de la souris pour dessiner à main levée
        MouseAdapter drawListener = new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                // Commencer un nouveau tracé
                currentPath = new Path2D.Float();
                currentPath.moveTo(e.getX(), e.getY());
                // Déterminer le stroke (trait) courant en fonction des paramètres
                if (dashed) {
                    float[] dashPattern = {10f, 10f};
                    currentStroke = new BasicStroke(currentWidth, 
                                      BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 
                                      10f, dashPattern, 0f);
                } else {
                    currentStroke = new BasicStroke(currentWidth, 
                                      BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
                }
            }
            @Override
            public void mouseDragged(MouseEvent e) {
                // Continuer le tracé en suivant la souris
                if (currentPath != null) {
                    currentPath.lineTo(e.getX(), e.getY());
                    repaint();  // redessiner en continu
                }
            }
            @Override
            public void mouseReleased(MouseEvent e) {
                // Terminer le tracé en cours
                if (currentPath != null) {
                    currentPath.lineTo(e.getX(), e.getY());
                    // Ajouter le tracé finalisé à la liste des formes
                    shapes.add(new DrawnShape(currentPath, currentColor, currentStroke));
                    currentPath = null;
                    repaint();
                }
            }
        };
        // Attacher les listeners souris au panel de dessin
        addMouseListener(drawListener);
        addMouseMotionListener(drawListener);
    }

    // Méthodes pour mettre à jour les paramètres de dessin depuis l'UI
    public void setCurrentColor(Color c) {
        currentColor = c;
    }
    public void setStrokeWidth(float w) {
        currentWidth = w;
    }
    public void setDashed(boolean d) {
        dashed = d;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // Dessiner toutes les formes stockées
        Graphics2D g2 = (Graphics2D) g;
        for (DrawnShape ds : shapes) {
            g2.setColor(ds.color);
            g2.setStroke(ds.stroke);
            g2.draw(ds.shape);
        }
        // Dessiner la forme en cours (pendant le drag) si présente
        if (currentPath != null) {
            g2.setColor(currentColor);
            g2.setStroke(currentStroke);
            g2.draw(currentPath);
        }
    }
}
