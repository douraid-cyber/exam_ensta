import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;

public class PolygonWindow extends JFrame {
    private JButton centerButton;
    private JButton[] edgeButtons;  // tableau pour les boutons sur les bords

    public PolygonWindow() {
    	super("Fenêtre Personnalisée");

        // Supprimer la décoration pour éviter la barre de titre
        setUndecorated(true);
        setSize(300, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Ajouter le panneau personnalisé qui dessine la forme
        CustomShapePanel shapePanel = new CustomShapePanel();
        setContentPane(shapePanel);
        shapePanel.setLayout(null); // Positionnement absolu des boutons

        // Bouton étoile central
        JButton starButton = createButton("★", 115, 115, 50, 50, Color.WHITE, Color.YELLOW);
        starButton.addActionListener(e -> dispose()); // Ferme la fenêtre
        shapePanel.add(starButton);

        // Bouton X (en bas à gauche)
        JButton btnX = createButton("X", 40, 200, 40, 40, Color.LIGHT_GRAY, Color.BLACK);
        shapePanel.add(btnX);

        // Bouton O (au centre droit)
        JButton btnO = createButton("O", 140, 140, 40, 40, Color.LIGHT_GRAY, Color.BLACK);
        shapePanel.add(btnO);

        // Bouton Y (en haut à droite)
        JButton btnY = createButton("Y", 220, 50, 40, 40, Color.LIGHT_GRAY, Color.BLACK);
        shapePanel.add(btnY);
    }

    private JButton createButton(String text, int x, int y, int width, int height, Color bg, Color fg) {
        JButton btn = new JButton(text);
        btn.setBounds(x, y, width, height);
        btn.setFont(new Font("SansSerif", Font.BOLD, 14));
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setFocusPainted(false);

        // Effet au survol
        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(Color.ORANGE);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(bg);
            }
        });

        return btn;
        
        
    
    }

}
class CustomShapePanel extends JPanel {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        // Couleur de fond
        g2.setColor(Color.DARK_GRAY);

        // Dessiner la partie carrée
        g2.fillRect(80, 50, 100, 100);

        // Dessiner les cercles
        g2.fillOval(30, 180, 50, 50); // Cercle bas-gauche
        g2.fillOval(130, 130, 50, 50); // Cercle centre-droit
        g2.fillOval(210, 40, 50, 50); // Cercle haut-droit
        g2.fillOval(110, 110, 60, 60); // Cercle central (étoile)

        // Dessiner les contours
        g2.setColor(Color.BLACK);
        g2.drawRect(80, 50, 100, 100);
        g2.drawOval(30, 180, 50, 50);
        g2.drawOval(130, 130, 50, 50);
        g2.drawOval(210, 40, 50, 50);
        g2.drawOval(110, 110, 60, 60);
    }
}
