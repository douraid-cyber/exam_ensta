import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Ellipse2D;

public class CircularWindow extends JFrame {
    private int mouseX, mouseY;
    private JPanel colorPanel;
    private JSlider colorSlider;
    private JCheckBox redCheck, greenCheck, blueCheck, alphaCheck;

    public CircularWindow() {
        // Configuration de base
        setSize(300, 300);
        setUndecorated(true);
        setShape(new Ellipse2D.Float(0, 0, getWidth(), getHeight())); // Fenêtre ronde
        setBackground(new Color(0, 0, 0, 0)); // Fond transparent
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // 🎨 PANEL PRINCIPAL AVEC DESSIN DU CERCLE
        colorPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(getBackground());
                g2d.fillOval(0, 0, getWidth(), getHeight()); // Dessiner le cercle
            }
        };
        colorPanel.setOpaque(false);
        colorPanel.setLayout(null); // Permet d'ajouter les composants avec setBounds()
        add(colorPanel, BorderLayout.CENTER);

        // 🛑 BOUTON FERMER
        JButton closeButton = new JButton("X");
        closeButton.setBounds(230, 10, 40, 30);
        closeButton.setBackground(Color.RED);
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        closeButton.addActionListener(e -> dispose());
        colorPanel.add(closeButton);

        // 🎚 SLIDER COULEUR
        colorSlider = new JSlider(0, 255, 128);
        colorSlider.setMajorTickSpacing(64);
        colorSlider.setPaintTicks(true);
        colorSlider.setPaintLabels(true);
        colorSlider.addChangeListener(e -> updateBackgroundColor());

        JPanel sliderPanel = new JPanel();
        sliderPanel.add(colorSlider);
        add(sliderPanel, BorderLayout.SOUTH);

        // ✅ CHECKBOXES COULEUR
        redCheck = new JCheckBox("R", true);
        greenCheck = new JCheckBox("G", true);
        blueCheck = new JCheckBox("B", true);
        alphaCheck = new JCheckBox("Alpha");
        JPanel checkPanel = new JPanel();
        checkPanel.add(redCheck);
        checkPanel.add(greenCheck);
        checkPanel.add(blueCheck);
        checkPanel.add(alphaCheck);
        add(checkPanel, BorderLayout.NORTH);

        // 🎯 PERMETTRE DEPLACEMENT FENÊTRE
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                mouseX = e.getXOnScreen() - getX();
                mouseY = e.getYOnScreen() - getY();
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                setLocation(e.getXOnScreen() - mouseX, e.getYOnScreen() - mouseY);
            }
        });

        setVisible(true);
    }

    // 🔥 METTRE À JOUR LA COULEUR DU CERCLE
    private void updateBackgroundColor() {
        int value = colorSlider.getValue();
        int r = redCheck.isSelected() ? value : 128;
        int g = greenCheck.isSelected() ? value : 128;
        int b = blueCheck.isSelected() ? value : 128;
        int a = alphaCheck.isSelected() ? value : 255;

        // Appliquer la nouvelle couleur et REDESSINER
        colorPanel.setBackground(new Color(r, g, b, a));
        colorPanel.repaint();
    }


}
