import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class RoundedWindow extends JFrame {
    private JTextField fieldNom, fieldPrenom, fieldAge, fieldEcole;
    private JLabel labelNom, labelPrenom, labelAge, labelEcole;
    private JButton okButton, closeButton;

    public RoundedWindow() {
        super("Informations Personnelles");
        // Fenêtre sans bordure avec coins arrondis
        setUndecorated(true);
        setShape(new RoundRectangle2D.Float(0, 0, 450, 300, 30, 30)); // Augmentation de la taille

        // Configuration de base
        setSize(450, 300);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // 📝 Panneau principal contenant le formulaire
        JPanel formPanel = new JPanel(new GridLayout(4, 3, 5, 5)); // 4 lignes et 3 colonnes
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // 🏷️ Labels des champs de texte
        formPanel.add(new JLabel("Nom:"));
        fieldNom = new JTextField();
        formPanel.add(fieldNom);
        labelNom = new JLabel(" "); // Label vide pour afficher la réponse
        formPanel.add(labelNom);

        formPanel.add(new JLabel("Prénom:"));
        fieldPrenom = new JTextField();
        formPanel.add(fieldPrenom);
        labelPrenom = new JLabel(" ");
        formPanel.add(labelPrenom);

        formPanel.add(new JLabel("Âge:"));
        fieldAge = new JTextField();
        formPanel.add(fieldAge);
        labelAge = new JLabel(" ");
        formPanel.add(labelAge);

        formPanel.add(new JLabel("École:"));
        fieldEcole = new JTextField();
        formPanel.add(fieldEcole);
        labelEcole = new JLabel(" ");
        formPanel.add(labelEcole);

        // ✅ Ajouter le formulaire en haut
        add(formPanel, BorderLayout.NORTH);

        // 🎯 Panneau pour le bouton OK (centré)
        JPanel okPanel = new JPanel();
        okButton = new JButton("OK");
        okButton.setPreferredSize(new Dimension(120, 40)); // Taille plus grande
        okButton.addActionListener(e -> {
            // Mise à jour des labels sous chaque champ
            labelNom.setText(fieldNom.getText());
            labelPrenom.setText(fieldPrenom.getText());
            labelAge.setText(fieldAge.getText());
            labelEcole.setText(fieldEcole.getText());
        });

        okPanel.add(okButton);
        add(okPanel, BorderLayout.CENTER);

        // 🛑 Panneau pour le bouton Fermer (aligné à droite)
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        closeButton = new JButton("Fermer");
        closeButton.addActionListener(e -> dispose());
        bottomPanel.add(closeButton);
        add(bottomPanel, BorderLayout.PAGE_END);
    }


}
