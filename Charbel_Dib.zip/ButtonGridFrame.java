import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ButtonGridFrame extends JFrame {
    public ButtonGridFrame() {
        setTitle("Interface 2 : 100 Boutons");
        setLayout(new GridLayout(10, 10));

        // Création des 100 boutons
        for (int i = 1; i <= 100; i++) {
            JButton button = new JButton(String.valueOf(i));
            if (i == 22) {
                // Comportement spécial pour le 22e bouton
                final JButton specialButton = button;
                final Color origColor = specialButton.getBackground();
                // Changer de couleur au survol de la souris
                specialButton.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseEntered(MouseEvent e) {
                        specialButton.setBackground(Color.RED);
                    }
                    @Override
                    public void mouseExited(MouseEvent e) {
                        specialButton.setBackground(origColor);
                    }
                });
                // Ouvrir une nouvelle fenêtre personnalisée au clic
                specialButton.addActionListener(e -> {
                    JFrame customFrame = new JFrame("Fenêtre personnalisée");
                    customFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    customFrame.setSize(300, 150);
                    customFrame.getContentPane().setBackground(Color.LIGHT_GRAY);
                    customFrame.setLayout(new BorderLayout());
                    JLabel label = new JLabel("Vous avez cliqué le bouton 22 !", JLabel.CENTER);
                    label.setFont(new Font("Serif", Font.BOLD, 16));
                    customFrame.add(label, BorderLayout.CENTER);
                    // Positionner la nouvelle fenêtre relativement à la fenêtre de la grille
                    customFrame.setLocationRelativeTo(ButtonGridFrame.this);
                    customFrame.setVisible(true);
                });
            }
            add(button);
        }
        // Ajuster la taille de la fenêtre au contenu et configurer la fermeture
        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
