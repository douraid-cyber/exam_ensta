import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

class paint extends JPanel {

    private Color currentColor = Color.BLACK;  
    private float strokeWidth = 2.0f;          
    private boolean isDashed = false;          

    private List<Trace> allTraces = new ArrayList<>(); 

    private JComboBox<String> colorComboBox;    
    private JComboBox<String> strokeComboBox;   
    private JComboBox<Integer> widthComboBox;   

    public paint() {
        setBackground(Color.WHITE); 
        setPreferredSize(new Dimension(300, 300)); 

        // Création des listes déroulantes
        String[] colors = {"Black", "Red", "Blue", "Green", "Yellow"};
        colorComboBox = new JComboBox<>(colors);
        colorComboBox.addActionListener(e -> updateColor());

        String[] strokes = {"Solid", "Dashed"};
        strokeComboBox = new JComboBox<>(strokes);
        strokeComboBox.addActionListener(e -> updateStrokeStyle());

        Integer[] widths = {1, 2, 3, 4, 5};
        widthComboBox = new JComboBox<>(widths);
        widthComboBox.addActionListener(e -> updateWidth());

        // Création du bouton Effacer
        JButton clearButton = new JButton("Effacer");
        clearButton.addActionListener(e -> clearDrawing());

        // Panneau de contrôles
        JPanel controlsPanel = new JPanel();
        controlsPanel.setLayout(new FlowLayout());
        controlsPanel.add(new JLabel("Color:"));
        controlsPanel.add(colorComboBox);
        controlsPanel.add(new JLabel("Stroke:"));
        controlsPanel.add(strokeComboBox);
        controlsPanel.add(new JLabel("Width:"));
        controlsPanel.add(widthComboBox);
        controlsPanel.add(clearButton);  // Ajout du bouton Effacer

        setLayout(new BorderLayout());
        add(controlsPanel, BorderLayout.NORTH);

        // Ajout des écouteurs de souris
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                allTraces.add(new Trace(currentColor, strokeWidth, isDashed));
                allTraces.get(allTraces.size() - 1).addPoint(e.getPoint());
                repaint();
            }
        });
        addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                allTraces.get(allTraces.size() - 1).addPoint(e.getPoint());
                repaint();
            }
        });
    }

    // Méthode pour effacer le dessin
    private void clearDrawing() {
        allTraces.clear();
        repaint();
    }

    private void updateColor() {
        String selectedColor = (String) colorComboBox.getSelectedItem();
        switch (selectedColor) {
            case "Red": currentColor = Color.RED; break;
            case "Blue": currentColor = Color.BLUE; break;
            case "Green": currentColor = Color.GREEN; break;
            case "Yellow": currentColor = Color.YELLOW; break;
            default: currentColor = Color.BLACK;
        }
    }

    private void updateStrokeStyle() {
        isDashed = "Dashed".equals(strokeComboBox.getSelectedItem());
    }

    private void updateWidth() {
        strokeWidth = (Integer) widthComboBox.getSelectedItem();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        for (Trace trace : allTraces) {
            g2d.setColor(trace.color);
            if (trace.isDashed) {
                float[] dashPattern = {10.0f};
                g2d.setStroke(new BasicStroke(trace.width, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, dashPattern, 0.0f));
            } else {
                g2d.setStroke(new BasicStroke(trace.width));
            }

            for (int i = 1; i < trace.points.size(); i++) {
                Point p1 = trace.points.get(i - 1);
                Point p2 = trace.points.get(i);
                g2d.drawLine(p1.x, p1.y, p2.x, p2.y);
            }
        }
    }

    private static class Trace {
        Color color;
        float width;
        boolean isDashed;
        List<Point> points;

        public Trace(Color color, float width, boolean isDashed) {
            this.color = color;
            this.width = width;
            this.isDashed = isDashed;
            this.points = new ArrayList<>();
        }

        public void addPoint(Point p) {
            points.add(p);
        }
    }
}
