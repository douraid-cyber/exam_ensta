import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class BE {
    public static void main(String[] args) {

        // Créer la fenêtre principale
        JFrame frame = new JFrame("BE");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 600);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout(15, 15));  

        JTabbedPane tabbedPane = new JTabbedPane();

        JPanel tab1 = new JPanel();
        tab1.setLayout(new BorderLayout(15, 15));  

        ButtonClass buttonPanel = new ButtonClass();

        empti1 bluePanel = new empti1();

        empti2 greenPanel = new empti2();

        text textAreaZone = new text();
        textAreaZone.setPreferredSize(new Dimension(frame.getWidth(), 100));

        paint paintPanel = new paint();


        tab1.add(buttonPanel, BorderLayout.NORTH);  
        tab1.add(greenPanel, BorderLayout.EAST);    
        tab1.add(bluePanel, BorderLayout.WEST);     
        tab1.add(textAreaZone, BorderLayout.SOUTH); 
        tab1.add(paintPanel, BorderLayout.CENTER);  


        JPanel tab2 = new JPanel();
        tab2.setLayout(new BorderLayout());  
        
        
        onglet2 onglet2 = new onglet2();
        
        tab2.add(onglet2, BorderLayout.CENTER);

        tabbedPane.addTab("Onglet 1", tab1);
        tabbedPane.addTab("Onglet 2", tab2);

        frame.add(tabbedPane, BorderLayout.CENTER);

        frame.setVisible(true);
    }
}
