
import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JPanel;

public class onglet2 extends JPanel {
    public onglet2() {
        setLayout(new GridLayout(10, 10));
       
        for (int i = 1; i <= 100; i++) {
            JButton button = new JButton("Btn " + i);
            if (i == 22) {
                button.addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseEntered(java.awt.event.MouseEvent evt) { button.setBackground(Color.RED);}
                    public void mouseExited(java.awt.event.MouseEvent evt) { button.setBackground(null); }
                });
                button.addActionListener(e -> new NewInterface());
            }
            add(button);
        }
    }
}
