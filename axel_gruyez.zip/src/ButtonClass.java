import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class ButtonClass extends JPanel {

    private JButton button1, button2, button3;
    private Point mousePressedPoint;
    private JButton currentButton;
    private boolean isDragging = false; 

    public ButtonClass() {
        setPreferredSize(new Dimension(400, 100));
        setLayout(null);

        button1 = new JButton("Button 1");
        button2 = new JButton("Button 2");
        button3 = new JButton("Button 3");

        button1.setBounds(50, 50, 100, 30);
        button2.setBounds(200, 50, 100, 30);
        button3.setBounds(350, 50, 100, 30);

        add(button1);
        add(button2);
        add(button3);

        MouseAdapter mouseAdapter = new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (e.getSource() instanceof JButton) {
                    currentButton = (JButton) e.getSource();
                    mousePressedPoint = e.getPoint();
                    isDragging = false;
                }
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                if (currentButton != null) {
                    isDragging = true; 
                    int dx = e.getX() - mousePressedPoint.x;
                    int dy = e.getY() - mousePressedPoint.y;

                    int newX = Math.min(Math.max(currentButton.getX() + dx, 0), getWidth() - currentButton.getWidth());
                    int newY = Math.min(Math.max(currentButton.getY() + dy, 0), getHeight() - currentButton.getHeight());

                    currentButton.setLocation(newX, newY);
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if (!isDragging && currentButton != null) {
                    currentButton.doClick(); 
                }
                currentButton = null;
            }
        };

        button1.addMouseListener(mouseAdapter);
        button1.addMouseMotionListener(mouseAdapter);
        button2.addMouseListener(mouseAdapter);
        button2.addMouseMotionListener(mouseAdapter);
        button3.addMouseListener(mouseAdapter);
        button3.addMouseMotionListener(mouseAdapter);

        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isDragging) return; // Annule l'action si drag détecté

                JFrame inputFrame = new JFrame("Saisie des informations");
                inputFrame.setSize(300, 250);
                inputFrame.setLocationRelativeTo(null);
                inputFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                JPanel panel = new JPanel();
                panel.setLayout(new GridLayout(5, 2));

                JLabel nameLabel = new JLabel("Nom:");
                JTextField nameField = new JTextField();
                JLabel lastNameLabel = new JLabel("Prénom:");
                JTextField lastNameField = new JTextField();
                JLabel ageLabel = new JLabel("Age:");
                JTextField ageField = new JTextField();
                JLabel schoolLabel = new JLabel("Ecole:");
                JTextField schoolField = new JTextField();

                panel.add(nameLabel);
                panel.add(nameField);
                panel.add(lastNameLabel);
                panel.add(lastNameField);
                panel.add(ageLabel);
                panel.add(ageField);
                panel.add(schoolLabel);
                panel.add(schoolField);

                JButton okButton = new JButton("OK");
                panel.add(okButton);

                JLabel infoLabel = new JLabel("");
                panel.add(infoLabel);

                okButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String name = nameField.getText();
                        String lastName = lastNameField.getText();
                        String age = ageField.getText();
                        String school = schoolField.getText();
                        infoLabel.setText("[" + name + ", " + lastName + ", " + age + ", " + school + "]");
                    }
                });

                inputFrame.add(panel);
                inputFrame.setVisible(true);
            }
        });

        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isDragging) return; 

                JFrame circularFrame = new JFrame();
                circularFrame.setUndecorated(true);
                circularFrame.setSize(300, 300);
                circularFrame.setLocationRelativeTo(null);

                JPanel panel = new JPanel();
                panel.setLayout(null);
                circularFrame.setContentPane(panel);

                panel.setBounds(0, 0, 300, 300);
                panel.setBackground(Color.RED);

                JButton closeButton = new JButton("Fermer");
                closeButton.setBounds(100, 220, 100, 30);
                closeButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        circularFrame.dispose();
                    }
                });
                panel.add(closeButton);

                JSlider colorSlider = new JSlider(0, 255, 0);
                colorSlider.setBounds(50, 150, 200, 40);
                colorSlider.addChangeListener(new ChangeListener() {
                    @Override
                    public void stateChanged(ChangeEvent e) {
                        int value = colorSlider.getValue();
                        panel.setBackground(new Color(value, 0, 0));
                    }
                });
                panel.add(colorSlider);

                circularFrame.setShape(new java.awt.geom.Ellipse2D.Double(0, 0, 300, 300));
                circularFrame.setVisible(true);
            }
        });
    }
}
