import javax.swing.*;
import java.awt.*;

public class empti1 extends JPanel {

    public empti1() {
    	setPreferredSize(new Dimension(100, 300));

        setBackground(Color.BLUE);
    }
}
