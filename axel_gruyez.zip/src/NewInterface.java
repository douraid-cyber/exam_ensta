import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class NewInterface {

    public NewInterface() {
        // Créer la nouvelle fenêtre (newFrame)
        JFrame newFrame = new JFrame("Nouvelle Interface");
        newFrame.setSize(400, 300);
        newFrame.setLocationRelativeTo(null); // Centrer la fenêtre à l'écran
        newFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        // Création d'un panneau avec un layout moderne et un dégradé de couleur
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                int width = getWidth();
                int height = getHeight();
                Color color1 = new Color(44, 62, 80); // Bleu foncé
                Color color2 = new Color(52, 152, 219); // Bleu clair
                GradientPaint gp = new GradientPaint(0, 0, color1, width, height, color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, width, height);
            }
        };
        panel.setLayout(new GridBagLayout());
        
        // Bouton stylisé
        JButton closeButton = new JButton("Fermer");
        closeButton.setPreferredSize(new Dimension(120, 40));
        closeButton.setBackground(new Color(231, 76, 60)); // Rouge
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        closeButton.setFont(new Font("Arial", Font.BOLD, 14));
        closeButton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        // Ajout de l'action de fermeture
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                newFrame.dispose();
            }
        });
        
        // Ajouter le bouton au panneau avec un placement centré
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(closeButton, gbc);
        
        // Ajouter le panneau à la fenêtre
        newFrame.add(panel);
        
        // Afficher la fenêtre
        newFrame.setVisible(true);
    }
}