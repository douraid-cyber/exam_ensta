import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class text extends JPanel {
    
    private JTextArea textArea; 
    private JScrollPane scrollPane;
    private JButton changeBgButton, changeTextColorButton;

    public text() {
        // Utilisation de BoxLayout pour une disposition verticale
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        // Créer une zone de texte avec une police par défaut
        textArea = new JTextArea("Zone de texte");
        
        // Créer une barre de défilement pour la zone de texte
        scrollPane = new JScrollPane(textArea);

        // Ajouter la barre de défilement au panneau
        add(scrollPane);

        // Créer un panneau pour les boutons
        JPanel buttonPanel = new JPanel();
        
        // Bouton pour changer la couleur de fond
        changeBgButton = new JButton("Change Background");
        changeBgButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Color newColor = JColorChooser.showDialog(null, "Choose Background Color", textArea.getBackground());
                if (newColor != null) {
                    textArea.setBackground(newColor);
                }
            }
        });
        
        // Bouton pour changer la couleur du texte
        changeTextColorButton = new JButton("Change Text Color");
        changeTextColorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Color newColor = JColorChooser.showDialog(null, "Choose Text Color", textArea.getForeground());
                if (newColor != null) {
                    textArea.setForeground(newColor);
                }
            }
        });

        // Ajouter les boutons au panneau de boutons
        buttonPanel.add(changeBgButton);
        buttonPanel.add(changeTextColorButton);
        
        // Ajouter le panneau de boutons au panneau principal
        add(buttonPanel);
    }
}
