import javax.swing.*;
import java.awt.*;

public class empti2 extends JPanel {

    public empti2() {
    	setPreferredSize(new Dimension(100, 300));

        setBackground(Color.GREEN);
    }
}
