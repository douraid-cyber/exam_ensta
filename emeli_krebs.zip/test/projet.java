package test;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTree;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;

public class projet {

	static int lastx, lasty; 
    static List<Line> lines = new ArrayList<>(); 
    static Color currentColor = Color.BLACK; 
    private static Color selectedColor = Color.BLACK;
    private static int currentWidth = 2;
    
    public static void main(String[] args) {

        JFrame frame = new JFrame("Test Emeli Krebs");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 700);
       
        
        ///////////////////////////////////////////////////////////////////

        JPanel general = new JPanel(); 
        general.setLayout(new BorderLayout(15, 15));
        
		// First Panel
        
		JPanel pan1 = new JPanel();
		pan1.setBackground(Color.magenta);
		pan1.add(new JLabel("Barre du haut"));
		
		// Second Panel
		
		JPanel pan2 = new JPanel();
		pan2.setBackground(Color.cyan);
		pan2.add(new JLabel("Barre du bas"));

        ///////////////////////////////////////////////////////////////////

        JPanel pan3 = new JPanel();
        pan3.setBackground(Color.white);
        pan3.setLayout(new BorderLayout());
        pan3.setPreferredSize(new Dimension(400, 0));

        
        JTextArea jta = new JTextArea("1. Sélectionnez d'abord une couleur ci-dessus "
        		+ "\n2. Dans le panneau ci-dessous, choisissez le composant ");
        
        JButton bgColorButton = new JButton("Couleur du background");
        JButton textColorButton = new JButton("Couleur du texte");
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(bgColorButton);
        buttonPanel.add(textColorButton);
        
        JScrollPane scrollPane = new JScrollPane(jta);
        
        JPanel colorPanel = new JPanel();
        colorPanel.setLayout(new GridLayout(2, 5, 5, 5));

        Color[] colors = {
            Color.BLACK, Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW,
            Color.ORANGE, Color.PINK, Color.CYAN, Color.MAGENTA, Color.WHITE
        };

        for (Color color : colors) {
            JButton button = new JButton();
            button.setBackground(color);
            button.setPreferredSize(new Dimension(40, 25));
            
            button.addActionListener(e -> selectedColor = color);
            
            colorPanel.add(button);
        }
        
        bgColorButton.addActionListener(e -> jta.setBackground(selectedColor));
        
        textColorButton.addActionListener(e -> jta.setForeground(selectedColor));
        
        pan3.add(colorPanel, BorderLayout.NORTH);
        pan3.add(buttonPanel, BorderLayout.SOUTH);
        pan3.add(scrollPane, BorderLayout.CENTER);
        
        ///////////////////////////////////////////////////////////////////

        JPanel pan4 = new JPanel();
        pan4.setLayout(null);
        pan4.setBackground(Color.LIGHT_GRAY);
        pan4.setPreferredSize(new Dimension(150, 0));

        JButton button1 = new JButton("Button 1");
        button1.setBounds(25, 50, 100, 30);
        
        JButton button2 = new JButton("Button 2");
        button2.setBounds(25, 100, 100, 30);

        JButton button3 = new JButton("Button 3");
        button3.setBounds(25, 150, 100, 30);
        
        button1.addMouseListener(new MouseAdapter() {
            int x, y;

            @Override
            public void mousePressed(MouseEvent e) {
                x = e.getX();
                y = e.getY();
            }
        });

        button1.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int newX = button1.getX() + e.getX() - button1.getWidth() / 2;
                int newY = button1.getY() + e.getY() - button1.getHeight() / 2;
                button1.setLocation(newX, newY);
            }
        });
        
        button1.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				
				button1 b1 = new button1();
				b1.setVisible(true);
				
			}
		});
        
        button2.addMouseListener(new MouseAdapter() {
            int x, y;

            @Override
            public void mousePressed(MouseEvent e) {
                x = e.getX();
                y = e.getY();
            }
        });

        button2.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int newX = button2.getX() + e.getX() - button2.getWidth() / 2;
                int newY = button2.getY() + e.getY() - button2.getHeight() / 2;
                button2.setLocation(newX, newY);
            }
        });
        

        button2.addMouseListener(new MouseAdapter() {
            int x, y;

            @Override
            public void mousePressed(MouseEvent e) {
                x = e.getX();
                y = e.getY();
            }
        });
        
        button2.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				
				button2 b2 = new button2();
				b2.setVisible(true);
				
			}
		});

        button3.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int newX = button3.getX() + e.getX() - button3.getWidth() / 2;
                int newY = button3.getY() + e.getY() - button3.getHeight() / 2;
                button3.setLocation(newX, newY);
            }
            
        });
        
        button3.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				
				button3 b3 = new button3();
				b3.setVisible(true);
				
			}
		});
        
        pan4.add(button1);
        pan4.add(button2);
        pan4.add(button3);


        ///////////////////////////////////////////////////////////////////

        JPanel pan5 = new JPanel();
        
        pan5.setBackground(Color.white);
        pan5.setLayout(new BorderLayout());

        JPanel pan51 = new JPanel();
        		
        JComboBox<String> colorBox , styleBox , widthBox;
        
        colorBox = new JComboBox<>(new String[]{"Black", "Red", "Blue", "Green"});
        
        colorBox.addActionListener(e -> {
            String selected = (String) colorBox.getSelectedItem();
            switch (selected) {
                case "Black":
                    currentColor = Color.BLACK;
                    break;
                case "Red":
                	currentColor = Color.RED;
                    break;
                case "Blue":
                	currentColor = Color.BLUE;
                    break;
                case "Green":
                	currentColor = Color.GREEN;
                    break;
            }
        });
        
        styleBox = new JComboBox<>(new String[]{"Continu", "Pointillé"});
        
        widthBox = new JComboBox<>(new String[]{"1", "3", "5", "7"});
        widthBox.addActionListener(e -> {
            String selectedWidth = (String) widthBox.getSelectedItem();
            currentWidth = Integer.parseInt(selectedWidth); 
        });
        
        pan51.add(new JLabel("Couleur:"));
        pan51.add(colorBox);
        pan51.add(new JLabel("Forme:"));
        pan51.add(styleBox);
        pan51.add(new JLabel("Largeur:"));
        pan51.add(widthBox);
        
        //Draw panel
        
        JPanel pan52 = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g); 
                Graphics2D g2d = (Graphics2D) g.create(); 
                g2d.setColor(currentColor);
                
                //quality
        		/*g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        		g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        		g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);*/
        		
        		//perf
        		/*g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        		g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
        		g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
*/
                
                String style = (String) styleBox.getSelectedItem();
                if ("Pointillé".equals(style)) {
                    float[] dashPattern = {5.0f, 50.0f}; 
                    g2d.setStroke(new BasicStroke(currentWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 10.0f, dashPattern, 0.0f));
                } else {
                    g2d.setStroke(new BasicStroke(currentWidth));
                }


               
                for (Line line : lines) {
                    g2d.setColor(line.color);
                    g2d.drawLine(line.x1, line.y1, line.x2, line.y2);
                }
                g2d.dispose();
            }
        };
        
        pan52.setBackground(Color.white); 

        pan52.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                lastx = e.getX(); 
                lasty = e.getY(); 
            }
        });

        pan52.addMouseMotionListener(new MouseMotionAdapter() {
        	
            @Override
            public void mouseDragged(MouseEvent e) {
            	
                int x = e.getX(); 
                int y = e.getY(); 

                lines.add(new Line(lastx, lasty, x, y, currentColor));

                lastx = x; 
                lasty = y; 

                pan52.repaint(); 
            }
        });
        
        
        pan5.add(pan51, BorderLayout.NORTH);
        pan5.add(pan52, BorderLayout.CENTER);
        
        
        ///////////////////////////////////////////////////////////////////

        general.add(pan1 , BorderLayout.NORTH);
        general.add(pan2, BorderLayout.SOUTH);
        general.add(pan3, BorderLayout.WEST);
        general.add(pan4, BorderLayout.EAST);
        general.add(pan5, BorderLayout.CENTER);
        
        ///////////////////////////////////////////////////////////////////
        
        
        JPanel libre = new JPanel();
        libre.setLayout(new GridLayout(10, 10, 5, 5)); 
        
        
        int i = 1;
        for (; i <= 100; i++) {
        	
            JButton button = new JButton(String.valueOf(i)); 
            
            int finalI = i; 
            button.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    if (finalI == 22) {
                        button.setBackground(Color.RED); 
                    }
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    if (finalI == 22) {
                        button.setBackground(null); 
                    }
                }

                @Override
                public void mouseClicked(MouseEvent e) {
                    if (finalI == 22) {
                        button.setBackground(Color.RED); 
                        libre blibre = new libre();
        				blibre.setVisible(true);
                    }
                }
            });
        
            libre.add(button); 
        }
        
        /////////////////////////////////////////////////////////////////////
        JTabbedPane jtpa = new JTabbedPane();
        
        jtpa.add("1", general);
        jtpa.add("2", libre);

        frame.add(jtpa);
        frame.setVisible(true);
    }
    
    static class Line {
        int x1, y1, x2, y2; 
        Color color; 

        Line(int x1, int y1, int x2, int y2, Color color) {
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
            this.color = color;
        }
    }
}
