package test;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class button3 extends JFrame{

	private static int mouseX;
	private static int mouseY;
	
	public button3()
	{
		setSize(1000,1000);
		setUndecorated(true);
		setLayout(null);
		setBackground(new Color(0, 0, 0, 0));
         
        
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen() - mouseX;
                int y = e.getYOnScreen() - mouseY;
                setLocation(x, y);
            }
        });
        
        addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen() - mouseX;
                int y = e.getYOnScreen() - mouseY;
                setLocation(x, y);
            }
        });

        JButton butExit = new JButton("");
        butExit.setBounds(150, 150, 30, 30);  
   

        butExit.setMargin(new Insets(0, 0, 0, 0));
        
        butExit.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
            	butExit.setBackground(Color.RED);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                butExit.setBackground(Color.WHITE);
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                dispose(); 
            }
        });
        
        JButton butX = new JButton("X");
        butX.setBounds(80, 225, 30, 30);  
   

        butX.setMargin(new Insets(0, 0, 0, 0));
        
        butX.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
            	butX.setBackground(Color.CYAN);
            }

            @Override
            public void mouseExited(MouseEvent e) {
            	butX.setBackground(null);
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                dispose(); 
            }
        });
        
        JButton butO = new JButton("O");
        butO.setBounds(175, 125, 30, 30);  
   

        butO.setMargin(new Insets(0, 0, 0, 0));
        
        butO.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
            	butO.setBackground(Color.BLUE);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                butO.setBackground(null);
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                dispose(); 
            }
        });
        
        JButton butY = new JButton("Y");
        butY.setBounds(250, 50, 30, 30);  
   
        butY.setMargin(new Insets(0, 0, 0, 0));
        
        butY.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
            	butY.setBackground(Color.MAGENTA);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                butY.setBackground(null);
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                dispose(); 
            }
        });
        
        add(butY);
        add(butO);
        add(butX);
        add(butExit);
    
    }
    
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        
        g2d.setColor(Color.GRAY); 
        g2d.fillOval(50, 200, 100, 100); 
        g2d.fillOval(150, 70, 100, 100); 
        g2d.fillOval(200, 20, 100,100); 
        g2d.fillRect(80, 120, 120, 120); 
        
        g2d.setColor(Color.WHITE);
        g2d.fillOval(120, 160, 50,50); 

        setShape(g2d.getClip()); 
    }
}