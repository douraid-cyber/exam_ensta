package test;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

import javax.swing.JButton;
import javax.swing.JFrame;

public class libre extends JFrame{

	private static int mouseX;
	private static int mouseY;
	
	public libre()
	{
		setSize(400,200);
		setUndecorated(true);
		setLayout(null);
		setBackground(new Color(0, 0, 0, 0));
		
		addMouseListener(new MouseAdapter() {
		
			@Override
			public void mouseDragged(MouseEvent e) 
			{
				int x = e.getXOnScreen() - mouseX;
				int y = e.getYOnScreen() - mouseY;
				setLocation(x,y);
				
			}
			
		});
		
		addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen() - mouseX;
                int y = e.getYOnScreen() - mouseY;
                setLocation(x, y);
            }
        });

        // Botão para fechar a janela
		JButton butExit = new JButton("X");
		butExit.setBounds(315, 170, 20, 20);
		butExit.setBackground(Color.red);
		//butExit.setBackground(new Color(255, 0, 0));
		butExit.setBorderPainted(false);
		butExit.setFocusPainted(false);
		butExit.setForeground(Color.white);
		butExit.setMargin(new Insets(0, 0, 0, 0));
		
		butExit.addMouseListener(new MouseAdapter() {
			@Override
            public void mouseEntered(MouseEvent e) {
                butExit.setBackground(Color.DARK_GRAY);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                butExit.setBackground(Color.red);
            }
            @Override
            public void mouseClicked(MouseEvent e) {
                dispose();
            }
		});
		
		add(butExit);
		
	}
	
	@Override
	public void paint(Graphics g)
	{
		super.paint(g);
		Graphics2D g2d = (Graphics2D) g;
		
		//quality
		/*g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);*/
		
		//perf
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
		g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
		g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
		
		// Criando um polígono
		int[] xpoints = {500,700,350,200,50,50};
		int[] ypoints = {50,150,200,200,200,150};
		
		Polygon poly = new Polygon(xpoints, ypoints, ypoints.length);
		
		//g2d.setColor(Color.blue);
		
		GradientPaint gradient = new GradientPaint(0, 0, Color.pink, 500,150, Color.orange);
		g2d.setPaint(gradient);
		g2d.fill(poly);
		
		setShape(poly);
	}
}
