package test;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class button1 extends JFrame{
	
	private static int mouseX;
	private static int mouseY;

	public button1() {
		
		setTitle("Forms");
		setUndecorated(true);
		setSize(400,300);
		setLayout(null);
		
		JLabel lblNom = new JLabel("Nom:");
        lblNom.setBounds(30, 30, 100, 30);
        JTextField tfNom = new JTextField();
        tfNom.setBounds(150, 30, 200, 30);

        JLabel lblPrenom = new JLabel("Prénom:");
        lblPrenom.setBounds(30, 70, 100, 30);
        JTextField tfPrenom = new JTextField();
        tfPrenom.setBounds(150, 70, 200, 30);

        JLabel lblAge = new JLabel("Age:");
        lblAge.setBounds(30, 110, 100, 30);
        JTextField tfAge = new JTextField();
        tfAge.setBounds(150, 110, 200, 30);

        JLabel lblEcole = new JLabel("Ecole:");
        lblEcole.setBounds(30, 150, 100, 30);
        JTextField tfEcole = new JTextField();
        tfEcole.setBounds(150, 150, 200, 30);

        JButton btnOK = new JButton("OK");
        btnOK.setBounds(150, 190, 100, 30);
        JLabel resultLabel = new JLabel();
        resultLabel.setBounds(30, 230, 350, 30);
        

        btnOK.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				
				 String nom = tfNom.getText();
	             String prenom = tfPrenom.getText();
	             String age = tfAge.getText();
	             String ecole = tfEcole.getText();
	             resultLabel.setText("[" + nom + ", " + prenom + ", " + age + ", " + ecole + "]");
				
			}
		});
		
		JButton butExit = new JButton("X");
		butExit.setBounds(350, 250, 20, 20);
		butExit.setBackground(Color.red);
		//butExit.setBackground(new Color(255, 0, 0));
		butExit.setBorderPainted(false);
		butExit.setFocusPainted(false);
		butExit.setForeground(Color.white);
		butExit.setMargin(new Insets(0, 0, 0, 0));
		
		butExit.addMouseListener(new MouseAdapter() {
			@Override
            public void mouseEntered(MouseEvent e) {
                butExit.setBackground(Color.DARK_GRAY);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                butExit.setBackground(Color.red);
            }
            @Override
            public void mouseClicked(MouseEvent e) {
                dispose();
            }
		});
		
		addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseDragged(MouseEvent e) 
			{
				int x = e.getXOnScreen() - mouseX;
				int y = e.getYOnScreen() - mouseY;
				setLocation(x,y);
				
			}
			
		});
		
		addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen() - mouseX;
                int y = e.getYOnScreen() - mouseY;
                setLocation(x, y);
            }
        });
		
		add(lblNom);
        add(tfNom);
        add(lblPrenom);
        add(tfPrenom);
        add(lblAge);
        add(tfAge);
        add(lblEcole);
        add(tfEcole);
        add(btnOK);
        add(resultLabel);
		add(butExit);
		
	}
	
	/*@Override
    public void paint(Graphics g) {
        super.paint(g);
        
       
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(Graphics2D.KEY_ANTIALIASING, Graphics2D.VALUE_ANTIALIAS_ON);
        g2d.setColor(Color.white);  // Cor do fundo arredondado
        g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);  // Desenha o fundo arredondado

        setShape(g2d.getClip()); // Define a forma da janela como a área do fundo arredondado
    }*/

	
}
