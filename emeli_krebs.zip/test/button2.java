package test;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class button2 extends JFrame {
    
    private static int mouseX;
    private static int mouseY;
    private JSlider slider;
    private Color ovalColor = new Color(0, 0, 255, 128); // Cor inicial do oval

    
    public button2() { 
        setSize(400, 400); 
        setUndecorated(true); 
        setLayout(null);
        setBackground(new Color(0, 0, 0, 0)); 
        
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen() - mouseX;
                int y = e.getYOnScreen() - mouseY;
                setLocation(x, y);
            }
        });
        
        addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen() - mouseX;
                int y = e.getYOnScreen() - mouseY;
                setLocation(x, y);
            }
        });

        JButton butExit = new JButton("X");
        butExit.setBounds(175, 50, 40, 40); 
        butExit.setBackground(Color.red);
        butExit.setBorderPainted(false);
        butExit.setFocusPainted(false);
        butExit.setForeground(Color.white);
        butExit.setMargin(new Insets(0, 0, 0, 0));
        
        butExit.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                butExit.setBackground(Color.DARK_GRAY);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                butExit.setBackground(Color.red);
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                dispose(); 
            }
        });
        
        
        slider = new JSlider(0, 255, 128);
        slider.setBounds(50, 150, 300, 50);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);
        
        slider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                int colorValue = slider.getValue();
                ovalColor = new Color(colorValue, 0, 255, 128); 
                repaint(); 
            }
        });
        
        add(slider);
        add(butExit);
    
    }
    
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        
        g2d.setColor(ovalColor); 
        g2d.fillOval(50, 50, 300, 300); 

        setShape(g2d.getClip()); 
    }
}
