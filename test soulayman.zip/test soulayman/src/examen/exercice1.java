package examen;

import java.awt.BorderLayout;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.awt.event.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class exercice1 {
    // Coordonnées de la dernière position pour le dessin
    static int lastx;
    static int lasty;
    // Liste des lignes dessinées, chaque ligne est représentée par un objet Line
    static List<Line> lines = new ArrayList<>();
    
    // Attributs actuels pour le dessin : couleur, style (dotted ou non) et largeur
    static Color currentColor = Color.BLACK;
    static boolean currentDotted = false;
    static int currentWidth = 1;
    
    public static void main(String[] args) {
        // Création de la fenêtre principale
        JFrame frame = new JFrame("C'est ma fenêtre!");
        frame.setSize(1500, 800);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Utilisation d'un BorderLayout avec des marges de 15 pixels
        frame.setLayout(new BorderLayout(15,15));
        
        // -----------------------
        // Création du panel Nord (Top)
        // -----------------------
        JPanel panel1 = new JPanel();
        panel1.setBackground(Color.red);
        panel1.add(new JLabel("barre du haut")); // Affiche "barre du haut" en haut de la fenêtre
        
        // -----------------------
        // Création du panel Sud (Bottom)
        // -----------------------
        JPanel panel2 = new JPanel();
        panel2.setBackground(Color.green);
        panel2.add(new JLabel("barre du bas")); // Affiche "barre du bas" en bas de la fenêtre
        
        // -----------------------
        // Création du panel Ouest (West) : zone dédiée aux boutons déplaçables
        // -----------------------
        JPanel panel3 = new JPanel();
        panel3.setBackground(Color.blue);
        panel3.setLayout(null); // Utilisation d'un layout absolu pour le glisser-déposer
        // Définir une taille préférée pour que le panel soit visible
        panel3.setPreferredSize(new Dimension(150, 600));
        
        // Création de trois boutons déplaçables avec leurs actions respectives
        DraggableButton button1 = new DraggableButton("Bouton 1");
        // Action du bouton 1 : ouvre une fenêtre de dialogue avec un formulaire
        button1.addActionListener(e -> {
            // Création d'une fenêtre de dialogue sans décoration et avec des bords arrondis
            JDialog dialog = new JDialog(frame, "Formulaire", true);
            dialog.setUndecorated(true);
            int dialogWidth = 300;
            int dialogHeight = 300;
            dialog.setSize(dialogWidth, dialogHeight);
            // Définir la forme arrondie du dialogue
            dialog.setShape(new RoundRectangle2D.Double(0, 0, dialogWidth, dialogHeight, 30, 30));
            dialog.setLocationRelativeTo(frame);

            // Panel principal du formulaire
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

            // Création des champs de saisie
            JTextField nomField = new JTextField();
            JTextField prenomField = new JTextField();
            JTextField ageField = new JTextField();
            JTextField ecoleField = new JTextField();

            // Ajout des labels et champs dans le panel
            panel.add(new JLabel("Nom:"));
            panel.add(nomField);
            panel.add(Box.createVerticalStrut(5));
            panel.add(new JLabel("Prénom:"));
            panel.add(prenomField);
            panel.add(Box.createVerticalStrut(5));
            panel.add(new JLabel("Age:"));
            panel.add(ageField);
            panel.add(Box.createVerticalStrut(5));
            panel.add(new JLabel("Ecole:"));
            panel.add(ecoleField);
            panel.add(Box.createVerticalStrut(10));

            // Label pour afficher le résultat du formulaire
            JLabel infoLabel = new JLabel(" ");
            panel.add(infoLabel);
            panel.add(Box.createVerticalStrut(10));

            // Panel pour les boutons "OK" et "Fermer"
            JPanel buttonsPanel = new JPanel();
            JButton okButton = new JButton("OK");
            JButton closeButton = new JButton("Fermer");
            buttonsPanel.add(okButton);
            buttonsPanel.add(closeButton);
            panel.add(buttonsPanel);

            // Action du bouton OK : affiche les informations saisies dans le label
            okButton.addActionListener(ae -> {
                String nom = nomField.getText();
                String prenom = prenomField.getText();
                String age = ageField.getText();
                String ecole = ecoleField.getText();
                String info = "[" + nom + ", " + prenom + ", " + age + ", " + ecole + "]";
                infoLabel.setText(info);
            });

            // Action du bouton Fermer : ferme la fenêtre de dialogue
            closeButton.addActionListener(ae -> dialog.dispose());

            dialog.add(panel);
            dialog.setVisible(true);
        });
        
        DraggableButton button2 = new DraggableButton("Bouton 2");
        // Action du bouton 2 : ouvre une fenêtre de dialogue circulaire
        button2.addActionListener(e -> {
            // Création d'une fenêtre de dialogue circulaire sans décoration
            JDialog dialog = new JDialog(frame, "Circular Window", true);
            dialog.setUndecorated(true);
            int diameter = 500;
            dialog.setSize(diameter, diameter);
            dialog.setLocationRelativeTo(frame);

            // Définir la forme circulaire (ellipse de même largeur et hauteur)
            dialog.setShape(new Ellipse2D.Double(0, 0, diameter, diameter));

            // Création d'un panel circulaire personnalisé avec une couleur de fond initiale
            CircularPanel circularPanel = new CircularPanel(new Color(100, 100, 100, 255));
            circularPanel.setLayout(new BorderLayout());

            // Bouton Fermer en haut
            JButton closeButton = new JButton("Fermer");
            closeButton.addActionListener(ev -> dialog.dispose());
            circularPanel.add(closeButton, BorderLayout.NORTH);

            // Slider au centre
            JSlider slider = new JSlider(0, 255, 100);
            slider.setMajorTickSpacing(50);
            slider.setMinorTickSpacing(10);
            slider.setPaintTicks(true);
            slider.setPaintLabels(true);
            circularPanel.add(slider, BorderLayout.CENTER);

            // Panel de cases à cocher en bas
            JPanel checkBoxPanel = new JPanel(new FlowLayout());
            checkBoxPanel.setOpaque(false);
            JCheckBox checkR = new JCheckBox("R");
            JCheckBox checkG = new JCheckBox("G");
            JCheckBox checkB = new JCheckBox("B");
            JCheckBox checkAlpha = new JCheckBox("Alpha");
            checkR.setOpaque(false);
            checkG.setOpaque(false);
            checkB.setOpaque(false);
            checkAlpha.setOpaque(false);
            checkBoxPanel.add(checkR);
            checkBoxPanel.add(checkG);
            checkBoxPanel.add(checkB);
            checkBoxPanel.add(checkAlpha);
            circularPanel.add(checkBoxPanel, BorderLayout.SOUTH);

            // Listener du slider pour mettre à jour la couleur de fond du panel circulaire
            slider.addChangeListener(new ChangeListener() {
                @Override
                public void stateChanged(ChangeEvent e) {
                    int value = slider.getValue();
                    Color current = circularPanel.getBackground();
                    int r, g, b, a;
                    if (!checkR.isSelected() && !checkG.isSelected() 
                            && !checkB.isSelected() && !checkAlpha.isSelected()) {
                        // Si aucune case n'est cochée, mettre à jour RGB de manière uniforme (alpha fixe à 255)
                        r = value;
                        g = value;
                        b = value;
                        a = 255;
                    } else {
                        r = checkR.isSelected() ? value : current.getRed();
                        g = checkG.isSelected() ? value : current.getGreen();
                        b = checkB.isSelected() ? value : current.getBlue();
                        a = checkAlpha.isSelected() ? value : current.getAlpha();
                    }
                    Color newColor = new Color(r, g, b, a);
                    circularPanel.setBackground(newColor);
                    circularPanel.repaint();
                }
            });

            dialog.setContentPane(circularPanel);
            dialog.setVisible(true);
        });
        
        DraggableButton button3 = new DraggableButton("Bouton 3");
        // Action du bouton 3 : ouvre une nouvelle fenêtre complexe
        button3.addMouseListener(new MouseListener() {	
            @Override
            public void mouseReleased(MouseEvent e) { }
            @Override
            public void mousePressed(MouseEvent e) { }
            @Override
            public void mouseExited(MouseEvent e) { }
            @Override
            public void mouseEntered(MouseEvent e) { }
            @Override
            public void mouseClicked(MouseEvent e) {
                FrameComplex newframe = new FrameComplex();
                newframe.setVisible(true);
            }
        });
        
        // Positionnement initial des boutons dans le panel Ouest
        button1.setBounds(10, 10, 100, 30);
        button2.setBounds(10, 50, 100, 30);
        button3.setBounds(10, 90, 100, 30);
        
        panel3.add(button1);
        panel3.add(button2);
        panel3.add(button3);
        
        // -----------------------
        // Création du panel Est (East) : zone d'édition de texte
        // -----------------------
        JPanel panel4 = new JPanel(new BorderLayout(10, 10));
        panel4.setBackground(new Color(240, 240, 240)); // Fond gris clair
        
        // Zone d'édition de texte
        JTextArea text1 = new JTextArea(10, 10);
        text1.setBackground(Color.white);
        text1.setFont(new Font("Arial", Font.PLAIN, 14));
        JScrollPane scroll = new JScrollPane(text1);
        
        // Barre d'outils pour changer la couleur de fond et la couleur du texte
        JPanel textToolbar = new JPanel();
        String[] bgColors = {"White", "Yellow", "Light Gray"};
        JComboBox<String> bgColorBox = new JComboBox<>(bgColors);
        bgColorBox.addActionListener(e -> {
            String selected = (String) bgColorBox.getSelectedItem();
            switch (selected) {
                case "Yellow": text1.setBackground(Color.YELLOW); break;
                case "Light Gray": text1.setBackground(Color.LIGHT_GRAY); break;
                default: text1.setBackground(Color.WHITE); break;
            }
        });
        textToolbar.add(new JLabel("Fond:"));
        textToolbar.add(bgColorBox);
        
        String[] textColors = {"Black", "Red", "Blue", "Green"};
        JComboBox<String> textColorBox = new JComboBox<>(textColors);
        textColorBox.addActionListener(e -> {
            String selected = (String) textColorBox.getSelectedItem();
            switch (selected) {
                case "Red": text1.setForeground(Color.RED); break;
                case "Blue": text1.setForeground(Color.BLUE); break;
                case "Green": text1.setForeground(Color.GREEN); break;
                default: text1.setForeground(Color.BLACK); break;
            }
        });
        textToolbar.add(new JLabel("Texte:"));
        textToolbar.add(textColorBox);
        
        // Ajout de la barre d'outils et de la zone d'édition au panel Est
        panel4.add(textToolbar, BorderLayout.NORTH);
        panel4.add(scroll, BorderLayout.CENTER);
        panel4.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(180, 180, 180), 2),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        // -----------------------
        // Création du container central pour le dessin
        // -----------------------
        JPanel centerContainer = new JPanel(new BorderLayout());
        
        // Barre d'outils pour changer les attributs du trait
        JPanel drawingToolbar = new JPanel();
        String[] colors = {"Black", "Red", "Blue", "Green"};
        JComboBox<String> colorBox = new JComboBox<>(colors);
        colorBox.addActionListener(e -> {
            String selected = (String) colorBox.getSelectedItem();
            switch (selected) {
                case "Red": currentColor = Color.RED; break;
                case "Blue": currentColor = Color.BLUE; break;
                case "Green": currentColor = Color.GREEN; break;
                default: currentColor = Color.BLACK; break;
            }
        });
        drawingToolbar.add(new JLabel("Couleur du trait:"));
        drawingToolbar.add(colorBox);
        
        String[] styles = {"Continu", "Pointillé"};
        JComboBox<String> styleBox = new JComboBox<>(styles);
        styleBox.addActionListener(e -> {
            String selected = (String) styleBox.getSelectedItem();
            currentDotted = selected.equals("Pointillé");
        });
        drawingToolbar.add(new JLabel("Style:"));
        drawingToolbar.add(styleBox);
        
        Integer[] widths = {1, 2, 3, 4, 5};
        JComboBox<Integer> widthBox = new JComboBox<>(widths);
        widthBox.addActionListener(e -> currentWidth = (Integer) widthBox.getSelectedItem());
        drawingToolbar.add(new JLabel("Largeur:"));
        drawingToolbar.add(widthBox);
        
        centerContainer.add(drawingToolbar, BorderLayout.NORTH);
        
        // Panneau de dessin personnalisé
        JPanel drawingPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D graphics2d = (Graphics2D) g.create();
                // Itération sur chaque ligne pour les redessiner
                for (Line line : lines) {
                    graphics2d.setColor(line.color);
                    if (line.dotted) {
                        float[] dash = {5.0f};
                        graphics2d.setStroke(new BasicStroke(line.width, BasicStroke.CAP_BUTT, 
                                BasicStroke.JOIN_BEVEL, 0, dash, 0));
                    } else {
                        graphics2d.setStroke(new BasicStroke(line.width));
                    }
                    graphics2d.drawLine(line.x1, line.y1, line.x2, line.y2);
                }
                graphics2d.dispose();
            }
        };
        drawingPanel.setBackground(Color.white);
        
        // Gestion des événements de la souris pour dessiner
        drawingPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                lastx = e.getX();
                lasty = e.getY();
            }
        });
        drawingPanel.addMouseMotionListener(new MouseMotionListener() {
            @Override
            public void mouseMoved(MouseEvent e) { }
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                // Ajoute une nouvelle ligne avec les attributs actuels
                lines.add(new Line(lastx, lasty, x, y, currentColor, currentDotted, currentWidth));
                lastx = x;
                lasty = y;
                drawingPanel.repaint();
            }
        });
        drawingPanel.setFocusable(true);
        drawingPanel.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) { }
            @Override
            public void keyReleased(KeyEvent e) { }
            @Override
            public void keyPressed(KeyEvent e) {
                // Gestion de Ctrl+Z pour annuler la dernière action
                if (e.isControlDown() && e.getKeyCode() == KeyEvent.VK_Z) {
                    if (!lines.isEmpty()) {
                        lines.remove(lines.size()-1);
                        drawingPanel.repaint();
                    }
                }
            }
        });
        
        // Bouton pour effacer le dessin
        JButton butclear = new JButton("clear");
        butclear.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                lines.clear();
                drawingPanel.repaint();
            }
        });
        
        centerContainer.add(drawingPanel, BorderLayout.CENTER);
        centerContainer.add(butclear, BorderLayout.SOUTH);
        
        // -----------------------
        // Création d'un JTabbedPane pour contenir deux onglets
        // -----------------------
        JTabbedPane tabbedPane = new JTabbedPane();
        // Premier onglet : interface de dessin existante
        tabbedPane.addTab("Dessin", centerContainer);
        
        // Deuxième onglet : panneau avec 100 boutons disposés en grille
        JPanel buttonsPanel = new JPanel(new GridLayout(10, 10, 5, 5));
        for (int i = 1; i <= 100; i++) {
            JButton btn = new JButton("Bouton " + i);
            // Pour le 22ème bouton, ajouter un effet au survol pour le rendre rouge
            if (i == 22) {
                btn.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseEntered(MouseEvent e) {
                        btn.setBackground(Color.RED);
                        btn.setOpaque(true);
                    }
                    @Override
                    public void mouseExited(MouseEvent e) {
                        btn.setBackground(null);
                        btn.setOpaque(false);
                    }
                    // Action au clic sur le 22ème bouton : ouvrir une nouvelle fenêtre (framepoly2)
                    @Override 
                    public void mouseClicked(MouseEvent e) {
                        framepoly2 framepoly2 = new framepoly2();
                        framepoly2.setVisible(true);
                    }
                });
            }
            buttonsPanel.add(btn);
        }
        tabbedPane.addTab("Boutons", buttonsPanel);
        
        // -----------------------
        // Ajout des panels dans la fenêtre principale
        // -----------------------
        frame.add(panel1, BorderLayout.NORTH);   // Barre du haut
        frame.add(panel2, BorderLayout.SOUTH);   // Barre du bas
        frame.add(panel3, BorderLayout.WEST);      // Boutons déplaçables
        frame.add(panel4, BorderLayout.EAST);      // Zone d'édition de texte
        // Remplacement du container central par le JTabbedPane
        frame.add(tabbedPane, BorderLayout.CENTER);
        
        frame.setVisible(true);
    }
    
    // Classe représentant une ligne dessinée avec ses attributs
    static class Line {
        int x1, y1, x2, y2;
        Color color;
        boolean dotted;
        int width;
        
        public Line(int x1, int y1, int x2, int y2, Color color, boolean dotted, int width) {
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
            this.color = color;
            this.dotted = dotted;
            this.width = width;
        }
    }
    
    // Classe pour un bouton déplaçable, qui ne peut se déplacer que dans son parent
    static class DraggableButton extends JButton {
        private int offsetX, offsetY;
        
        public DraggableButton(String text) {
            super(text);
            // Enregistrer la position initiale lors de l'appui de la souris
            addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    offsetX = e.getX();
                    offsetY = e.getY();
                }
            });
            // Déplacement du bouton lors du glisser-déposer
            addMouseMotionListener(new MouseMotionAdapter() {
                @Override
                public void mouseDragged(MouseEvent e) {
                    int newX = getX() + e.getX() - offsetX;
                    int newY = getY() + e.getY() - offsetY;
                    Container parent = getParent();
                    if (parent != null) {
                        int parentWidth = parent.getWidth();
                        int parentHeight = parent.getHeight();
                        if (newX < 0) newX = 0;
                        if (newY < 0) newY = 0;
                        if (newX + getWidth() > parentWidth) newX = parentWidth - getWidth();
                        if (newY + getHeight() > parentHeight) newY = parentHeight - getHeight();
                    }
                    setLocation(newX, newY);
                }
            });
        }
    }
    
    // Classe pour un panneau circulaire personnalisé (utilisé dans le dialogue du bouton 2)
    static class CircularPanel extends JPanel {
        public CircularPanel(Color bgColor) {
            setBackground(bgColor);
            setOpaque(false); // Permet un dessin personnalisé du fond
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            // Activer l'anticrénelage pour une meilleure qualité graphique
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            g2.setColor(getBackground());
            // Dessiner un ovale rempli couvrant tout le panneau
            g2.fillOval(0, 0, getWidth(), getHeight());
            g2.dispose();
            super.paintComponent(g);
        }
    }
}
