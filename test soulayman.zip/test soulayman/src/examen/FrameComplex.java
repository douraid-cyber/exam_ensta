package examen;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class FrameComplex extends JFrame {

    // Variables statiques pour stocker la position de la souris lors du glissement
    private static int mouseX;
    private static int mouseY;
    
    // Constructeur de la fenêtre personnalisée
    public FrameComplex() {
        // Configuration de la fenêtre :
        // Taille de 400x400 pixels, sans décoration, avec un fond transparent et un layout absolu
        setSize(400, 400);
        setUndecorated(true);
        setLayout(null);
        // Le fond est transparent grâce à l'alpha (0)
        setBackground(new Color(0, 0, 0, 0));
        
        // Ajout d'un écouteur de souris pour récupérer la position initiale lors d'un clic
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
            }
        });
        
        // Ajout d'un écouteur de mouvement de souris pour permettre le déplacement de la fenêtre
        addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                // Calcul de la nouvelle position en soustrayant l'offset
                int x = e.getXOnScreen() - mouseX;
                int y = e.getYOnScreen() - mouseY;
                setLocation(x, y);
            }
        });
        
        // ----------------------------
        // Ajout du bouton "Dispose" personnalisé
        // ----------------------------
        // Ce bouton est dessiné sous forme de cercle avec un rectangle rouge à l'intérieur
        CircleButton btnDispose = new CircleButton();
        // Positionnement du bouton au centre de la zone carrée (centre à (200,200) pour une fenêtre de 400x400)
        // Pour un bouton de 40x40, on positionne son coin supérieur gauche à (180,180)
        btnDispose.setBounds(180, 180, 40, 40);
        // L'action consiste à fermer (dispose) la fenêtre
        btnDispose.addActionListener(e -> dispose());
        add(btnDispose);
        
        // ----------------------------
        // Ajout des boutons circulaires situés en haut et en bas à gauche
        // ----------------------------
        // Bouton Circle1 : positionné en haut à droite (centre à (350,50))
        JButton btnCircle1 = new JButton("1");
        // Pour un bouton de 40x40, le coin supérieur gauche est à (350 - 20, 50 - 20) = (330,30)
        btnCircle1.setBounds(350 - 20, 50 - 20, 40, 40);
        // Désactiver l'affichage de la bordure, du focus, du fond et du rollover pour un effet transparent
        btnCircle1.setBorderPainted(false);
        btnCircle1.setFocusPainted(false);
        btnCircle1.setContentAreaFilled(false);
        btnCircle1.setRolloverEnabled(false);
        btnCircle1.setOpaque(false);
        // Texte en blanc
        btnCircle1.setForeground(Color.WHITE);
        // L'action ferme la fenêtre
        btnCircle1.addActionListener(e -> dispose());
        add(btnCircle1);
        
        // Bouton Circle2 : positionné juste à côté du premier (centre à (380,50))
        JButton btnCircle2 = new JButton("2");
        // Coin supérieur gauche à (380 - 20, 50 - 20) = (360,30)
        btnCircle2.setBounds(380 - 20, 50 - 20, 40, 40);
        btnCircle2.setBorderPainted(false);
        btnCircle2.setFocusPainted(false);
        btnCircle2.setContentAreaFilled(false);
        btnCircle2.setRolloverEnabled(false);
        btnCircle2.setOpaque(false);
        btnCircle2.setForeground(Color.WHITE);
        btnCircle2.addActionListener(e -> dispose());
        add(btnCircle2);
        
        // Bouton Circle3 : positionné en bas à gauche (centre à (50,350))
        JButton btnCircle3 = new JButton("3");
        // Coin supérieur gauche à (50 - 20, 350 - 20) = (30,330)
        btnCircle3.setBounds(50 - 20, 350 - 20, 40, 40);
        btnCircle3.setBorderPainted(false);
        btnCircle3.setFocusPainted(false);
        btnCircle3.setContentAreaFilled(false);
        btnCircle3.setRolloverEnabled(false);
        btnCircle3.setOpaque(false);
        btnCircle3.setForeground(Color.WHITE);
        btnCircle3.addActionListener(e -> dispose());
        add(btnCircle3);
    }
    
    // Redéfinition de la méthode paint pour dessiner le contenu personnalisé de la fenêtre
    @Override
    public void paint(Graphics g) {
        // Appel de la méthode paint du composant parent pour dessiner les enfants
        super.paint(g);
        Graphics2D g2 = (Graphics2D) g.create();
        // Activer l'anticrénelage pour un rendu plus lisse
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Dessiner un carré (zone principale) avec un dégradé
        int squareX = 50, squareY = 50, squareSize = 300;
        // Dégradé du rouge en haut à gauche vers le bleu en bas à droite
        GradientPaint gradient = new GradientPaint(0, 0, Color.RED, 400, 400, Color.BLUE);
        g2.setPaint(gradient);
        g2.fillRect(squareX, squareY, squareSize, squareSize);
        // Dessiner le contour du carré en noir
        g2.setColor(Color.BLACK);
        g2.drawRect(squareX, squareY, squareSize, squareSize);
        
        int circleDiameter = 40;
        // Dessiner le premier cercle en haut à droite
        // Position : coin supérieur gauche (330,30)
        int circle1X = 330, circle1Y = 30;
        g2.setColor(Color.CYAN);
        g2.fillOval(circle1X, circle1Y, circleDiameter, circleDiameter);
        g2.setColor(Color.BLACK);
        g2.drawOval(circle1X, circle1Y, circleDiameter, circleDiameter);
        
        // Dessiner le second cercle juste à côté
        // Position : coin supérieur gauche (360,30)
        int circle2X = 360, circle2Y = 30;
        g2.setColor(Color.MAGENTA);
        g2.fillOval(circle2X, circle2Y, circleDiameter, circleDiameter);
        g2.setColor(Color.BLACK);
        g2.drawOval(circle2X, circle2Y, circleDiameter, circleDiameter);
        
        // Dessiner le troisième cercle en bas à gauche du carré
        // Position : coin supérieur gauche (30,330)
        int circle3X = 30, circle3Y = 330;
        g2.setColor(Color.ORANGE);
        g2.fillOval(circle3X, circle3Y, circleDiameter, circleDiameter);
        g2.setColor(Color.BLACK);
        g2.drawOval(circle3X, circle3Y, circleDiameter, circleDiameter);
        
        // Créer une forme composite en unissant le carré et les trois cercles
        Area composite = new Area(new Rectangle(50, 50, 300, 300));
        composite.add(new Area(new Ellipse2D.Double(330, 30, circleDiameter, circleDiameter)));
        composite.add(new Area(new Ellipse2D.Double(360, 30, circleDiameter, circleDiameter)));
        composite.add(new Area(new Ellipse2D.Double(30, 330, circleDiameter, circleDiameter)));
        // Appliquer cette forme à la fenêtre
        setShape(composite);
        
        g2.dispose();
    }
    
    // Classe interne pour un bouton personnalisé circulaire
    class CircleButton extends JButton {
        public CircleButton() {
            // Constructeur par défaut
        }
        
        // Redéfinition de la méthode de peinture pour dessiner un bouton en forme de cercle
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            // Activer l'anticrénelage pour des bords lisses
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            // Dessiner le fond du bouton sous forme de cercle avec une couleur de fond claire
            g2.setColor(Color.LIGHT_GRAY);
            g2.fillOval(0, 0, w, h);
            // Dessiner le contour du cercle
            g2.setColor(Color.BLACK);
            g2.drawOval(0, 0, w, h);
            // Dessiner un rectangle rouge à l'intérieur du cercle
            int rectWidth = (int) (w * 0.5);
            int rectHeight = (int) (h * 0.4);
            int rectX = (w - rectWidth) / 2;
            int rectY = (h - rectHeight) / 2;
            g2.setColor(Color.RED);
            g2.fillRect(rectX, rectY, rectWidth, rectHeight);
            g2.dispose();
        }
    }
}
