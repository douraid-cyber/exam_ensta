package examen;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Area;

import javax.swing.JButton;
import javax.swing.JFrame;

public class framepoly2 extends JFrame {

	private static int mouseX=0;
	private static int mouseY=0;
	
	public framepoly2()
	{
		setSize(400,200);
		setUndecorated(true);
		setLayout(null);
		setBackground(new Color(0,0,0,0));
		
		addMouseMotionListener(new MouseAdapter() {
			
			@Override
			public void mouseDragged(MouseEvent e)
			{
				int x = e.getXOnScreen()-mouseX;
				int y = e.getYOnScreen()-mouseY;
				setLocation(x,y);
			}
		});
		
		addMouseListener(new MouseAdapter() {
			
			@Override
			public void mousePressed(MouseEvent e)
			{
				mouseX = e.getX();
				mouseY = e.getY();
			}
		});
		
		JButton butExit = new JButton("x");
		butExit.setBounds((getWidth()/2) -20 ,(getHeight()/2) - 20 ,40,40);
		//butExit.setBackground(new Color(255,0,0));
		butExit.setBorderPainted(false);
		butExit.setFocusPainted(false);
		butExit.setForeground(Color.white);
		
		
		butExit.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				// TODO Auto-generated method stub
				butExit.setBackground(Color.red);
			}
			
			@Override
			public void mouseEntered(MouseEvent arg0) {
				// TODO Auto-generated method stub
				butExit.setBackground(Color.DARK_GRAY);
				
			}
			
			@Override
			public void mouseClicked(MouseEvent arg0) {
				dispose();
				
			}
		});
		
		add(butExit);

	}
	@Override
	public void paint(Graphics g)
	{
		super.paint(g);
		Graphics2D graphics2d = (Graphics2D)g;
	
		graphics2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		graphics2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		graphics2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
		
		//perf
//		graphics2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
//		graphics2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
//		graphics2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
		
		//int w = getWidth();
		//int h = getHeight();
//		int[] xpoints = {200,350,350,200,50,50};
//		int[] ypoints = {50,150,300,350,300,150};
//		Polygon polygon = new Polygon(xpoints,ypoints,ypoints.length);
		
		//graphics2d.setColor(Color.BLUE);
		int w = getWidth();
		int h = getHeight();
		int[] xpoints1 = {10,w/2,w/2 - 2,w-3,w-3,w,w,w-10,w/2,w/2-2,3,3,0,0};
		int[] ypoints1 = {0,0,3,3,h-(h/3),h-(h/3)+2,h-10,h,h,h-3,h-3,h/3 - 2,10};
		
		Polygon poly1 = new Polygon(xpoints1,ypoints1,ypoints1.length);
		
		int[] xpoints2 = {14,w/2-4,w/2-2,w-4,w-4,w-6,w-6,w-14,w/2-4,w/2-2,4,4,6,6};
		int[] ypoints2 = {6,6,4,4,h-(h/3),h-(h/3)-3,h-15,h-6,h-6,h-4,h-4,h/3,(h/3)+2,14};
		
		Polygon poly2 = new Polygon(xpoints2,ypoints2,ypoints2.length);
		
		Area area1 = new Area(poly1);
		Area area2 = new Area(poly2);
		area1.exclusiveOr(area2);
		
		graphics2d.setColor(Color.BLUE);
		GradientPaint gradient = new GradientPaint(0, 0, Color.red, 300,150,Color.magenta);
		
		graphics2d.fill(area1);
		graphics2d.setPaint(gradient);
		graphics2d.fill(poly2);
		//setShape(poly1);
	}
}

