import java.awt.Color;

import javax.swing.JFrame;

public class test extends JFrame{
	
	test()
	{
		setSize(400,410);
		setUndecorated(true);
		setBackground(Color.red);
	}
	
	

	public static void main(String[] args) {
        test text = new test();
        text.setVisible(true);
    }
}

