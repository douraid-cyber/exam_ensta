import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Label;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.TextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Area;
import java.awt.geom.RoundRectangle2D;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class polyv2 extends JFrame{
	
	private static int mouseX;
	private static int mouseY;
	
	public polyv2() {
		setSize(400,200);
		setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
		setBackground(new Color(0,0,0,100));
		
		addMouseMotionListener(new MouseAdapter() {	
			@Override
			public void mouseDragged(MouseEvent e) {
				int x = e.getXOnScreen() - mouseX;
				int y = e.getYOnScreen() - mouseY;
				setLocation(x,y);
			}
		});
		
		addMouseListener(new MouseAdapter() {	
			@Override
			public void mousePressed(MouseEvent e) {
				mouseX = e.getX();
				mouseY = e.getY();
			}
		});
		
		JTextArea nom = new JTextArea("Nom");
		nom.setOpaque(true);
		JTextArea prenom = new JTextArea("Prenom");
		prenom.setOpaque(true);
		JTextArea age = new JTextArea("Age");
		age.setOpaque(true);
		JTextArea ecole = new JTextArea("Ecole");
		ecole.setOpaque(true);
		JLabel label = new JLabel(" ");
			
		add(nom);
		add(prenom);
		add(age);
		add(ecole);
		
		JButton butOK = new JButton("OK");
		butOK.setBackground(new Color(255,0,0)); // RGB --> Rouge
		butOK.setBorderPainted(false);
		butOK.setFocusPainted(false);
		butOK.setForeground(Color.white);
		butOK.setMargin(new Insets(0, 0, 0, 0));
		
		
		butOK.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				butOK.setBackground(new Color(255,0,0));
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				butOK.setBackground(new Color(255,90,90));
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				String nomText = nom.getText().isEmpty() ? "Non spécifié" : nom.getText();
                String prenomText = prenom.getText().isEmpty() ? "Non spécifié" : prenom.getText();
                String ageText = age.getText().isEmpty() ? "Non spécifié" : age.getText();
                String ecoleText = ecole.getText().isEmpty() ? "Non spécifié" : ecole.getText();
                
                label.setText("[" + nomText + ", " + prenomText + ", " + ageText + ", " + ecoleText + "]");
            }
		});
		
		JButton butExit = new JButton("X");
		butExit.setBounds(getWidth()-20, getHeight()-20, 40, 40);
		butExit.setBackground(new Color(255,0,0)); // RGB --> Rouge
		butExit.setBorderPainted(false);
		butExit.setFocusPainted(false);
		butExit.setForeground(Color.white);
		butExit.setMargin(new Insets(0, 0, 0, 0));
		
		
		butExit.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				butExit.setBackground(new Color(255,0,0));
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				butExit.setBackground(new Color(255,90,90));
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
				
			}
		});
		
			

	add(butOK);
	add(label);
	add(butExit);
		
		

	}
	
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		// Quality
		Graphics2D g2d = (Graphics2D)g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);

		int w = getWidth();
		int h = getHeight();
		
		RoundRectangle2D poly = new RoundRectangle2D.Double(0, 0, w, h, 50, 50);

		g2d.setPaint(new Color(0,0,0,100));
		g2d.fill(poly);
		
	}
}
