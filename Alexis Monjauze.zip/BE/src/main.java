import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Stroke;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTree;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;


public class main {
	
	private static int mouseX;
	private static int mouseY;
	
	static int lastx;
	static int lasty;
	static List<int[]> lines = new ArrayList<>();
	static Color couleur_actuelle = Color.BLACK;
	static List<Color> Liste_couleur = new ArrayList<>();
	static List<String> Liste_thinkness = new ArrayList<>();
	static String thinkness = "Thin";
	static List<String> Liste_shape = new ArrayList<>();
	static String shape = "Straight";
	
	public static JButton addMouveButton(JPanel panel, String nom_boutton) {
		JButton button = new JButton(nom_boutton);
		panel.add(button);
		
		button.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
            }
        });

        button.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                int newX = button.getX() + e.getX() - mouseX;
                int newY = button.getY() + e.getY() - mouseY;

                // Vérification des limites de la fenêtre
                if (newX < 0) newX = 0;
                if (newY < 0) newY = 0;
                if (newX + button.getWidth() > panel.getWidth()) newX = panel.getWidth() - button.getWidth();
                if (newY + button.getHeight() > panel.getHeight()) newY = panel.getHeight() - button.getHeight();

                button.setLocation(newX, newY);
            }
        });
    return button;
	}
	
	public static void main(String[] args) {
		
		JFrame frame = new JFrame("BE");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(1000,700);
		frame.setLayout(new BorderLayout(15,15));
		
		//##############################################
		JPanel north = new JPanel();
		north.setBackground(Color.red);
		
		JButton button1 = addMouveButton(north, "Bougez moi 1");
		JButton button2 = addMouveButton(north, "Bougez moi 2");
		JButton button3 = addMouveButton(north, "Bougez moi 3");
		
		button1.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				polyv2 plv2= new polyv2();
				plv2.setVisible(true);
			}
		});
		
		button2.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				but2 frame = new but2();
				frame.setVisible(true);
			}
		});
		
		//##############################################
		JPanel south = new JPanel();
		south.setBackground(Color.magenta);
		
		//##############################################
		JPanel east = new JPanel();
		east.setBackground(Color.orange);
		
		JTextArea jta = new JTextArea("zone de texte");
		jta.setForeground(Color.black);
		JScrollPane jscp = new JScrollPane(jta);
		jscp.setPreferredSize(new Dimension(250, 500));
		
		JButton chgt_couleur_text = new JButton("Changer la couleur du texte");
		chgt_couleur_text.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				couleur_actuelle = jta.getForeground();
				if (couleur_actuelle == Color.black) {
					jta.setForeground(Color.RED);
				}else {
					jta.setForeground(Color.black);
				}			
			}
		});
		
		JButton chgt_couleur_backgound = new JButton("Changer la couleur du background");
		chgt_couleur_backgound.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				couleur_actuelle = east.getBackground();
				if (couleur_actuelle == Color.orange) {
					east.setBackground(Color.gray);
				}else {
					east.setBackground(Color.orange);
				}			
			}
		});
		
		
		east.add(jscp);
		east.add(chgt_couleur_text);
		east.add(chgt_couleur_backgound);
		
		//##############################################
		JPanel west = new JPanel();
		west.setBackground(Color.green);
		
		//##############################################
		JPanel center = new JPanel() {
			@Override
			protected void paintComponent(Graphics g) {
				super.paintComponent(g);
				Graphics2D g2d = (Graphics2D) g.create();
				for (int i=0; i<lines.size();i++) {
					g2d.setColor(Liste_couleur.get(i));
					int real_thickness; 
					if (Liste_thinkness.get(i) == "Thin"); {
						real_thickness = 1; 
					}if (Liste_thinkness.get(i) == "Thick") {
						real_thickness = 5; 
					}if (Liste_thinkness.get(i) == "Thickest") {
						real_thickness = 10; 
					}
					g2d.setStroke(new BasicStroke(real_thickness));
					int[] line = lines.get(i);
					shape = Liste_shape.get(i);
					if (shape == "Straight"); {
						g2d.drawLine(line[0], line[1], line[2], line[3]);
					}if (shape == "Dotted") {
						g2d.drawLine(line[0], line[1], line[2], line[3]);
						// j'y arrive pas je passe

					}
				}
			}
		};
		
		center.setBackground(Color.white);
		
		String[] lst_thickness = {"Thin", "Thick", "Thickest"};
        JComboBox<String> comboBox_thick = new JComboBox<>(lst_thickness);
        
        String[] lst_shape = {"Straight", "Dotted"};
        JComboBox<String> comboBox_shape = new JComboBox<>(lst_shape);
        
        Color[] lst_color = {Color.red, Color.green, Color.blue, Color.black};
        JComboBox<Color> comboBox_color = new JComboBox<>(lst_color);
		
		center.setFocusable(true);
		
		
		center.setBackground(Color.white);
		center.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				lastx = e.getX();
				lasty = e.getY();
			}
		});
		
		center.addMouseMotionListener(new MouseMotionListener() {			
			@Override
			public void mouseMoved(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseDragged(MouseEvent e) {
				int x = e.getX();
				int y = e.getY();
				lines.add(new int[] {lastx, lasty, x, y});
				Liste_couleur.add((Color) comboBox_color.getSelectedItem());
				Liste_thinkness.add((String) comboBox_thick.getSelectedItem());
				Liste_shape.add((String) comboBox_shape.getSelectedItem());
				lastx = x;
				lasty = y;
				center.repaint();
				
			}
		}); 

        center.add(comboBox_thick);
        center.add(comboBox_color);
        center.add(comboBox_shape);
		
        //##############################################
        
		frame.add(north, BorderLayout.NORTH);
		frame.add(south, BorderLayout.SOUTH);
		frame.add(east, BorderLayout.EAST);
		frame.add(west, BorderLayout.WEST);
		frame.add(center, BorderLayout.CENTER);
		frame.setVisible(true);

	}

}
