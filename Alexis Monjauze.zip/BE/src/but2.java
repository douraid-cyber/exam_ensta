import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class but2 extends JFrame {
    
    private static int mouseX;
    private static int mouseY;
    
    private static int R = 50;
    private static int G = 50;
    private static int B = 50;
    private static int Visi = 50;
    
    
    public but2() {
        setSize(500, 500);  // Augmenté pour mieux correspondre à la forme ronde
        setUndecorated(true);
        //getContentPane().setBackground(new Color(0,0,0,0));
        //setLayout(new BorderLayout());	
        setLocationRelativeTo(null);  // Centrer la fenêtre
        setBackground(Color.GRAY);

        // Écouteurs pour déplacer la fenêtre
        addMouseMotionListener(new MouseAdapter() {    
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen() - mouseX;
                int y = e.getYOnScreen() - mouseY;
                setLocation(x, y);
            }
        });

        addMouseListener(new MouseAdapter() {    
            @Override
            public void mousePressed(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
            }
        });
    JSlider slider = new JSlider(JSlider.HORIZONTAL, 0, 255, 50);
    slider.setMajorTickSpacing(20);  // Ticks majeurs toutes les 20 unités
    slider.setMinorTickSpacing(5);   // Ticks mineurs toutes les 5 unités
    slider.setPaintTicks(true);      // Afficher les ticks
    slider.setPaintLabels(true);    // Afficher les étiquettes de tick
    
    JPanel panel = new JPanel();
    
    JCheckBox Red = new JCheckBox("R");
    JCheckBox Green = new JCheckBox("G");
    JCheckBox Blue = new JCheckBox("B");
    JCheckBox Visib = new JCheckBox("Visibilite");
    
    slider.addChangeListener(new ChangeListener() {
        @Override
        public void stateChanged(ChangeEvent e) {
            if (Red.isSelected()) {
            	R = slider.getValue()  ;          	
            }if (Green.isSelected()) {
            	G = slider.getValue() ; 
            }if (Blue.isSelected()) {
            	B = slider.getValue() ; 
            }if (Visib.isSelected()) {
            	Visi = slider.getValue() ; 
            }
            setBackground(new Color(R,G,B,Visi));
        }
            
    });
    
    
    add(slider, BorderLayout.CENTER);
    add(panel, BorderLayout.SOUTH);
    panel.add(Red);
    panel.add(Green);
    panel.add(Blue);
    panel.add(Visib);
    
    
    }
    
    

    // Peindre la forme ronde
    /*@Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.red);
        g2d.fill(new Ellipse2D.Double(0, 0, getWidth(), getHeight()));  
        repaint();
    }*/

    public static void main(String[] args) {
    	but2 but22 = new but2();
    	but22.setVisible(true);
    	
    	//but22.repaint();
    }
}
