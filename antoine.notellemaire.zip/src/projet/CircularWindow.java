package projet;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class CircularWindow extends JDialog
{
    private JSlider slider;
    private JButton btnClose;
    private JCheckBox cbR, cbG, cbB, cbA;

    public CircularWindow()
    {
        setTitle("Fenêtre Circulaire");
        setSize(300, 300);
        setLocationRelativeTo(null);
        setUndecorated(true);
        setShape(new Ellipse2D.Double(0, 0, 300, 300));

        // Utiliser BorderLayout sur la CircularWindow pour centrer les composants au centre du cercle
        setLayout(new BorderLayout());

        // Créer un panel principal transparent avec un BoxLayout vertical pour centrer
        JPanel mainPanel = new JPanel();
        mainPanel.setOpaque(false);
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        // Slider centré
        slider = new JSlider(0, 255, 128);
        slider.setAlignmentX(Component.CENTER_ALIGNMENT);
        slider.addChangeListener(new ChangeListener()
        {
            @Override
            public void stateChanged(ChangeEvent e)
            {
                updateColor();
            }
        });

        // Panel pour les checkboxs, centré
        JPanel checkboxPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
        checkboxPanel.setOpaque(false);
        cbR = new JCheckBox("R", true);
        cbG = new JCheckBox("G", true);
        cbB = new JCheckBox("B", true);
        cbA = new JCheckBox("A", false);
        checkboxPanel.add(cbR);
        checkboxPanel.add(cbG);
        checkboxPanel.add(cbB);
        checkboxPanel.add(cbA);

        // Bouton exit centré
        btnClose = new JButton("Fermer");
        btnClose.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnClose.addActionListener(e -> dispose());

        // Ajout des composants, tous centrés verticalement et horizontalement normalement
        mainPanel.add(Box.createVerticalGlue());
        mainPanel.add(slider);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(checkboxPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(btnClose);
        mainPanel.add(Box.createVerticalGlue());

        // Ajouter le panel principal au centre de la JDialog
        add(mainPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    private void updateColor()
    {
        int val = slider.getValue();
        int r = cbR.isSelected() ? val : 128;
        int g = cbG.isSelected() ? val : 128;
        int b = cbB.isSelected() ? val : 128;
        int a = cbA.isSelected() ? val : 255;

        Color c = new Color(r, g, b, a);
        getContentPane().setBackground(c);
    }
}
