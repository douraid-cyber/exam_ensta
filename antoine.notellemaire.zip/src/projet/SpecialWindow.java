package projet;

import javax.swing.*;
import java.awt.*;

public class SpecialWindow extends JDialog
{

    public SpecialWindow() 
   {
        setTitle("Fenêtre spéciale");
        setSize(300, 200);
        setLocationRelativeTo(null);
        setModal(true);

        getContentPane().setBackground(new Color(227, 148, 194));

        JLabel label = new JLabel("Bienvenue dans la fenêtre spéciale !", SwingConstants.CENTER);
        label.setForeground(Color.WHITE);
        add(label, BorderLayout.CENTER);

        setVisible(true);
    }
}
