package projet;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ButtonsZone extends JPanel
{

    private JButton button1, button2, button3;

    public ButtonsZone()
    {
        setLayout(null);
        setPreferredSize(new Dimension(200, 0)); // largeur fixe (optionnel)

        // Boutons
        button1 = new JButton("Bouton 1");
        button2 = new JButton("Bouton 2");
        button3 = new JButton("Bouton 3");

        // Positions initiales
        button1.setBounds(20, 20, 80, 30);
        button2.setBounds(20, 70, 80, 30);
        button3.setBounds(20, 120, 80, 30);

        addDragCapability(button1, this);
        addDragCapability(button2, this);
        addDragCapability(button3, this);

        // Actions
        button1.addActionListener(e -> new RoundedWindow());
        button2.addActionListener(e -> new CircularWindow());
        button3.addActionListener(e -> new PolygonWindow());

        add(button1);
        add(button2);
        add(button3);
    }

    private void addDragCapability(JButton btn, JPanel parent)
    {
        final Point clickPoint = new Point();

        btn.addMouseListener(new MouseAdapter()
        {
            @Override
            public void mousePressed(MouseEvent e)
            {
                clickPoint.x = e.getX();
                clickPoint.y = e.getY();
            }
        });

        btn.addMouseMotionListener(new MouseMotionAdapter()
        {
            @Override
            public void mouseDragged(MouseEvent e)
            {
                int newX = btn.getX() + e.getX() - clickPoint.x;
                int newY = btn.getY() + e.getY() - clickPoint.y;

                // Clamps pour rester dans la zone
                newX = Math.max(newX, 0);
                newY = Math.max(newY, 0);
                newX = Math.min(newX, parent.getWidth() - btn.getWidth());
                newY = Math.min(newY, parent.getHeight() - btn.getHeight());

                btn.setLocation(newX, newY);
            }
        });
    }
}
