package projet;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;

public class PolygonWindow extends JDialog
{

    public PolygonWindow()
    {
        setTitle("Fenêtre polygonale");
        setSize(200, 200);
        setLocationRelativeTo(null);
        setUndecorated(true);
        getContentPane().setBackground(Color.GRAY);

        Area shape = new Area(new Rectangle2D.Double(40, 30, 70, 70));
        Area shape2 = new Area(new Ellipse2D.Double(120,  0,  50, 50));
        shape.add(shape2);
        Area shape3 = new Area(new Ellipse2D.Double(15, 75, 50, 50));
        shape.add(shape3);
        Area shape4 = new Area(new Ellipse2D.Double(95, 15, 50, 50));
        shape.add(shape4);

        setShape(shape);

        setLayout(null);

        // Y
        JButton btnY = createHoverButton("y");
        btnY.setBounds(110, 30, 15, 15);
        add(btnY);

        // X
        JButton btnX = createHoverButton("x");
        btnX.setBounds(30, 90, 15, 15);
        add(btnX);

        // O
        JButton btnO = createHoverButton("o");
        btnO.setBounds(135, 15, 15, 15);
        add(btnO);

        // bouton central (étoile)
        JButton btnStar = createHoverButton("");
        btnStar.setBounds(60, 50, 30, 30);
  
        btnStar.setContentAreaFilled(false);
        btnStar.setBorderPainted(false);
        btnStar.setFocusPainted(false);
        // étoile
        btnStar.setIcon(new StarIcon(30, 30, Color.YELLOW));
        
        // exit
        btnStar.addActionListener(e -> dispose());
        add(btnStar);

        setVisible(true);
    }

    private JButton createHoverButton(String text)
    {
        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.addMouseListener(new MouseAdapter()
        {
            Color oldBg = btn.getBackground();
            @Override
            public void mouseEntered(MouseEvent e)
            {
                btn.setBackground(Color.CYAN);
            }
            @Override
            public void mouseExited(MouseEvent e)
            {
                btn.setBackground(oldBg);
            }
        });
        return btn;
    }

    private static class StarIcon implements Icon
    {
        private final int w, h;
        private final Color color;

        public StarIcon(int w, int h, Color color)
        {
            this.w = w;
            this.h = h;
            this.color = color;
        }

        @Override
        public int getIconWidth()
        {
            return w;
        }

        @Override
        public int getIconHeight()
        {
            return h;
        }

        @Override
        public void paintIcon(Component c, Graphics g, int x, int y)
        {
            Graphics2D g2 = (Graphics2D) g.create();

            // étoile à 5 branches
            Polygon star = new Polygon();
            star.addPoint(x + w/2,           y + 0);
            star.addPoint(x + (int)(0.62*w), y + (int)(0.38*h));
            star.addPoint(x + w,            y + (int)(0.38*h));
            star.addPoint(x + (int)(0.69*w), y + (int)(0.62*h));
            star.addPoint(x + (int)(0.81*w), y + h);
            star.addPoint(x + w/2,           y + (int)(0.77*h));
            star.addPoint(x + (int)(0.19*w), y + h);
            star.addPoint(x + (int)(0.31*w), y + (int)(0.62*h));
            star.addPoint(x + 0,            y + (int)(0.38*h));
            star.addPoint(x + (int)(0.38*w), y + (int)(0.38*h));

            g2.setColor(color);
            g2.fill(star);

            g2.dispose();
        }
    }
}
