package projet;

import javax.swing.*;
import java.awt.*;

public class TextZone extends JPanel
{
    private JTextArea textArea;
    private JComboBox<String> bgColorCombo, fgColorCombo;

    public TextZone()
    {
        setLayout(new BorderLayout());
        textArea = new JTextArea(5, 30);
        JScrollPane scroll = new JScrollPane(textArea);
        String[] colors = {"Blanc","Jaune","Rose","Cyan"};
        bgColorCombo = new JComboBox<>(colors);
        fgColorCombo = new JComboBox<>(colors);

        bgColorCombo.addActionListener(e -> updateColors());
        fgColorCombo.addActionListener(e -> updateColors());

        JPanel topPanel = new JPanel();
        topPanel.add(new JLabel("Background:"));
        topPanel.add(bgColorCombo);
        topPanel.add(new JLabel("Texte:"));
        topPanel.add(fgColorCombo);

        add(topPanel, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
    }

    private void updateColors()
    {
        Color cBg = convertColor((String) bgColorCombo.getSelectedItem());
        Color cFg = convertColor((String) fgColorCombo.getSelectedItem());
        textArea.setBackground(cBg);
        textArea.setForeground(cFg);
    }

    private Color convertColor(String s)
    {
        switch (s)
        {
            case "Jaune": return Color.YELLOW;
            case "Rose":  return Color.PINK;
            case "Cyan":  return Color.CYAN;
            default:      return Color.WHITE;
        }
    }
}
