package projet;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Line2D;
import java.util.ArrayList;

public class DrawingZone extends JPanel
{

    private Color currentColor = Color.BLACK;
    private float currentStrokeWidth = 2f;
    private boolean dotted = false;

    private Point lastPoint;
    private java.util.List<ColoredLine> lines = new ArrayList<>();

    public DrawingZone()
    {
        setLayout(new BorderLayout());
        JPanel optionsPanel = new JPanel();
        String[] colors = {"Noir", "Rouge", "Vert", "Bleu"};
        JComboBox<String> colorCombo = new JComboBox<>(colors);

        String[] styles = {"Continu", "Pointillé"};
        JComboBox<String> styleCombo = new JComboBox<>(styles);

        String[] widths = {"1", "2", "5", "10"};
        JComboBox<String> widthCombo = new JComboBox<>(widths);

        colorCombo.addActionListener(e ->
        {
            switch ((String)colorCombo.getSelectedItem())
            {
                case "Rouge": currentColor = Color.RED; break;
                case "Vert": currentColor = Color.GREEN; break;
                case "Bleu": currentColor = Color.BLUE; break;
                default: currentColor = Color.BLACK; break;
            }
        });
        styleCombo.addActionListener(e ->
        {
            dotted = styleCombo.getSelectedItem().equals("Pointillé");
        });
        widthCombo.addActionListener(e ->
        {
            currentStrokeWidth = Float.parseFloat((String) widthCombo.getSelectedItem());
        });

        optionsPanel.add(new JLabel("Couleur:"));
        optionsPanel.add(colorCombo);
        optionsPanel.add(new JLabel("Style:"));
        optionsPanel.add(styleCombo);
        optionsPanel.add(new JLabel("Largeur:"));
        optionsPanel.add(widthCombo);

        add(optionsPanel, BorderLayout.NORTH);

        DrawPanel drawPanel = new DrawPanel();
        add(drawPanel, BorderLayout.CENTER);
    }

    private class DrawPanel extends JPanel
    {
        public DrawPanel()
        {
            setBackground(Color.WHITE);
            MouseAdapter ma = new MouseAdapter()
            {
                @Override
                public void mousePressed(MouseEvent e)
                {
                    lastPoint = e.getPoint();
                }
                @Override
                public void mouseDragged(MouseEvent e)
                {
                    Point current = e.getPoint();
                    lines.add(new ColoredLine(lastPoint, current, currentColor, currentStrokeWidth, dotted));
                    lastPoint = current;
                    repaint();
                }
                @Override
                public void mouseReleased(MouseEvent e)
                {
                    lastPoint = null;
                }
            };
            addMouseListener(ma);
            addMouseMotionListener(ma);
        }

        @Override
        protected void paintComponent(Graphics g)
        {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            for (ColoredLine line : lines)
            {
                g2.setColor(line.color);
                if (line.dotted)
                {
                    float[] dash = {5f, 5f};
                    g2.setStroke(new BasicStroke(line.width,
                            BasicStroke.CAP_BUTT,
                            BasicStroke.JOIN_BEVEL,
                            0, dash, 0));
                }
                else
                {
                    g2.setStroke(new BasicStroke(line.width));
                }
                g2.draw(new Line2D.Float(line.start, line.end));
            }
        }
    }

    private static class ColoredLine
    {
        Point start, end;
        Color color;
        float width;
        boolean dotted;
        public ColoredLine(Point s, Point e, Color c, float w, boolean d)
        {
            start = s;
            end = e;
            color = c;
            width = w;
            dotted = d;
        }
    }
}
