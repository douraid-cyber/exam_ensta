package projet;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class RoundedWindow extends JDialog
{
    private JTextField tfNom, tfPrenom, tfAge, tfEcole;
    private JLabel lblResult;

    public RoundedWindow()
    {
        setTitle("Fenêtre arrondie");
        setSize(300, 250);
        setLocationRelativeTo(null);
        setModal(true);

        // pour l'effet arrondi
        setUndecorated(true);
        setShape(new RoundRectangle2D.Double(0, 0, 300, 250, 30, 30));

        JPanel mainPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        tfNom = new JTextField();
        tfPrenom = new JTextField();
        tfAge = new JTextField();
        tfEcole = new JTextField();
        lblResult = new JLabel(" ", SwingConstants.CENTER);

        mainPanel.add(new JLabel("Nom: "));
        mainPanel.add(tfNom);
        mainPanel.add(new JLabel("Prénom: "));
        mainPanel.add(tfPrenom);
        mainPanel.add(new JLabel("Âge: "));
        mainPanel.add(tfAge);
        mainPanel.add(new JLabel("École: "));
        mainPanel.add(tfEcole);

        JButton btnOk = new JButton("OK");
        JButton btnClose = new JButton("Fermer");

        btnOk.addActionListener(e ->
        {
            String result = String.format("[%s, %s, %s, %s]",
                tfNom.getText(), tfPrenom.getText(), tfAge.getText(), tfEcole.getText());
            lblResult.setText(result);
        });

        btnClose.addActionListener(e -> dispose());

        mainPanel.add(btnOk);
        mainPanel.add(btnClose);

        add(mainPanel, BorderLayout.CENTER);
        add(lblResult, BorderLayout.SOUTH);

        setVisible(true);
    }
}
