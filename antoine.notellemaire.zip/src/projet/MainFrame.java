package projet;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame
{

    private JTabbedPane tabbedPane;

    public MainFrame()
    {
        super("Projet Java ENSTA - 2 mars 2025");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1000, 600);
        setLocationRelativeTo(null);

        tabbedPane = new JTabbedPane();

        // Onglet 1 : 5 zones
        JPanel panel5Zones = createFiveZonesPanel();
        tabbedPane.addTab("Interface principale", panel5Zones);

        // Onglet 2 : 100 boutons
        JPanel panel100Buttons = create100ButtonsPanel();
        tabbedPane.addTab("100 Boutons", panel100Buttons);

        add(tabbedPane);
        setVisible(true);
    }

    private JPanel createFiveZonesPanel()
    {
        JPanel mainPanel = new JPanel(new BorderLayout());

        // Zones
        JPanel topPanel = new TextZone(); // zone de texte (NORTH)
        topPanel.setBackground(Color.BLUE); // ne fonctionne pas....
        JPanel leftPanel = new ButtonsZone(); // zone 3 boutons déplaçables (WEST)
        leftPanel.setBackground(Color.YELLOW);
        JPanel centerPanel = new DrawingZone(); // zone de dessin (CENTER)
        centerPanel.setBackground(Color.MAGENTA); // ne fonctionne pas ....
        JPanel rightPanel = new JPanel(); // zone vide (EAST)
        rightPanel.setBackground(Color.RED);
        JPanel bottomPanel = new JPanel(); // zone vide (SOUTH)
        bottomPanel.setBackground(Color.RED);

        mainPanel.add(topPanel,    BorderLayout.NORTH);
        mainPanel.add(leftPanel,   BorderLayout.WEST);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        mainPanel.add(rightPanel,  BorderLayout.EAST);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        return mainPanel;
    }

    private JPanel create100ButtonsPanel()
    {
        JPanel panel = new JPanel(new GridLayout(10, 10));
        for (int i = 1; i <= 100; i++)
        {
            JButton btn = new JButton("Btn " + i);
            if (i == 22)
            {
                btn.addMouseListener(new java.awt.event.MouseAdapter()
                {
                    @Override
                    public void mouseEntered(java.awt.event.MouseEvent e)
                    {
                        btn.setBackground(Color.RED);
                    }
                    @Override
                    public void mouseExited(java.awt.event.MouseEvent e)
                    {
                        btn.setBackground(null);
                    }
                    @Override
                    public void mouseClicked(java.awt.event.MouseEvent e)
                    {
                        new SpecialWindow();
                    }
                });
            }
            panel.add(btn);
        }
        return panel;
    }

    public static void main(String[] args)
    {
        SwingUtilities.invokeLater(MainFrame::new);
    }
}
