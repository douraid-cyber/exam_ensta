package be_java;


public class main {

	public static void main(String[] args) {

		interface_main myframe = new interface_main();
		myframe.setVisible(true);

	}

}
