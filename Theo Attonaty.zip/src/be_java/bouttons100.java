package be_java;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class bouttons100 extends JPanel {
	JPanel tous_lesboutons;
	int index = 22;
    public bouttons100() {
    	tous_lesboutons = new JPanel();
        // Définir le layout du panneau pour aligner les boutons
        tous_lesboutons.setLayout(new GridLayout(10, 10, 5, 5)); // 10 lignes et 10 colonnes, avec des espacements de 5px

        // Créer les 100 boutons blancs
        for (int i = 1; i <= 100; i++) {
            JButton bouton = new JButton("Button " + i);
            bouton.setBackground(Color.WHITE);  // Par défaut, les boutons sont blancs
            bouton.setFocusPainted(false);  // Désactive le contour du bouton quand il est sélectionné

            // Ajouter un MouseListener pour modifier la couleur au survol
            if (index == i) {bouton.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {

                        bouton.setBackground(Color.red); // Le 22e bouton devient blanc
                    
                }

                @Override
                public void mouseExited(MouseEvent e) {

                        bouton.setBackground(Color.WHITE); // Tous les autres boutons sont blancs
                    
                }
            });}

            // Ajouter chaque bouton au JPanel
            tous_lesboutons.add(bouton);
        }

        // Utilisation d'un JScrollPane pour permettre de défiler les boutons
        JScrollPane scrollPane = new JScrollPane(tous_lesboutons);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);//Encore une fois pour forcer un ascenseur verticale
        //Le JScrollPane n'est en fait pas necessaire
        add(scrollPane);
    }
}
