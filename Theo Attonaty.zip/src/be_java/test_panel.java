package be_java;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class test_panel extends JPanel {
    private JTextArea textArea;
    private JScrollPane scrollPane;

    public test_panel() {
        // Configurer le layout
        setLayout(new BorderLayout());

        // Créer la zone de texte
        textArea = new JTextArea();
        textArea.setWrapStyleWord(true);
        textArea.setLineWrap(true);
        textArea.setFont(new Font("Arial", Font.PLAIN, 14));

        // Ajouter la possibilité de modifier la couleur de fond
        setBackground(Color.white);

        // Créer une barre de défilement
        scrollPane = new JScrollPane(textArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);//Force le JScrollPane à avoir une barre verticale

        // Ajouter la zone de texte dans le panneau avec la barre de défilement
        JPanel controle = new JPanel();
        String[] colors_choix  = {"Noir", "Rouge", "Vert", "Bleu"};	
        JComboBox<String> color_text = new JComboBox<>(colors_choix);
        JComboBox<String> color_fond = new JComboBox<>(colors_choix);
        color_text.addActionListener(new ActionListener() {
        	@Override
        	public void actionPerformed(ActionEvent e) {
        		String selection = (String) color_text.getSelectedItem();
        		if(selection == "Noir") {
        			textArea.setForeground(Color.black);
        		}
        		else if(selection == "Rouge") {
        			textArea.setForeground(Color.red);        		}
        		else if(selection == "Vert") {
        			textArea.setForeground(Color.green);        		}
        		else if(selection == "Bleu") {
        			textArea.setForeground(Color.blue);        		}
        	}
        });
        color_fond.addActionListener(new ActionListener() {
        	@Override
        	public void actionPerformed(ActionEvent e) {
        		String selection = (String) color_fond.getSelectedItem();
        		if(selection == "Noir") {
        			textArea.setBackground(Color.black);
        		}
        		else if(selection == "Rouge") {
        			textArea.setBackground(Color.red);        		}
        		else if(selection == "Vert") {
        			textArea.setBackground(Color.green);        		}
        		else if(selection == "Bleu") {
        			textArea.setBackground(Color.blue);        		}
        	}
        });
        controle.add(color_text);
        controle.add(color_fond);
        add(controle, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
    }

    // Méthode pour récupérer le texte
    public String getText() {
        return textArea.getText();
    }

    // Méthode pour changer le texte
    public void setText(String text) {
        textArea.setText(text);
    }

    // Méthode pour changer la couleur de fond
    public void setBackgroundColor(Color color) {
        setBackground(color);
        textArea.setBackground(color);
    }
}
