package be_java;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class saise_nom extends JFrame {
    private JTextField nom_F, prenom_F, age_F, ecole_F;
    private JLabel resume;

    public saise_nom() {
        setTitle("Informations");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setUndecorated(true); // On enlève la barre de titre 
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 30, 30)); // Bords arrondis (J'ai eu cette option par IA qui à le merite d'être très rapide à implementer)
        setLayout(new GridLayout(6, 2, 5, 5));
        setResizable(true);
        setLocationRelativeTo(null);

        // Création des champs de texte
        add(new JLabel("Nom:"));
        nom_F = new JTextField();
        add(nom_F);

        add(new JLabel("Prénom:"));
        prenom_F = new JTextField();
        add(prenom_F);

        add(new JLabel("Âge:"));
        age_F = new JTextField();
        add(age_F);

        add(new JLabel("École:"));
        ecole_F = new JTextField();
        add(ecole_F);

        // Bouton "OK"
        JButton okButton = new JButton("OK");
        add(okButton);

        // Bouton "Fermer"
        JButton closeButton = new JButton("Fermer");
        add(closeButton);

        // Label pour afficher le résultat
        resume = new JLabel("");
        resume.setHorizontalAlignment(SwingConstants.CENTER);
        add(resume);

        // Action sur le bouton OK
        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nom = nom_F.getText();
                String prenom = prenom_F.getText();
                String age = age_F.getText();
                String ecole = ecole_F.getText();
                resume.setText("Nom : " + nom + ", Prenom : " + prenom + ", Age :" + age + ", Ecole :" + ecole + ".");
            }
        });

        // Action sur le bouton Fermer
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        setVisible(true);
    }
}
