package be_java;

import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.*;

public class saise_couleurs extends JFrame {
    private JSlider slide_r, slide_v, slide_b, slide_alpha, slide_tout;
    private JCheckBox box_r, box_v, box_b, box_alpha, box_tout;
    private JPanel curseur, cases, dessin;
    private int r = 0, v = 0, b = 0, alpha = 255;

    public saise_couleurs() {
        setTitle("Choisis ta couleur !");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        setResizable(true);
        setLocationRelativeTo(null);

        // Panel pour les curseurs
        curseur = new JPanel(new GridLayout(5, 1));
        
        // Panel pour les checkboxes
        cases = new JPanel(new GridLayout(1, 5));
        
        // Panel pour le dessin
        dessin = new JPanel() {
            @Override
            public void paintComponent(Graphics g) { //Pas besoin d'utiliser un g2D les methodes sont déjà implemente dans le g
                super.paintComponent(g);
                g.setColor(new Color(r, v, b, alpha));
                int diametre = Math.min(getWidth(), getHeight()) / 2; 
                g.fillOval((getWidth() - diametre) / 2, (getHeight() - diametre) / 2, diametre, diametre);
            }
        };

        // Création des sliders
        slide_r = new JSlider(0, 255, 0);
        slide_v = new JSlider(0, 255, 0);
        slide_b = new JSlider(0, 255, 0);
        slide_alpha = new JSlider(0, 255, 255);
        slide_tout = new JSlider(0, 255, 0);

        // Cachés au départ
        slide_r.setVisible(false);
        slide_v.setVisible(false);
        slide_b.setVisible(false);
        slide_alpha.setVisible(false);
        slide_tout.setVisible(false);

        // Création des cases à cocher
        box_r = new JCheckBox("Rouge");
        box_v = new JCheckBox("Vert");
        box_b = new JCheckBox("Bleu");
        box_alpha = new JCheckBox("Alpha");
        box_tout = new JCheckBox("Gris");

        // Ajout des cases à cocher
        cases.add(box_tout);
        cases.add(box_r);
        cases.add(box_v);
        cases.add(box_b);
        cases.add(box_alpha);

        // Ajout des sliders
        curseur.add(slide_tout);
        curseur.add(slide_r);
        curseur.add(slide_v);
        curseur.add(slide_b);
        curseur.add(slide_alpha);

        // Ajout des listeners pour afficher/masquer les sliders et gérer la sélection
        //On utilise des fonctions lambda sinon le code serait très long
        box_r.addItemListener(e -> toggleSlider(e, slide_r));
        box_v.addItemListener(e -> toggleSlider(e, slide_v));
        box_b.addItemListener(e -> toggleSlider(e, slide_b));
        box_alpha.addItemListener(e -> toggleSlider(e, slide_alpha));

        box_tout.addItemListener(e -> {
            boolean selected = box_tout.isSelected();
            slide_tout.setVisible(selected);

            // Désélectionner les autres cases si celle-ci est cochée
            if (selected) {
                box_r.setSelected(false);
                box_v.setSelected(false);
                box_b.setSelected(false);
                box_alpha.setSelected(false);

                slide_r.setVisible(false);
                slide_v.setVisible(false);
                slide_b.setVisible(false);
                slide_alpha.setVisible(false);
            }
            refresh();
        });

        // Ajout des listeners pour changer la couleur du cercle
        slide_r.addChangeListener(e -> { r = slide_r.getValue(); refresh(); });
        slide_v.addChangeListener(e -> { v = slide_v.getValue(); refresh(); });
        slide_b.addChangeListener(e -> { b = slide_b.getValue(); refresh(); });
        slide_alpha.addChangeListener(e -> { alpha = slide_alpha.getValue(); refresh(); });
        slide_tout.addChangeListener(e -> { r = v = b = slide_tout.getValue(); refresh(); });

        // Ajout des panneaux
        add(cases, BorderLayout.SOUTH);
        add(curseur, BorderLayout.NORTH);
        add(dessin, BorderLayout.CENTER);

        setVisible(true);
    }
    //Cette fonction permet de cocher decocher les cases pour les couleurs et decoche la case gris
    private void toggleSlider(ItemEvent e, JSlider slider) {
        boolean selected = e.getStateChange() == ItemEvent.SELECTED;
        slider.setVisible(selected);

        if (selected) {
            box_tout.setSelected(false);
            slide_tout.setVisible(false);
        }
        refresh();
    }

    private void refresh() {
        revalidate();
        repaint();
    }

}


