package be_java;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;

public class bouton_gliss extends JButton{
	
	private  int mouseX =0;
	private  int mouseY =0;
	private int lim_x = 0;
	private int lim_y = 0;
	private int taille_x = 0;
	private int taille_y = 0;
	
	
	public bouton_gliss(String text) {
		super(text);
		addMouseMotionListener(new MouseAdapter() {
			@Override
			public void mouseDragged(MouseEvent e)
			{
				int x = e.getXOnScreen()- mouseX;
				int y = e.getYOnScreen()- mouseY;
				System.out.println(lim_x);
				System.out.println(lim_y);
				System.out.println(x+taille_x);
				System.out.println(y+taille_y);
				if(x+taille_x < lim_x && y+taille_y < lim_y) {
					setLocation(x,y);
				}
			}
		});
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e)
			{
				mouseX=e.getX();
				mouseY=e.getY();
			}

		});
		
		taille_x = getSize().width;
		taille_y = getSize().height;
	}
	  public void set_limites(int a, int b) {
		lim_x = a;
		lim_y = b;
		System.out.println(lim_x);
		System.out.println(lim_y);
		}
}
