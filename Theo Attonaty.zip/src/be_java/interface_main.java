package be_java;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;


public class interface_main extends JFrame{
	public interface_main()
	{
		setSize(800, 600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JTabbedPane onglets = new JTabbedPane();
		
		JPanel onglets1 = new JPanel();
		bouttons100 onglets2 = new bouttons100();
		onglets1.setLayout(new BorderLayout());
		
		//On s'occupe d'abord du pannelle avec les boutons.
		JPanel bouttons = new JPanel();
		//bouttons.setLayout(null);
		bouton_gliss bout1 = new bouton_gliss("Inforamtions");
		bouton_gliss bout2 = new bouton_gliss("Choix couleurs");
		bouttons.setPreferredSize(new Dimension(300, getHeight()));
		bouttons.setBackground(Color.red);
		bouttons.add(bout1);
		bouttons.add(bout2);
		
		DessinPanel dessins = new DessinPanel();
		
		test_panel text = new test_panel();
		
		bout1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent arg0) {
				
				/*JFrame fra = new JFrame();
				fra.setSize(300,150);
				fra.setVisible(true);*/
				
				saise_nom infos = new saise_nom();
				infos.setVisible(true);
				
				
				
			}
		});
		
		bout2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent arg0) {
				
				/*JFrame fra = new JFrame();
				fra.setSize(300,150);
				fra.setVisible(true);*/
				
				saise_couleurs couleurs = new saise_couleurs();
				couleurs.setVisible(true);
				
				
				
			}
		});
		
		onglets1.add(bouttons, BorderLayout.WEST);
		onglets1.add(dessins, BorderLayout.CENTER);
		onglets1.add(text, BorderLayout.EAST);
		JPanel bas = new JPanel();
		bas.setBackground(Color.green);
		JPanel haut = new JPanel();
		haut.setBackground(Color.blue);
		onglets1.add(bas, BorderLayout.SOUTH);
		onglets1.add(haut, BorderLayout.NORTH);
		
		onglets.add("partie1", onglets1);
		onglets.add("Partie2", onglets2);
		
		add(onglets);
		
		setVisible(true);
		
		bout1.set_limites(bouttons.getSize().width, bouttons.getSize().height);
		bout2.set_limites(bouttons.getSize().width, bouttons.getSize().height);

}
}
