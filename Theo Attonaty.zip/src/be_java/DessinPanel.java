package be_java;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Line2D;
import java.util.ArrayList;

public class DessinPanel extends JPanel {
    private Color couleur_mtn = Color.BLACK; // Couleur par défaut
    private float strokeWidth = 2.0f; // Épaisseur par défaut
    private boolean dashed = false; // Style de trait (false = continu, true = pointillé)

    private final ArrayList<Stroke> strokes = new ArrayList<>();
    private final ArrayList<Color> colors = new ArrayList<>();
    private final ArrayList<Shape> shapes = new ArrayList<>();

    private int lastX, lastY;
    
    JPanel controle = new JPanel();
    String[] colors_choix  = {"Noir", "Rouge", "Vert", "Bleu"};	
    JComboBox<String> colorBox = new JComboBox<>(colors_choix);

    public DessinPanel() {
        setBackground(Color.WHITE);
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                lastX = e.getX();
                lastY = e.getY();
            }
        });

        colorBox.addActionListener(new ActionListener() {
        	@Override
        	public void actionPerformed(ActionEvent e) {
        		String selection = (String) colorBox.getSelectedItem();
        		if(selection == "Noir") {
        			couleur_mtn = Color.black;
        		}
        		else if(selection == "Rouge") {
        			couleur_mtn = Color.red;
        		}
        		else if(selection == "Vert") {
        			couleur_mtn = Color.green;
        		}
        		else if(selection == "Bleu") {
        			couleur_mtn = Color.blue;
        		}
        	}
        });
        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                Shape line = new Line2D.Float(lastX, lastY, e.getX(), e.getY());
                shapes.add(line);
                colors.add(couleur_mtn);
                strokes.add(createStroke());
                lastX = e.getX();
                lastY = e.getY();
                repaint();
            }
        });
        controle.add(colorBox);
        add(controle);
    }

    private Stroke createStroke() {
        if (dashed) {
            float[] dashPattern = {10.0f, 10.0f}; // Pointillés
            return new BasicStroke(strokeWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 10.0f, dashPattern, 0.0f);
        } else {
            return new BasicStroke(strokeWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        for (int i = 0; i < shapes.size(); i++) {
            g2.setColor(colors.get(i));
            g2.setStroke(strokes.get(i));
            g2.draw(shapes.get(i));
        }
    }

    public void setCurrentColor(Color color) {
        this.couleur_mtn = color;
    }

    public void setStrokeWidth(float width) {
        this.strokeWidth = width;
    }

    public void setDashed(boolean dashed) {
        this.dashed = dashed;
    }


    }

