package batikh;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TextPanel extends JPanel {
    private JTextArea textArea;

    public TextPanel() {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createTitledBorder("Zone de texte"));

        // Zone de texte avec barre de défilement
        textArea = new JTextArea(10, 20);
        JScrollPane scrollPane = new JScrollPane(textArea);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);

        // Panneau de contrôles (couleurs du texte et du fond)
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton textColorButton = new JButton("Couleur Texte");
        JButton bgColorButton = new JButton("Couleur Fond");

        // Choix de la couleur du texte
        textColorButton.addActionListener(e -> {
            Color newColor = JColorChooser.showDialog(
                    TextPanel.this, "Choisir Couleur du Texte", textArea.getForeground());
            if (newColor != null) {
                textArea.setForeground(newColor);
            }
        });
        // Choix de la couleur de fond
        bgColorButton.addActionListener(e -> {
            Color newColor = JColorChooser.showDialog(
                    TextPanel.this, "Choisir Couleur de Fond", textArea.getBackground());
            if (newColor != null) {
                textArea.setBackground(newColor);
            }
        });

        topPanel.add(textColorButton);
        topPanel.add(bgColorButton);

        // Ajouter les composants au panel de texte
        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        // Définir une largeur préférée pour la zone de texte (hauteur flexible)
        setPreferredSize(new Dimension(250, 0));
    }

    // (Optionnel) Méthode pour récupérer la zone de texte si besoin d'interactions externes
    public JTextArea getTextArea() {
        return textArea;
    }
}