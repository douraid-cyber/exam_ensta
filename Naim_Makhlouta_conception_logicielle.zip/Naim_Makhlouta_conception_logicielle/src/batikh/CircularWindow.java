package batikh;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CircularWindow extends JFrame {
    private int mouseX, mouseY;
    private JPanel colorPanel;
    private JSlider colorSlider;
    private JCheckBox redCheck, greenCheck, blueCheck, alphaCheck;

    public CircularWindow() {
        setSize(300, 300);
        setUndecorated(true);
        setBackground(new Color(0, 0, 0, 0));
        setLayout(new BorderLayout());

        // Panel to hold components
        colorPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Enable Anti-Aliasing
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(getBackground());
                g2d.fillOval(0, 0, getWidth(), getHeight());
            }
        };
        colorPanel.setOpaque(false);
        add(colorPanel, BorderLayout.CENTER);

        // Close Button
        JButton closeButton = new JButton("X");
        closeButton.setBounds(250, 10, 40, 30);
        closeButton.setBackground(Color.RED);
        closeButton.setForeground(Color.WHITE);
        closeButton.addActionListener(e -> dispose());

        // Slider to modify color intensity
        colorSlider = new JSlider(0, 255, 128);
        colorSlider.setBounds(50, 220, 200, 30);
        colorSlider.addChangeListener(e -> updateBackgroundColor());

        // Checkboxes for RGB and Alpha channels
        redCheck = new JCheckBox("R");
        greenCheck = new JCheckBox("G");
        blueCheck = new JCheckBox("B");
        alphaCheck = new JCheckBox("Alpha");
        
        JPanel checkPanel = new JPanel();
        checkPanel.add(redCheck);
        checkPanel.add(greenCheck);
        checkPanel.add(blueCheck);
        checkPanel.add(alphaCheck);

        colorPanel.setLayout(null);
        colorPanel.add(closeButton);
        colorPanel.add(colorSlider);
        add(checkPanel, BorderLayout.SOUTH);

        // Enable dragging window
        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen() - mouseX;
                int y = e.getYOnScreen() - mouseY;
                setLocation(x, y);
            }
        });

        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
            }
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void updateBackgroundColor() {
        int value = colorSlider.getValue();
        int r = redCheck.isSelected() ? value : 128;
        int g = greenCheck.isSelected() ? value : 128;
        int b = blueCheck.isSelected() ? value : 128;
        int a = alphaCheck.isSelected() ? value : 255;

        colorPanel.setBackground(new Color(r, g, b, a));
        colorPanel.repaint();
    }
}
