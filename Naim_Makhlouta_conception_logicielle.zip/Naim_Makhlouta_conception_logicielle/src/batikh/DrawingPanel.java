package batikh;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class DrawingPanel extends JPanel {
    private int lastX, lastY;
    
    // List to store all drawn lines along with their properties
    private final List<DrawnLine> linesList = new ArrayList<>();
    
    // Current drawing properties
    private Color currentColor = Color.BLACK;
    private float currentWidth = 2f;
    private boolean dashed = false;

    // Class to store a single drawn line with its properties
    private static class DrawnLine {
        int x1, y1, x2, y2;
        Color color;
        float width;
        boolean dashed;

        DrawnLine(int x1, int y1, int x2, int y2, Color color, float width, boolean dashed) {
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
            this.color = color;
            this.width = width;
            this.dashed = dashed;
        }
    }

    public DrawingPanel() {
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createTitledBorder("Zone de dessin"));
        setPreferredSize(new Dimension(0, 400));

        // Mouse listener to start a line
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                lastX = e.getX();
                lastY = e.getY();
            }
        });

        // Mouse motion listener to draw lines
        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                // Store each line with its current properties
                linesList.add(new DrawnLine(lastX, lastY, x, y, currentColor, currentWidth, dashed));
                lastX = x;
                lastY = y;
                repaint();
            }
        });

        // Enable undo with "Ctrl + Z"
        setFocusable(true);
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.isControlDown() && e.getKeyCode() == KeyEvent.VK_Z && !linesList.isEmpty()) {
                    linesList.remove(linesList.size() - 1);
                    repaint();
                }
            }
        });
    }

    // Setters to change drawing properties (only affect new lines)
    public void setCurrentColor(Color c) {
        currentColor = c;
    }

    public void setStrokeWidth(float w) {
        currentWidth = w;
    }

    public void setDashed(boolean d) {
        dashed = d;
    }

    // Clear all drawings
    public void clearDrawing() {
        linesList.clear();
        repaint();
    }

    // Create a clear button
    public JButton getClearButton() {
        JButton clearButton = new JButton("Clear");
        clearButton.addActionListener(e -> clearDrawing());
        return clearButton;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g.create();

        // Draw all stored lines with their individual properties
        for (DrawnLine line : linesList) {
            Stroke stroke;
            if (line.dashed) {
                float[] dashPattern = {10f, 10f};
                stroke = new BasicStroke(line.width, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 10f, dashPattern, 0f);
            } else {
                stroke = new BasicStroke(line.width, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
            }
            g2d.setStroke(stroke);
            g2d.setColor(line.color);
            g2d.drawLine(line.x1, line.y1, line.x2, line.y2);
        }

        g2d.dispose();
    }
}
