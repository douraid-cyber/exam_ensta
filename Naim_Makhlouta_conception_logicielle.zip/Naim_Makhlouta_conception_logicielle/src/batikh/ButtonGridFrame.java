package batikh;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ButtonGridFrame extends JFrame {
    public ButtonGridFrame() {
        setTitle("Interface 2 : 100 Boutons");
        setLayout(new GridLayout(10, 10, 5, 5)); // Added spacing between buttons
        setBackground(new Color(50, 50, 50)); // Darker background for contrast

        // Création des 100 boutons avec un design amélioré
        for (int i = 1; i <= 100; i++) {
            JButton button = new JButton(String.valueOf(i));
            
            // **Button Styling**
            button.setFont(new Font("Arial", Font.BOLD, 14));
            button.setForeground(Color.WHITE);
            button.setBackground(new Color(70, 130, 180)); // Steel blue
            button.setOpaque(true);
            button.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 2));
            
            // Hover effect: Change color on hover
            button.addMouseListener(new MouseAdapter() {
                private final Color originalColor = button.getBackground();
                @Override
                public void mouseEntered(MouseEvent e) {
                    button.setBackground(originalColor.darker());
                }
                @Override
                public void mouseExited(MouseEvent e) {
                    button.setBackground(originalColor);
                }
            });

            // **Special behavior for button 22**
            if (i == 22) {
                button.setBackground(new Color(200, 0, 0)); // Red
                final JButton specialButton = button;
                final Color origColor = specialButton.getBackground();

                // Special hover effect
                specialButton.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseEntered(MouseEvent e) {
                        specialButton.setBackground(Color.RED.brighter());
                    }
                    @Override
                    public void mouseExited(MouseEvent e) {
                        specialButton.setBackground(origColor);
                    }
                });

                // Open a new custom window when button 22 is clicked
                specialButton.addActionListener(e -> {
                    JFrame customFrame = new JFrame("Fenêtre personnalisée");
                    customFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    customFrame.setSize(300, 150);
                    customFrame.getContentPane().setBackground(Color.LIGHT_GRAY);
                    customFrame.setLayout(new BorderLayout());
                    
                    JLabel label = new JLabel("Merci d'avoir cliqué sur le bouton 22 !", JLabel.CENTER);
                    label.setFont(new Font("Serif", Font.BOLD, 16));
                    customFrame.add(label, BorderLayout.CENTER);

                    // Custom button inside the pop-up
                    JButton jbt = new JButton("Test");
                    jbt.setFont(new Font("Arial", Font.BOLD, 12));
                    jbt.setBackground(new Color(50, 205, 50)); // Lime green
                    jbt.setForeground(Color.WHITE);
                    jbt.setBorderPainted(false);
                    jbt.setFocusPainted(false);

                    jbt.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            if (jbt.getText().equals("Test")) {
                                jbt.setBackground(Color.GREEN);
                                jbt.setText("OK");
                            } else {
                                jbt.setText("Test");
                                jbt.setBackground(new Color(50, 205, 50)); // Reset to lime green
                            }
                        }
                    });

                    customFrame.add(jbt, BorderLayout.SOUTH);
                    customFrame.setLocationRelativeTo(ButtonGridFrame.this);
                    customFrame.setVisible(true);
                });
            }

            add(button);
        }

        // Ajuster la taille de la fenêtre au contenu et configurer la fermeture
        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
