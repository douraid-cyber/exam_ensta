package batikh;

import javax.swing.*;
import java.awt.*;

public class InfoFormDialog extends JDialog {
    private JTextField nomField, prenomField, ageField, ecoleField;
    private JLabel resultLabel;

    public InfoFormDialog() {
        setTitle("Formulaire d'Informations");
        setModal(true);
        setSize(300, 250);
        setLayout(new BorderLayout());
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel formPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Champs de saisie
        formPanel.add(new JLabel("Nom:"));
        nomField = new JTextField();
        formPanel.add(nomField);

        formPanel.add(new JLabel("Prénom:"));
        prenomField = new JTextField();
        formPanel.add(prenomField);

        formPanel.add(new JLabel("Âge:"));
        ageField = new JTextField();
        formPanel.add(ageField);

        formPanel.add(new JLabel("École:"));
        ecoleField = new JTextField();
        formPanel.add(ecoleField);

        add(formPanel, BorderLayout.NORTH);

        // Label pour afficher le résultat
        resultLabel = new JLabel(" ", SwingConstants.CENTER);
        add(resultLabel, BorderLayout.CENTER);

        // Panel pour les boutons
        JPanel buttonPanel = new JPanel();

        // Bouton "OK"
        JButton okButton = new JButton("OK");
        okButton.addActionListener(e -> {
            // Récupérer le texte et l'afficher
            resultLabel.setText(nomField.getText() + ", " +
                                prenomField.getText() + ", " +
                                ageField.getText() + ", " +
                                ecoleField.getText());
        });

        // Bouton "Fermer"
        JButton closeButton = new JButton("Fermer");
        closeButton.addActionListener(e -> dispose()); // Ferme uniquement la boîte de dialogue

        // Ajouter les boutons au panel
        buttonPanel.add(okButton);
        buttonPanel.add(closeButton);

        add(buttonPanel, BorderLayout.SOUTH);

        // Afficher la fenêtre au centre
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
