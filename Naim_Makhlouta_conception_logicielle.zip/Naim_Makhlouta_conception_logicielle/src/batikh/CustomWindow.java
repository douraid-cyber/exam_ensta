package batikh;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CustomWindow extends JFrame {
    private int mouseX, mouseY;
    
    // Dimensions
    private final int RECT_WIDTH = 150;
    private final int RECT_HEIGHT = 150;
    private final int CIRCLE_RADIUS = 80; // Circle size
    private final int BUTTON_SIZE = 40;   // Regular rectangular buttons

    // Positioning
    private final int RECT_X = 120;
    private final int RECT_Y = 80;
    private final int CIRCLE_X1 = RECT_X - CIRCLE_RADIUS / 2;  // Bottom-Left Circle
    private final int CIRCLE_Y1 = RECT_Y + RECT_HEIGHT - CIRCLE_RADIUS / 2;
    private final int CIRCLE_X2 = RECT_X + RECT_WIDTH - CIRCLE_RADIUS / 2; // Top-Right Circle
    private final int CIRCLE_Y2 = RECT_Y - CIRCLE_RADIUS / 2;
    private final int CIRCLE_X3 = CIRCLE_X2 + CIRCLE_RADIUS / 4; // Adjusted for better intersection
    private final int CIRCLE_Y3 = CIRCLE_Y2 - CIRCLE_RADIUS / 2; 

    // **New Center Circle (Centered on Rectangle)**
    private final int CIRCLE_CENTER_X = RECT_X + RECT_WIDTH / 2 - CIRCLE_RADIUS / 2;
    private final int CIRCLE_CENTER_Y = RECT_Y + RECT_HEIGHT / 2 - CIRCLE_RADIUS / 2;

    public CustomWindow() {
        setSize(500, 400);
        setUndecorated(true);
        setBackground(new Color(0, 0, 0, 0));
        setLayout(null);

        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen() - mouseX;
                int y = e.getYOnScreen() - mouseY;
                setLocation(x, y);
            }
        });

        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
            }
        });

        // **Close Button (X)**
        JButton closeButton = new JButton("X");
        closeButton.setBounds(CIRCLE_X1 + CIRCLE_RADIUS / 2 - BUTTON_SIZE / 2, CIRCLE_Y1 + CIRCLE_RADIUS / 2 - BUTTON_SIZE / 2, BUTTON_SIZE, BUTTON_SIZE);
        closeButton.setBackground(Color.RED);
        closeButton.setForeground(Color.WHITE);
        closeButton.setBorderPainted(true);
        closeButton.setFocusPainted(false);
        closeButton.addActionListener(e -> dispose());
        closeButton.setMargin(new Insets(0, 0, 0, 0));
        add(closeButton);

        // **O Button**
        JButton oButton = new JButton("O");
        oButton.setBounds(CIRCLE_X2 + CIRCLE_RADIUS / 2 - BUTTON_SIZE / 2, CIRCLE_Y2 + CIRCLE_RADIUS / 2 - BUTTON_SIZE / 2, BUTTON_SIZE, BUTTON_SIZE);
        oButton.setBackground(Color.BLUE);
        oButton.setForeground(Color.WHITE);
        oButton.setBorderPainted(true);
        oButton.setFocusPainted(false);
        oButton.setMargin(new Insets(0, 0, 0, 0));
        add(oButton);

        // **Y Button**
        JButton yButton = new JButton("Y");
        yButton.setBounds(CIRCLE_X3 + CIRCLE_RADIUS / 2 - BUTTON_SIZE / 2, CIRCLE_Y3 + CIRCLE_RADIUS / 2 - BUTTON_SIZE / 2, BUTTON_SIZE, BUTTON_SIZE);
        yButton.setBackground(Color.GREEN);
        yButton.setForeground(Color.WHITE);
        yButton.setBorderPainted(true);
        yButton.setFocusPainted(false);
        yButton.setMargin(new Insets(0, 0, 0, 0));
        add(yButton);

        // **Exit Button in Center Circle**
        JButton centerExitButton = new JButton("Exit");
        centerExitButton.setBounds(CIRCLE_CENTER_X + CIRCLE_RADIUS / 2 - BUTTON_SIZE / 2, CIRCLE_CENTER_Y + CIRCLE_RADIUS / 2 - BUTTON_SIZE / 2, BUTTON_SIZE, BUTTON_SIZE);
        centerExitButton.setBackground(Color.BLACK);
        centerExitButton.setForeground(Color.WHITE);
        centerExitButton.setBorderPainted(true);
        centerExitButton.setFocusPainted(false);
        centerExitButton.setMargin(new Insets(0, 0, 0, 0));
        centerExitButton.addActionListener(e -> dispose());
        add(centerExitButton);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // **Main Rectangle**
        g2d.setColor(new Color(80, 80, 80));
        g2d.fillRect(RECT_X, RECT_Y, RECT_WIDTH, RECT_HEIGHT);

        // **Bottom-Left Circle (X Button)**
        g2d.setColor(Color.RED);
        g2d.fillOval(CIRCLE_X1, CIRCLE_Y1, CIRCLE_RADIUS, CIRCLE_RADIUS);

        // **First Top-Right Circle (O Button)**
        g2d.setColor(Color.BLUE);
        g2d.fillOval(CIRCLE_X2, CIRCLE_Y2, CIRCLE_RADIUS, CIRCLE_RADIUS);

        // **Second Top-Right Circle (Y Button)**
        g2d.setColor(Color.GREEN);
        g2d.fillOval(CIRCLE_X3, CIRCLE_Y3, CIRCLE_RADIUS, CIRCLE_RADIUS);

        // **New Center Circle (Different Color)**
        g2d.setColor(Color.MAGENTA); // Different color
        g2d.fillOval(CIRCLE_CENTER_X, CIRCLE_CENTER_Y, CIRCLE_RADIUS, CIRCLE_RADIUS);
    }
}
