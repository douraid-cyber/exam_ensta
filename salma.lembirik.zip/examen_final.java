import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

public class examen_final {

    static int lastx;
    static int lasty;
    static List<int[]> lines = new ArrayList<>();
    private static Color currentColor = Color.BLACK;
    private static ArrayList<Color> colorsList = new ArrayList<>();
    private static ArrayList<Float> strokeWidthsList = new ArrayList<>();
    private static ArrayList<String> strokeStylesList = new ArrayList<>();
    private static String strokeStyle = "CONTINU";
    private static float strokeWidth = 2.0f;
    
    
    

    public static void main(String[] args) {
        JFrame frame = new JFrame("MyBorderLayout");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600); // Taille augmentée pour un meilleur affichage
        frame.setLayout(new BorderLayout(15, 15));

        // === Zone Centrale ===
        JPanel pan1 = new JPanel(new BorderLayout());
        pan1.setBackground(Color.white);
    	pan1.setLayout(new BorderLayout());

        // === Zone Gauche (pan2) ===
     // === Zone Gauche (pan2) ===
    	// === Zone Gauche (pan2) ===
        JPanel pan2 = new JPanel(null);
        pan2.setBackground(Color.LIGHT_GRAY);
        pan2.setPreferredSize(new Dimension(100, 600));

        String[] buttonList = {"1", "2", "3"};

        for (String nom : buttonList) {
            JButton button2 = new JButton(nom);
            button2.setBounds(10, 30 * Integer.parseInt(nom), 50, 30);
            pan2.add(button2);

            // Déclaration des variables pour suivre la position de départ
            final int[] startX = new int[1];
            final int[] startY = new int[1];

            button2.addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    startX[0] = e.getX();
                    startY[0] = e.getY();
                }

                @Override
                public void mouseReleased(MouseEvent e) {
                    if (nom.equals("1")) {
                        createCustomWindow(1);
                    } else if (nom.equals("2")) {
                        createCustomWindow(2);
                    }
                }
            });

            button2.addMouseMotionListener(new MouseMotionAdapter() {
                @Override
                public void mouseDragged(MouseEvent e) {
                    int newX = button2.getX() + e.getX() - startX[0];
                    int newY = button2.getY() + e.getY() - startY[0];

                    newX = Math.max(0, Math.min(newX, pan2.getWidth() - button2.getWidth()));
                    newY = Math.max(0, Math.min(newY, pan2.getHeight() - button2.getHeight()));

                    button2.setLocation(newX, newY);
                }
            });
        }

    
	 // === Zone Droite (pan3) ===
	    JPanel pan3 = new JPanel(new BorderLayout());
	    pan3.setPreferredSize(new Dimension(550, 600));

	    // Zone de texte avec barre de défilement
	    JTextArea jta = new JTextArea("JTextArea");
	    jta.setBackground(Color.LIGHT_GRAY); // Définir une couleur initiale
	    jta.setForeground(Color.BLACK);      // Définir la couleur du texte initiale
	    JScrollPane scrollPane = new JScrollPane(jta);
	    pan3.add(scrollPane, BorderLayout.CENTER);

	    // === Ajout des boutons de couleur ===
	    JPanel colorPanel = new JPanel(new GridLayout(2, 2)); // 2 lignes, 2 colonnes

	    // Boutons pour changer la couleur du fond du JTextArea
	    JButton btnBgWhite = new JButton("B");
	    JButton btnBgGreen = new JButton("V");

	    // Boutons pour changer la couleur du texte
	    JButton btnTextBlack = new JButton("N");
	    JButton btnTextRed = new JButton("R");

	    // Actions pour changer la couleur du fond du JTextArea
	    btnBgWhite.addActionListener(e -> jta.setBackground(Color.WHITE));
	    btnBgGreen.addActionListener(e -> jta.setBackground(Color.green));

	    // Actions pour changer la couleur du texte
	    btnTextBlack.addActionListener(e -> jta.setForeground(Color.BLACK));
	    btnTextRed.addActionListener(e -> jta.setForeground(Color.RED));

	    // Ajout des boutons au panel sud
	    colorPanel.add(btnBgWhite);
	    colorPanel.add(btnBgGreen);
	    colorPanel.add(btnTextBlack);
	    colorPanel.add(btnTextRed);

	    pan3.add(colorPanel, BorderLayout.SOUTH);

        
	    

        // === Zone Haut (pan4) ===
        JPanel pan4 = new JPanel();
        pan4.setBackground(Color.pink);
        pan4.setPreferredSize(new Dimension(800, 50));

        // === Zone Bas (pan5) ===
        JPanel pan5 = new JPanel();
        pan5.setBackground(Color.pink);
        pan5.setPreferredSize(new Dimension(800, 50));

        // === Zone Outils (bas du centre) ===
        JPanel pan11 = new JPanel();
        pan11.setBackground(Color.white);
        pan11.setPreferredSize(new Dimension(200, 100));
        pan11.setLayout(new BorderLayout());

        // === Barre de couleurs ===
        JPanel pan111 = new JPanel();
        pan111.setLayout(new GridLayout(1, 12));

        Color[] colors = {
            Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE,
            Color.MAGENTA, Color.PINK, Color.LIGHT_GRAY, Color.DARK_GRAY, Color.BLACK, Color.WHITE
        };

        for (Color color : colors) {
            JButton button = new JButton();
            button.setBackground(color);
            button.setOpaque(true);
            button.setBorderPainted(false);
            button.setPreferredSize(new Dimension(50, 50));

            button.addActionListener(e -> {
                currentColor = color;
                System.out.println("Couleur du stylo sélectionnée : " + color);
            });

            pan111.add(button);
        }

        // === Boutons pour le style de trait (Continu / Pointillé) ===
        JPanel pan112 = new JPanel();
        JButton btnContinu = new JButton("Continu");
        JButton btnPointille = new JButton("Pointillé");

        btnContinu.addActionListener(e -> {
            strokeStyle = "CONTINU";
            System.out.println("Trait sélectionné : Continu");
        });

        btnPointille.addActionListener(e -> {
            strokeStyle = "POINTILLE";
            System.out.println("Trait sélectionné : Pointillé");
        });

        pan112.add(btnContinu);
        pan112.add(btnPointille);

        // === Boutons pour l'épaisseur du trait ===
        JPanel pan113 = new JPanel();
        JButton btnFin = new JButton("Fin");
        JButton btnMoyen = new JButton("Moyen");
        JButton btnEpais = new JButton("Épais");

        btnFin.addActionListener(e -> {
            strokeWidth = 1.0f;
            System.out.println("Épaisseur du trait : Fin");
        });

        btnMoyen.addActionListener(e -> {
            strokeWidth = 3.0f;
            System.out.println("Épaisseur du trait : Moyen");
        });

        btnEpais.addActionListener(e -> {
            strokeWidth = 6.0f;
            System.out.println("Épaisseur du trait : Épais");
        });

        pan113.add(btnFin);
        pan113.add(btnMoyen);
        pan113.add(btnEpais);

        // === Zone de dessin ===
        JPanel pan12 = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();

                for (int i = 0; i < lines.size(); i++) {
                    g2d.setColor(colorsList.get(i));
                    float thickness = strokeWidthsList.get(i);
                    String style = strokeStylesList.get(i);

                    if (style.equals("POINTILLE")) {
                        float[] dashPattern = {10, 10};
                        g2d.setStroke(new BasicStroke(thickness, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 10, dashPattern, 0));
                    } else {
                        g2d.setStroke(new BasicStroke(thickness));
                    }

                    int[] line = lines.get(i);
                    g2d.drawLine(line[0], line[1], line[2], line[3]);
                }
            }
        };
        pan12.setBackground(Color.white);
        pan12.setPreferredSize(new Dimension(600, 400));

        // === Gestion de la souris ===
        pan12.addMouseListener(new MouseListener() {
            @Override
            public void mousePressed(MouseEvent e) {
                lastx = e.getX();
                lasty = e.getY();
            }

            @Override
            public void mouseReleased(MouseEvent e) {}

            @Override
            public void mouseExited(MouseEvent e) {}

            @Override
            public void mouseEntered(MouseEvent e) {}

            @Override
            public void mouseClicked(MouseEvent e) {}
        });

        pan12.addMouseMotionListener(new MouseMotionListener() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                lines.add(new int[]{lastx, lasty, x, y});
                colorsList.add(currentColor);
                strokeWidthsList.add(strokeWidth);
                strokeStylesList.add(strokeStyle);

                lastx = x;
                lasty = y;
                pan12.repaint();
            }

            @Override
            public void mouseMoved(MouseEvent e) {}
        });
        
    
     // === Création d'un onglet supplémentaire dans le panel de droite  =
        JTabbedPane tabbedPane = new JTabbedPane();

        // === Premier onglet : Zone de texte avec boutons de couleur ===
        JPanel onglet1 = new JPanel(new BorderLayout());
        onglet1.add(scrollPane, BorderLayout.CENTER);
        onglet1.add(colorPanel, BorderLayout.SOUTH);

       
        JPanel onglet2 = new JPanel(new GridLayout(10, 10));
        onglet2.setBackground(Color.BLACK);

        for (int i = 1; i <= 100; i++) {
            JButton btn = new JButton(String.valueOf(i)); // Numéro du bouton
            btn.setBackground(Color.white);
            
            // Capture correcte de la valeur actuelle de i
            int buttonNumber = i; 
            
            btn.addActionListener(e -> {
                if (buttonNumber == 22) { 
                	framepoly newFrame = new framepoly();
                    newFrame.setVisible(true);
                    
                    
                    btn.addMouseListener(new MouseListener() {
						
						@Override
						public void mouseReleased(MouseEvent e) {
							// TODO Auto-generated method stub
							
						}
						
						@Override
						public void mousePressed(MouseEvent e) {
							// TODO Auto-generated method stub
							
						}
						
						@Override
						public void mouseExited(MouseEvent e) {
							// TODO Auto-generated method stub
							btn.setBackground(Color.white);
							
							
						}
						
						@Override
						public void mouseEntered(MouseEvent e) {
							// TODO Auto-generated method stub
							btn.setBackground(Color.red );
							
						}
						
						@Override
						public void mouseClicked(MouseEvent e) {
							// TODO Auto-generated method stub
							
						}
					});
                }
            });

            onglet2.add(btn); // Ajoute le bouton au panel
            
      
        }
        
        // === Ajout des onglets au JTabbedPane ===
        tabbedPane.addTab("onglet 1", onglet1);
        tabbedPane.addTab("onglet 2", onglet2);

        // === Ajout du JTabbedPane dans pan3 ===
        pan3.setLayout(new BorderLayout());  // Assurer un bon affichage
        pan3.add(tabbedPane, BorderLayout.CENTER);
        
       

        

        
   


        

        // === Ajout des panneaux outils ===
        pan11.add(pan111, BorderLayout.NORTH);
        pan11.add(pan112, BorderLayout.WEST);
        pan11.add(pan113, BorderLayout.CENTER);

        // === Assemblage final ===
        pan1.add(pan12, BorderLayout.CENTER);
        pan1.add(pan11, BorderLayout.SOUTH);

        frame.add(pan1, BorderLayout.CENTER);
        frame.add(pan2, BorderLayout.WEST);
        frame.add(pan3, BorderLayout.EAST);
        frame.add(pan4, BorderLayout.NORTH);
        frame.add(pan5, BorderLayout.SOUTH);

        frame.setVisible(true);
    }
   
    private static void createCustomWindow(int type) {
        JDialog dialog = new JDialog();
        dialog.setUndecorated(true);
        dialog.setBackground(new Color(0, 0, 0, 0));
        dialog.setOpacity(0.4f);
        
        dialog.setSize(200, 200);
        dialog.setLocationRelativeTo(null);
        

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setColor(Color.BLUE);
                if (type == 1) {
                    g2d.fillRoundRect(10, 10, 180, 180, 30, 30);
                } else if (type == 2) {
                    g2d.fillOval(10, 10, 180, 180);
                }
            }
        };
        panel.setLayout(null);

        // Bouton de fermeture "X"
        JButton closeButton = new JButton("X");
        closeButton.setBounds(160, 10, 30, 30); // Position en haut à droite
        closeButton.setBorder(null);
        closeButton.setFocusPainted(false);
        closeButton.setBackground(Color.RED);
        closeButton.setForeground(Color.WHITE);
        
        closeButton.addActionListener(e -> dialog.dispose());

        panel.add(closeButton);
        dialog.add(panel);
        dialog.setVisible(true);
    }


    
    
}

