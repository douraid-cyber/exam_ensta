import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class FramePoly extends JFrame {
    private static int mouseX;
    private static int mouseY;

    public FramePoly() {
        setSize(1200, 800);
        setLayout(null);
        setLocation(300, 150);
        setUndecorated(true);
        setLayout(null);
        
        // Forme polygonale
        RoundRectangle2D rect = new RoundRectangle2D.Double(200, 200, 400, 300, 20, 20); // Rectangle au centre
        Ellipse2D circle1 = new Ellipse2D.Double(100, 500, 100, 100);  // Cercle en bas à gauche
        Ellipse2D circle2 = new Ellipse2D.Double(500, 100, 100, 100);  // Cercle au milieu

        Ellipse2D circle3 = new Ellipse2D.Double(600, 0, 100, 100); 
        
        addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen() - mouseX;
                int y = e.getYOnScreen() - mouseY;
                setLocation(x, y);
            }
        });

        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
            }
        });

        
        
        Area polygonArea = new Area(rect);
        polygonArea.add(new Area(circle1));
        polygonArea.add(new Area(circle2));
        polygonArea.add(new Area(circle3));

        setShape(polygonArea);

        

        // je defini les centre pour m'aider prcque je me perd rapidement
     
        int rect_centre_X = 200 + 400 / 2; // X central du rectangle
        int rect_cente_Y = 200 + 300 / 2; // Y central du rectangle
        
        int cercle1_centre_X = 100 + 100 / 2;
        int cercle1_centre_Y = 500 + 100 / 2;

        int cercle2_centre_X = 500 + 100 / 2;
        int cercle2_centre_Y = 100 + 100 / 2;

        int cercle3_centre_X = 600 + 100 / 2;
        int cercle3_centre_Y = 0 + 100 / 2;


        JButton btnX = createButton("X", cercle1_centre_X - 20, cercle1_centre_Y - 20, Color.BLUE);
        JButton btnO = createButton("O", cercle2_centre_X - 20, cercle2_centre_Y - 20, Color.GREEN);
        JButton btnY = createButton("Y", cercle3_centre_X - 20, cercle3_centre_Y - 20, Color.RED);
        JButton btnStar = createButton("★", rect_centre_X - 20, rect_cente_Y - 20, Color.YELLOW);
        
        JButton[] buttons = {btnX, btnO, btnY, btnStar};
        for (JButton button : buttons) {
            button.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseExited(MouseEvent e) {
                    button.setBackground(Color.RED);
                }

                @Override
                public void mouseEntered(MouseEvent e) {
                    button.setBackground(Color.BLACK);
                }
            });

            if (button == btnStar) {
                button.addActionListener(e -> dispose()); // Ferme la fenêtre quand on clique sur btnStar
            }
        }

        

        // Ajout des boutons
        add(btnX);
        add(btnO);
        add(btnY);
        add(btnStar);

        // Comme les fonctions ici étaient déjà implémenter dans le TP dernier j'y ai pas touché (ça permet de drag la fenêtre)
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
            }
        });

        addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen() - mouseX;
                int y = e.getYOnScreen() - mouseY;
                setLocation(x, y);
            }
        });

        setVisible(true);
    }

    private JButton createButton(String text, int x, int y, Color color) {
    	// Ici j'ai demander à l'IA de me faire un rendu plus jolie, donc tout ne vient pas de moi
        JButton button = new JButton(text);
        button.setBounds(x, y, 40, 40);
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        return button;
    }

    

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;

        
        // Quality
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        
        int w = getWidth();
        int h = getHeight();

        int [] xpoints1 = {10, w/2, w/2-2, w-3, w-3, w,w,w-10,w/2,w/2-2,3,3,0,0};
        int [] ypoints1 = {0, 0, 3, 3, h-(h/3), h-(h/3)+2, h-10, h, h, h-3, h-3, h/3, (h/3)-2, 10};
        
        Polygon poly1 = new Polygon(xpoints1, ypoints1, ypoints1.length);
        
        
        int [] xpoints2 = {14, w/2-4, w/2-2, w-4, w-4, w-6, w-6, w-14, w/2-4, w/2-2, 4, 4, 6, 6};
        int [] ypoints2 = {6, 6, 4, 4, h-(h/3), h-(h/3)-3, h-15, h-6, h-6, h-4, h-4, h/3, (h/3)+2, 14};
        
        Polygon poly2 = new Polygon(xpoints2, ypoints2, ypoints2.length);
        
        Area area1 = new Area(poly1);
        Area area2 = new Area(poly2);
        area1.exclusiveOr(area2);
        
        g2d.setColor(Color.blue);
        g2d.fill(area1);
        
        GradientPaint gradient = new GradientPaint(0, 0, Color.red, 350, 150, Color.magenta);
        g2d.setPaint(gradient);
        g2d.fill(poly2);
    }
}
