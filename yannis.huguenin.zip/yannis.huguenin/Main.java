import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JWindow;

public class Main {
    static int lastX;
    static int lastY;
    static Color selectedColor = Color.BLACK; // Noir par défautt
    static int selectedThickness = 5;
    static float[] selectedType = {}; // Par défaut on prend trait plein

    // Liste des couleurs et des boutons dans menu deroulant
    static Color[] colors = {Color.RED, Color.BLUE, Color.GREEN, Color.BLACK, Color.CYAN};
    static String[] colorslist = {"Rouge", "Bleu", "Vert", "Noir", "Cyan"};

    // Liste des epaisseurs
    static String[] thicknessOptions = {"1", "3", "5", "8"};

    // Options pour le type de trait
    static String[] lineStyles = {"Plein", "Pointillé"};
    static float[][] strokePatterns = {
            {}, 
            {5.0f, 5.0f} 
    };

    // Liste des lignes dessinées avec leur style speficique
    static List<Line> lines = new ArrayList<>();

    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1200, 800);
        frame.setLocationRelativeTo(null);

        // JTabbedPane pour gérer les onglets
        JTabbedPane tabbedPane = new JTabbedPane();

        // 1er onglet : l'interface principalee
        JPanel mainPanel = createMainPanel(); //methode pour pas surcharger
        tabbedPane.addTab("Onglet 1", mainPanel);

        // 2eme onglet : Grille de 100 boutons
        JPanel buttonGridPanel = createButtonGridPanel(); //methode pour pas surcharger
        tabbedPane.addTab("Onglet 2", buttonGridPanel);

        
        frame.add(tabbedPane);
        frame.setVisible(true);
    }

    private static JPanel createMainPanel() {
    	// Au début j'ai juste repris le TP1 avec le BorderLayout, cependant les tailles des zones n'étaient pas proportionnelle et c'était embêtant pour
    	// le dessin par exemple qui avait une très petite zone. J'ai donc regarder sur internet et on m'a conseillé l'utilisation de GridBagLayout
    	// Après j'aurai pu reprendre le TD et faire la zone de dessin au milieu mais c'était mieux comme ça

        JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        
        //------------------------------------------------------------------------------------------------------------------

        // Zone Haut
        JPanel pan_haut = new JPanel();
        pan_haut.setBackground(Color.BLUE);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        gbc.weightx = 1.0;
        gbc.weighty = 0.2;
        mainPanel.add(pan_haut, gbc);

        // Création de trois boutons déplaçables
        for (int i = 0; i < 3; i++) {
            JButton button = new JButton("Bouton " + (i + 1));
            button.setBounds(50 + i * 120, 10, 100, 30);

            if (i == 0) {
                button.addActionListener(e -> {
                    JFrame formulaire = new JFrame();
                    formulaire.setSize(300, 200);
                    formulaire.setLayout(new GridLayout(5, 2)); // J'utilise un gridlayout car strcuture de tableau

                    JTextField nomField = new JTextField();
                    JTextField prenomField = new JTextField();
                    JTextField ageField = new JTextField();
                    JTextField ecoleField = new JTextField();
                    JLabel resultLabel = new JLabel();

                    formulaire.add(new JLabel("Nom:"));
                    formulaire.add(nomField);
                    formulaire.add(new JLabel("Prénom:"));
                    formulaire.add(prenomField);
                    formulaire.add(new JLabel("Âge:"));
                    formulaire.add(ageField);
                    formulaire.add(new JLabel("École:"));
                    formulaire.add(ecoleField);

                    JButton okButton = new JButton("OK");
                    okButton.addActionListener(ev -> {
                        resultLabel.setText("[" + nomField.getText() + ", " + prenomField.getText() + ", " + ageField.getText() + ", " + ecoleField.getText() + "]");
                    });

                    formulaire.add(okButton);
                    formulaire.add(resultLabel);
                    formulaire.setVisible(true);
                });
            } else if (i == 1) {
                button.addActionListener(e -> {
                	// La fenetre en forme d'ellipse
                	// Je vais être honnête, pour créer cette fenêtre ChatGPT m'a aidé : au début j'utilisais un JFrame classique comme celle d'avant
        			// Mais ça ne fonctionnait pas... Quand j'ai demander pourquoi mon code ne fonctionnait pas il m'a proposer une fenêtre et ça marche mieux
        			// Pour la gestion du Slider, je ne connaissais mais comme obenir la valeur et on m'a proposer d'utiliser un changelistener (ce qui semble
        			// plutot logique)
        			// J'ai eu des problèmes de troncature de fenêtre aussi, car mon JPanel ne s'étend pas automatiquement à la taille de la fenêtre circulaire
                	// On m'a proposé d'utiliser un FlowLayout pour remédier au probleme

                    JWindow fenetre = new JWindow();
                    fenetre.setSize(300, 300);
                    fenetre.setShape(new Ellipse2D.Double(0, 0, 300, 300));
                    fenetre.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));

                    JPanel cercle = new JPanel();
                    cercle.setOpaque(false);
                    cercle.setPreferredSize(new Dimension(280, 280));

                    JSlider slider = new JSlider(0, 255, 127);
                    slider.setPreferredSize(new Dimension(220, 50));
                    slider.setMajorTickSpacing(50);
                    slider.setPaintTicks(true);
                    slider.setPaintLabels(true);

                    JCheckBox checkR = new JCheckBox("Rouge", true);
                    JCheckBox checkG = new JCheckBox("Vert", false);
                    JCheckBox checkB = new JCheckBox("Bleu", false);
                    JCheckBox checkA = new JCheckBox("Alpha (Transparence)", false);

                    JButton closeButton = new JButton("Fermer");
                    closeButton.addActionListener(event -> fenetre.dispose());

                    cercle.add(slider);
                    cercle.add(checkR);
                    cercle.add(checkG);
                    cercle.add(checkB);
                    cercle.add(checkA);
                    cercle.add(closeButton);

                    fenetre.add(cercle);
                    fenetre.setLocationRelativeTo(null);

                    slider.addChangeListener(evt -> {
                        int value = slider.getValue();
                        int r = checkR.isSelected() ? value : 127;
                        int g = checkG.isSelected() ? value : 127;
                        int b = checkB.isSelected() ? value : 127;
                        int a = checkA.isSelected() ? value : 255;

                        fenetre.getContentPane().setBackground(new Color(r, g, b, a));
                    });

                    fenetre.setVisible(true);
                });
            } else if (i == 2) {
            	// Ici j'utilise des fragments du dernier TP où on avait définit une classe FramePoly pour créer un fenetre avec une forme particulière
                button.addActionListener(e -> {
                    FramePoly frame_bizarre = new FramePoly();
                    frame_bizarre.setVisible(true);
                });
            }

            button.addMouseListener(new MouseAdapter() {
                int offsetX, offsetY;

                @Override
                public void mousePressed(MouseEvent e) {
                    offsetX = e.getX();
                    offsetY = e.getY();
                }

                @Override
                public void mouseReleased(MouseEvent e) {
                    JButton button = (JButton) e.getSource();
                    int newX = button.getX() + e.getX() - offsetX;
                    int newY = button.getY() + e.getY() - offsetY;

                    if (newX < 0) newX = 0;
                    if (newY < 0) newY = 0;
                    if (newX + button.getWidth() > pan_haut.getWidth()) newX = pan_haut.getWidth() - button.getWidth();
                    if (newY + button.getHeight() > pan_haut.getHeight()) newY = pan_haut.getHeight() - button.getHeight();

                    button.setLocation(newX, newY);
                }
            });
            pan_haut.add(button);
        }
        gbc.fill = GridBagConstraints.BOTH;
        mainPanel.add(pan_haut, gbc);
        
        
        //------------------------------------------------------------------------------------------------------------------

        // Zone Gauche        
        // On reprend le TD sur la surcharge de la méthode paintComponent pour dessiner
        JPanel pan_gauche = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();

                for (Line line : lines) {
                    if (line.strokePattern.length == 0) {
                        g2d.setStroke(new BasicStroke(line.thickness));
                    } else {
                        g2d.setStroke(new BasicStroke(line.thickness, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, line.strokePattern, 0));
                    }

                    g2d.setColor(line.color);
                    g2d.drawLine(line.x1, line.y1, line.x2, line.y2);
                }

                g2d.dispose();
            }
        };

        pan_gauche.setBackground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.weightx = 0.2;
        gbc.weighty = 0.6;
        mainPanel.add(pan_gauche, gbc);

        pan_gauche.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                lastX = e.getX();
                lastY = e.getY();
            }
        });

        pan_gauche.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();

                lines.add(new Line(lastX, lastY, x, y, selectedColor, selectedThickness, selectedType));

                lastX = x;
                lastY = y;
                pan_gauche.repaint();
            }
        });
        
        // Creation du menu déroulant des couleurs :
        JComboBox<String> couleurMenu = new JComboBox<>(colorslist);
        couleurMenu.addActionListener(e -> {
            int selectedIndex = couleurMenu.getSelectedIndex();
            selectedColor = colors[selectedIndex];
        });
        
        // Creation du menuu déroulant pour choisir l'épaisseur
        JComboBox<String> epaisseurMenu = new JComboBox<>(thicknessOptions);
        epaisseurMenu.addActionListener(e -> {
            selectedThickness = Integer.parseInt((String) epaisseurMenu.getSelectedItem());
        });
        
        // Création du menu déroulant pour choisir le type de trait
        JComboBox<String> styleMenu = new JComboBox<>(lineStyles);
        styleMenu.addActionListener(e -> {
            int selectedIndex = styleMenu.getSelectedIndex();
            selectedType = strokePatterns[selectedIndex];
        });

        pan_gauche.add(epaisseurMenu);
        pan_gauche.add(couleurMenu);
        pan_gauche.add(styleMenu);

        pan_gauche.setFocusable(true);
        mainPanel.add(pan_gauche, gbc);

        
        
        //------------------------------------------------------------------------------------------------------------------

        // Zone Centre
        JPanel pan_centre = new JPanel(new BorderLayout());
        pan_centre.setBackground(Color.GREEN);
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.weightx = 0.6;
        gbc.weighty = 0.6;
        mainPanel.add(pan_centre, gbc);
        
        // Zone de texte avec le Jscroll si il  y a depassement
        JTextArea textArea = new JTextArea();
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        pan_centre.add(scrollPane, BorderLayout.CENTER);
        
        // Menu deroulant pour changer la couleur du texte
        JComboBox<String> textColorMenu = new JComboBox<>(colorslist);
        textColorMenu.addActionListener(e -> {
            int selectedIndex = textColorMenu.getSelectedIndex();
            textArea.setForeground(colors[selectedIndex]);
        });
        
        // Menu deroulant pour changer la couleur du fond
        JComboBox<String> fondColorMenu = new JComboBox<>(colorslist);
        fondColorMenu.addActionListener(e -> {
            int selectedIndex = fondColorMenu.getSelectedIndex();
            textArea.setBackground(colors[selectedIndex]);
        });
        
        //J'ai créé un nouveau panel pour ajouter les options de couleur de fond et de txt
        JPanel optionsPanel = new JPanel();
        optionsPanel.add(new JLabel("Texte :"));
        optionsPanel.add(textColorMenu);
        optionsPanel.add(new JLabel("Fond :"));
        optionsPanel.add(fondColorMenu);

        pan_centre.add(optionsPanel, BorderLayout.NORTH);
        mainPanel.add(pan_centre, gbc);

        //------------------------------------------------------------------------------------------------------------------

        // Zone Droite
        JPanel pan_droite = new JPanel();
        pan_droite.setBackground(Color.PINK);
        gbc.gridx = 2;
        gbc.gridy = 1;
        gbc.weightx = 0.2;
        gbc.weighty = 0.6;
        mainPanel.add(pan_droite, gbc);
        
        //------------------------------------------------------------------------------------------------------------------

        // Zone Bas
        JPanel pan_bas = new JPanel();
        pan_bas.setBackground(Color.RED);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 3;
        gbc.weightx = 1.0;
        gbc.weighty = 0.2;
        mainPanel.add(pan_bas, gbc);

        return mainPanel;
    }

    private static JPanel createButtonGridPanel() {
        JPanel panel = new JPanel(new GridLayout(10, 10));

        for (int i = 1; i <= 100; i++) {
            JButton button = new JButton("Bouton " + i);
            if (i == 22) {
                button.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseEntered(MouseEvent e) {
                        button.setBackground(Color.RED);
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                        button.setBackground(null);
                    }

                    @Override
                    public void mouseClicked(MouseEvent e) {
                        openCustomIHM();
                    }
                });
            }
            panel.add(button);
        }

        return panel;
    }

    private static void openCustomIHM() {
        JFrame customFrame = new JFrame("Nouvelle IHM");
        customFrame.setSize(400, 300);
        customFrame.setLocationRelativeTo(null);

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gradient = new GradientPaint(0, 0, Color.BLUE, getWidth(), getHeight(), Color.GREEN);
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        customFrame.add(panel);
        customFrame.setVisible(true);
    }

 // Classe pour stocker une ligne avec sa couleur (j'ia aussi rajouter l'epaisseur et le style)
    static class Line {
        int x1, y1, x2, y2;
        Color color;
        int thickness;
        float[] strokePattern;

        public Line(int x1, int y1, int x2, int y2, Color color, int thickness, float[] strokePattern) {
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
            this.color = color;
            this.thickness = thickness;
            this.strokePattern = strokePattern;
        }
    }
}