package exam;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe principale "pro" :
 * Contient la fenêtre principale (mainFrame) avec 2 onglets :
 * - L'interface principale
 * - Les 100 boutons
 * et gère l'ouverture des 3 boîtes de dialogue (Bouton1 => Info, Bouton2 => Color, Bouton3 => Fenêtre Polygonale).
 */
public class pro {

    public static void main(String[] args) {
        // Lance l'interface graphique
        SwingUtilities.invokeLater(() -> new pro().initUI());
    }

    // La fenêtre principale
    JFrame mainFrame;

    /**
     * Initialise l'interface : crée un JFrame avec onglets
     * et l'affiche.
     */
    private void initUI() {
        mainFrame = new JFrame("Examen Java - Version Alternative 2");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(1000, 700);

        // On crée un JTabbedPane (plusieurs onglets)
        JTabbedPane tabPane = new JTabbedPane();
        tabPane.addTab("Interface Principale", createMainInterface());
        tabPane.addTab("100 Boutons", createHundredButtonsPanel());

        // Ajout des onglets au mainFrame
        mainFrame.add(tabPane);
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
    }

    //--------------------------------------------------------------------------
    //  1) L'onglet "Interface Principale"
    //--------------------------------------------------------------------------
    private JPanel createMainInterface() {
        // Panel principal en BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout(5, 5));

        // Zone Haut : panneau "null layout" avec 3 boutons déplaçables
        JPanel topPanel = new JPanel(null);
        topPanel.setPreferredSize(new Dimension(800, 100));

        // Boutons draggables : "Bouton 1", "Bouton 2", "Bouton 3"
        // Respectivement : ouvre InfoDialog, ColorDialog, PolygonDialog
        addDraggableButton(topPanel, "Bouton 1", 20, 20, 120, 30,
                e -> new InfoDialog(mainFrame).setVisible(true));
        addDraggableButton(topPanel, "Bouton 2", 160, 20, 120, 30,
                e -> new ColorDialog(mainFrame).setVisible(true));
        addDraggableButton(topPanel, "Bouton 3", 300, 20, 120, 30,
                e -> new PolygonDialog(mainFrame).setVisible(true));

        mainPanel.add(topPanel, BorderLayout.NORTH);

        // Zone Centre : un panneau de dessin (DrawingPanel)
        mainPanel.add(new DrawingPanel(), BorderLayout.CENTER);

        // Zone Bas : zone de texte + panneaux de changement de couleur
        JPanel bottomPanel = new JPanel(new BorderLayout());
        JTextArea textArea = new JTextArea(5, 30);
        bottomPanel.add(new JScrollPane(textArea), BorderLayout.CENTER);

        JPanel textControls = new JPanel();
        JButton bgBtn = new JButton("Fond");
        JButton txtBtn = new JButton("Texte");
        textControls.add(bgBtn);
        textControls.add(txtBtn);

        bottomPanel.add(textControls, BorderLayout.SOUTH);

        // Boutons pour changer la couleur de fond ou de texte
        bgBtn.addActionListener(e -> {
            Color c = JColorChooser.showDialog(mainFrame, "Changer fond", textArea.getBackground());
            if (c != null) textArea.setBackground(c);
        });
        txtBtn.addActionListener(e -> {
            Color c = JColorChooser.showDialog(mainFrame, "Changer texte", textArea.getForeground());
            if (c != null) textArea.setForeground(c);
        });

        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        // Zones Gauche et Droite : panneaux colorés
        JPanel leftPanel = new JPanel();
        leftPanel.setBackground(Color.CYAN);
        leftPanel.setPreferredSize(new Dimension(150, 0));
        mainPanel.add(leftPanel, BorderLayout.WEST);

        JPanel rightPanel = new JPanel();
        rightPanel.setBackground(Color.ORANGE);
        rightPanel.setPreferredSize(new Dimension(150, 0));
        mainPanel.add(rightPanel, BorderLayout.EAST);

        return mainPanel;
    }

    /**
     * Ajoute un JButton dans un JPanel en "layout null",
     * positionné à (x,y) de taille (w,h), et rend ce bouton déplaçable à la souris.
     */
    private void addDraggableButton(JPanel panel, String text, int x, int y,
                                    int w, int h, ActionListener action) {
        JButton btn = new JButton(text);
        btn.setBounds(x, y, w, h);
        // Action quand on clique
        btn.addActionListener(action);
        panel.add(btn);

        // Garde en mémoire l'endroit où on a cliqué (pour le drag)
        final Point[] origin = {new Point()};

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                origin[0] = e.getPoint(); // point interne au bouton
            }
        });

        // Quand on fait glisser la souris, on repositionne le bouton
        btn.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                Point loc = btn.getLocation();
                // Calcul du nouvel emplacement (x + déplacement)
                int newX = loc.x + e.getX() - origin[0].x;
                int newY = loc.y + e.getY() - origin[0].y;

                // Contraindre pour ne pas sortir du panel
                newX = Math.max(0, Math.min(newX, panel.getWidth() - btn.getWidth()));
                newY = Math.max(0, Math.min(newY, panel.getHeight() - btn.getHeight()));

                btn.setLocation(newX, newY);
            }
        });
    }

    //--------------------------------------------------------------------------
    //  2) Second onglet : 100 boutons (dont le 22ème ouvre AestheticFrame)
    //--------------------------------------------------------------------------
    private JPanel createHundredButtonsPanel() {
        JPanel panel = new JPanel(new GridLayout(10, 10, 5, 5));

        for (int i = 1; i <= 100; i++) {
            JButton btn = new JButton(String.valueOf(i));

            // Si c'est le 22ème bouton, on lui met un listener spécial
            if (i == 22) {
                btn.addMouseListener(new MouseAdapter() {
                    Color original;
                    @Override
                    public void mouseEntered(MouseEvent e) {
                        // Passe en rouge au survol
                        original = btn.getBackground();
                        btn.setBackground(Color.RED);
                    }
                    @Override
                    public void mouseExited(MouseEvent e) {
                        // Reprend sa couleur initiale
                        btn.setBackground(original);
                    }
                });
                // Clique => ouvre la AestheticFrame
                btn.addActionListener(e -> new AestheticFrame(mainFrame).setVisible(true));
            }
            panel.add(btn);
        }
        return panel;
    }

    //--------------------------------------------------------------------------
    //  3) Bouton 1 : Fenêtre de saisie InfoDialog
    //--------------------------------------------------------------------------
    class InfoDialog extends JDialog {
        public InfoDialog(Frame owner) {
            super(owner, "Formulaire d'Information", true);
            setSize(300, 250);
            setLocationRelativeTo(owner);
            setUndecorated(true);

            // Panneau principal en GridLayout (5 lignes, 2 colonnes)
            JPanel panel = new JPanel(new GridLayout(5, 2, 5, 5));
            panel.setBackground(Color.LIGHT_GRAY);
            panel.setBorder(new LineBorder(Color.BLACK, 2, true));

            panel.add(new JLabel("Nom:"));
            JTextField tfNom = new JTextField();
            panel.add(tfNom);

            panel.add(new JLabel("Prénom:"));
            JTextField tfPrenom = new JTextField();
            panel.add(tfPrenom);

            panel.add(new JLabel("Âge:"));
            JTextField tfAge = new JTextField();
            panel.add(tfAge);

            panel.add(new JLabel("École:"));
            JTextField tfEcole = new JTextField();
            panel.add(tfEcole);

            // Boutons OK et Fermer
            JButton okBtn = new JButton("OK");
            JButton closeBtn = new JButton("Fermer");
            panel.add(okBtn);
            panel.add(closeBtn);

            // Label pour afficher le résultat
            JLabel resultLabel = new JLabel(" ");
            panel.add(resultLabel);

            // Quand on clique sur OK, on récupère le texte des champs
            okBtn.addActionListener(e -> {
                String info = "[" + tfNom.getText() + ", " + tfPrenom.getText() + ", "
                              + tfAge.getText() + ", " + tfEcole.getText() + "]";
                resultLabel.setText(info);
            });

            // Fermer le dialog
            closeBtn.addActionListener(e -> dispose());

            add(panel);
        }
    }

    //--------------------------------------------------------------------------
    //  4) Bouton 2 : Fenêtre circulaire (ColorDialog)
    //--------------------------------------------------------------------------
    class ColorDialog extends JDialog {
        public ColorDialog(Frame owner) {
            super(owner, "Modifier Couleur", true);
            setSize(300, 300);
            setLocationRelativeTo(owner);
            setUndecorated(true);

            // Donne une forme elliptique au JDialog
            setShape(new Ellipse2D.Double(0, 0, 300, 300));

            JPanel panel = new JPanel(new BorderLayout());

            // Un slider de 0 à 255 pour ajuster l'intensité
            JSlider slider = new JSlider(0, 255, 128);
            panel.add(slider, BorderLayout.CENTER);

            // Panel avec des checkboxes : R, G, B, A
            JPanel checkPanel = new JPanel(new FlowLayout());
            JCheckBox cbR = new JCheckBox("R");
            JCheckBox cbG = new JCheckBox("G");
            JCheckBox cbB = new JCheckBox("B");
            JCheckBox cbA = new JCheckBox("Alpha");
            checkPanel.add(cbR); 
            checkPanel.add(cbG); 
            checkPanel.add(cbB); 
            checkPanel.add(cbA);
            panel.add(checkPanel, BorderLayout.NORTH);

            // Petit panneau coloré pour voir la couleur choisie
            JPanel colorPanel = new JPanel();
            colorPanel.setPreferredSize(new Dimension(50, 50));
            colorPanel.setBackground(new Color(128, 128, 128));
            panel.add(colorPanel, BorderLayout.WEST);

            // Bouton fermer
            JButton closeBtn = new JButton("Fermer");
            panel.add(closeBtn, BorderLayout.SOUTH);

            // Quand on bouge le slider, on modifie la couleur
            slider.addChangeListener(e -> {
                int val = slider.getValue();
                Color curr = colorPanel.getBackground();
                int r = curr.getRed(), g = curr.getGreen(), b = curr.getBlue(), a = curr.getAlpha();

                if (cbR.isSelected()) r = val;
                if (cbG.isSelected()) g = val;
                if (cbB.isSelected()) b = val;
                if (cbA.isSelected()) a = val;

                Color newC = new Color(r, g, b, a);
                colorPanel.setBackground(newC);
                panel.setBackground(newC);
            });

            // Ferme la fenêtre
            closeBtn.addActionListener(e -> dispose());

            add(panel);
        }
    }

    //--------------------------------------------------------------------------
    //  5) Bouton 3 : Fenêtre polygonale (carré + 3 cercles)
    //--------------------------------------------------------------------------
    class PolygonDialog extends JDialog {
        public PolygonDialog(Frame owner) {
            super(owner, "Fenêtre Polygonale", true);
            setUndecorated(true);
            setSize(400, 400);
            setLocationRelativeTo(owner);

            // On crée la forme (carré central + 3 cercles)
            Area customShape = createCustomShape();
            setShape(customShape);

            // Panneau contenant 4 boutons (X, O, Y, et étoile)
            PolygonalPanel panel = new PolygonalPanel(this);
            add(panel);
        }

        /**
         * Construit l'Area représentant la forme globale :
         *  - Un carré au centre : (100,100,150,150)
         *  - Un cercle en bas à gauche
         *  - Deux cercles en haut à droite
         */
        private Area createCustomShape() {
            // Le carré
            Area shape = new Area(new Rectangle2D.Double(100, 100, 150, 150));

            // Cercle bas gauche
            shape.add(new Area(new Ellipse2D.Double(60, 220, 80, 80)));

            // Cercle haut droite
            shape.add(new Area(new Ellipse2D.Double(230, 70, 80, 80)));

            // Deuxième cercle haut droite
            shape.add(new Area(new Ellipse2D.Double(260, 30, 80, 80)));

            return shape;
        }

        /**
         * Panneau (layout null) avec 4 boutons : X, O, Y, et ★
         */
        class PolygonalPanel extends JPanel {
            private final JDialog parentDialog;

            public PolygonalPanel(JDialog dialog) {
                this.parentDialog = dialog;
                setLayout(null);
                setBackground(new Color(120,120,120));

                initButtons();
            }

            private void initButtons() {
                // Bouton X
                JButton boutonX = new JButton("X");
                boutonX.setBounds(70, 240, 40, 40);
                configurerBoutonSurvol(boutonX, Color.RED, Color.LIGHT_GRAY);
                boutonX.addActionListener(e ->
                    JOptionPane.showMessageDialog(this, "Bouton X cliqué !")
                );
                add(boutonX);

                // Bouton O
                JButton boutonO = new JButton("O");
                boutonO.setBounds(240, 80, 40, 40);
                configurerBoutonSurvol(boutonO, Color.CYAN, Color.LIGHT_GRAY);
                boutonO.addActionListener(e ->
                    JOptionPane.showMessageDialog(this, "Bouton O cliqué !")
                );
                add(boutonO);

                // Bouton Y
                JButton boutonY = new JButton("Y");
                boutonY.setBounds(270, 40, 40, 40);
                configurerBoutonSurvol(boutonY, Color.BLUE, Color.LIGHT_GRAY);
                boutonY.addActionListener(e ->
                    JOptionPane.showMessageDialog(this, "Bouton Y cliqué !")
                );
                add(boutonY);

                // Bouton Étoile => ferme la fenêtre polygonale
                JButton boutonEtoile = new JButton("★");
                boutonEtoile.setBounds(160, 150, 50, 50);
                boutonEtoile.setForeground(Color.YELLOW);
                boutonEtoile.setFont(new Font("Dialog", Font.BOLD, 20));
                configurerBoutonSurvol(boutonEtoile, new Color(255,215,0), Color.GRAY);
                boutonEtoile.addActionListener(e -> parentDialog.dispose());
                add(boutonEtoile);
            }

            /**
             * Méthode utilitaire pour changer la couleur du bouton au survol
             */
            private void configurerBoutonSurvol(JButton btn, Color over, Color base) {
                btn.setBackground(base);
                btn.setOpaque(true);
                btn.setBorderPainted(false);

                btn.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseEntered(MouseEvent e) {
                        btn.setBackground(over);
                    }
                    @Override
                    public void mouseExited(MouseEvent e) {
                        btn.setBackground(base);
                    }
                });
            }
        }
    }

    //--------------------------------------------------------------------------
    //  6) Zone de dessin (DrawingPanel)
    //--------------------------------------------------------------------------
    class DrawingPanel extends JPanel {
        // Paramètres de dessin : couleur, épaisseur, style pointillé ou non
        private Color drawColor = Color.BLACK;
        private float lineWidth = 2.0f;
        private boolean dotted = false;

        // Permet de conserver la position initiale et la liste des segments
        private Point startPoint;
        private List<LineSegment> segments = new ArrayList<>();

        public DrawingPanel() {
            setLayout(new BorderLayout());

            // Panneau de contrôle en haut (choix de la couleur, style, épaisseur)
            JPanel ctrlPanel = new JPanel();
            String[] colorOpts = {"Black", "Red", "Green", "Blue"};
            JComboBox<String> colorBox = new JComboBox<>(colorOpts);
            ctrlPanel.add(new JLabel("Couleur:"));
            ctrlPanel.add(colorBox);

            String[] styleOpts = {"Continu", "Pointillé"};
            JComboBox<String> styleBox = new JComboBox<>(styleOpts);
            ctrlPanel.add(new JLabel("Style:"));
            ctrlPanel.add(styleBox);

            String[] widthOpts = {"1", "2", "3", "4", "5"};
            JComboBox<String> widthBox = new JComboBox<>(widthOpts);
            ctrlPanel.add(new JLabel("Épaisseur:"));
            ctrlPanel.add(widthBox);

            add(ctrlPanel, BorderLayout.NORTH);

            // Listeners pour modifier la couleur, le style, l'épaisseur
            colorBox.addActionListener(e -> {
                String sel = (String) colorBox.getSelectedItem();
                if ("Red".equals(sel)) {
                    drawColor = Color.RED;
                } else if ("Green".equals(sel)) {
                    drawColor = Color.GREEN;
                } else if ("Blue".equals(sel)) {
                    drawColor = Color.BLUE;
                } else {
                    drawColor = Color.BLACK;
                }
            });
            styleBox.addActionListener(e -> dotted = "Pointillé".equals(styleBox.getSelectedItem()));
            widthBox.addActionListener(e -> lineWidth = Float.parseFloat((String) widthBox.getSelectedItem()));

            // La zone de dessin elle-même
            DrawArea drawArea = new DrawArea();
            add(drawArea, BorderLayout.CENTER);
        }

        // Classe interne représentant la zone de dessin
        class DrawArea extends JPanel {
            public DrawArea() {
                setBackground(Color.WHITE);

                // Au clic souris, on enregistre la position
                addMouseListener(new MouseAdapter() {
                    @Override
                    public void mousePressed(MouseEvent e) {
                        startPoint = e.getPoint();
                    }
                    @Override
                    public void mouseReleased(MouseEvent e) {
                        // Quand on relâche, on crée un segment dans la liste
                        if (startPoint != null) {
                            segments.add(new LineSegment(startPoint, e.getPoint(),
                                                         drawColor, lineWidth, dotted));
                            startPoint = null;
                            repaint();
                        }
                    }
                });

                // Au drag, on redessine "à la volée"
                addMouseMotionListener(new MouseMotionAdapter() {
                    @Override
                    public void mouseDragged(MouseEvent e) {
                        repaint();
                    }
                });
            }

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;

                // Dessine tous les segments déjà finis
                for (LineSegment seg : segments) {
                    seg.draw(g2);
                }

                // Dessine la ligne en cours de tracé
                if (startPoint != null) {
                    g2.setColor(drawColor);
                    Stroke old = g2.getStroke();

                    if (dotted) {
                        g2.setStroke(new BasicStroke(lineWidth, BasicStroke.CAP_BUTT,
                                                     BasicStroke.JOIN_BEVEL, 0,
                                                     new float[]{5}, 0));
                    } else {
                        g2.setStroke(new BasicStroke(lineWidth));
                    }

                    Point current = getMousePosition();
                    if (current != null) {
                        g2.drawLine(startPoint.x, startPoint.y, current.x, current.y);
                    }
                    g2.setStroke(old);
                }
            }
        }

        // Petite classe pour stocker les infos d'un trait
        class LineSegment {
            Point p1, p2;
            Color color;
            float width;
            boolean dotted;

            LineSegment(Point p1, Point p2, Color color,
                        float width, boolean dotted) {
                this.p1 = p1;
                this.p2 = p2;
                this.color = color;
                this.width = width;
                this.dotted = dotted;
            }

            void draw(Graphics2D g2) {
                g2.setColor(color);
                Stroke old = g2.getStroke();

                if (dotted) {
                    g2.setStroke(new BasicStroke(width, BasicStroke.CAP_BUTT,
                                                 BasicStroke.JOIN_BEVEL, 0,
                                                 new float[]{5}, 0));
                } else {
                    g2.setStroke(new BasicStroke(width));
                }
                g2.drawLine(p1.x, p1.y, p2.x, p2.y);

                g2.setStroke(old);
            }
        }
    }

    //--------------------------------------------------------------------------
    //  7) Fenêtre esthétique déclenchée par le 22ème bouton
    //--------------------------------------------------------------------------
    class AestheticFrame extends JFrame {
        public AestheticFrame(Frame owner) {
            setTitle("Nouvelle IHM Esthétique");
            setSize(500, 400);
            setLocationRelativeTo(owner);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            // Panel avec un dégradé en background
            JPanel panel = new JPanel() {
                @Override
                protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    Graphics2D g2 = (Graphics2D) g;
                    // Dégradé du coin haut gauche (CYAN) au coin bas droit (MAGENTA)
                    g2.setPaint(new GradientPaint(0, 0, Color.CYAN,
                                                  getWidth(), getHeight(), Color.MAGENTA));
                    g2.fillRect(0, 0, getWidth(), getHeight());
                }
            };
            panel.setLayout(new BorderLayout());

            JLabel label = new JLabel("Bienvenue dans la nouvelle IHM!", SwingConstants.CENTER);
            label.setFont(new Font("Arial", Font.BOLD, 18));
            panel.add(label, BorderLayout.CENTER);

            add(panel);
        }
    }
}
