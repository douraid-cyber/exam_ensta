package controller;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;

public class Button_windows {
	JPanel panbuttons= new JPanel();
    public Button_windows() {
    	panbuttons.setLayout(null); // Utilisation d'un layout null pour un positionnement manuel
    	panbuttons.setPreferredSize(new Dimension(600, 100)); // Définition d'une taille par défaut

        
        // Ajouter les boutons
        addButton1();
        addButton2();
        addButton3();
    }

    // Bouton 1 : Fenêtre rectangulaire aux bords arrondis avec formulaire
    private void addButton1() {
    	ButtonDragAndDrop button1 = new ButtonDragAndDrop("Bouton 1");
        button1.setBounds(0, 0, 100, 30);
        button1.addActionListener(e -> {
            InfoFormWindow formWindow = new InfoFormWindow();
            formWindow.setVisible(true);
        });
         panbuttons.add(button1);
    }

    // Bouton 2 : Fenêtre circulaire avec slider et checkboxes
    private void addButton2() {
    	ButtonDragAndDrop button2 = new ButtonDragAndDrop("Bouton 2");
        button2.setBounds(150, 0, 100, 30);
        button2.addActionListener(e -> {
            CircularColorWindow colorWindow = new CircularColorWindow();
            colorWindow.setVisible(true);
        });
        
        panbuttons.add(button2);
    }

    // Bouton 3 : Fenêtre polygonale avec boutons interactifs
    private void addButton3() {
    	ButtonDragAndDrop button3 = new ButtonDragAndDrop("Bouton 3");
        button3.setBounds(300, 0, 100, 30);
        button3.addActionListener(e -> {
            PolygonalWindow polyWindow = new PolygonalWindow();
            polyWindow.setVisible(true);
        });
        panbuttons.add(button3);
    }

    // Fenêtre pour le Bouton 1
    private static class InfoFormWindow extends JFrame {
        public InfoFormWindow() {
            setTitle("Formulaire");
            setSize(400, 300);
            setLocationRelativeTo(null);
            setUndecorated(true);
            setShape(new RoundRectangle2D.Double(0, 0, 400, 300, 20, 20));

            JPanel mainPanel = new JPanel();
            mainPanel.setLayout(new GridLayout(6, 2, 10, 10));
            mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

            // Champs de saisie
            JTextField nomField = new JTextField();
            JTextField prenomField = new JTextField();
            JTextField ageField = new JTextField();
            JTextField ecoleField = new JTextField();

            mainPanel.add(new JLabel("Nom :"));
            mainPanel.add(nomField);
            mainPanel.add(new JLabel("Prénom :"));
            mainPanel.add(prenomField);
            mainPanel.add(new JLabel("Âge :"));
            mainPanel.add(ageField);
            mainPanel.add(new JLabel("École :"));
            mainPanel.add(ecoleField);

            // Bouton OK
            JButton okButton = new JButton("OK");
            mainPanel.add(okButton);

            // Label pour afficher les informations
            JLabel resultLabel = new JLabel();
            mainPanel.add(resultLabel);

            // Bouton Fermer
            JButton closeButton = new JButton("Fermer");
            closeButton.addActionListener(e -> dispose());
            mainPanel.add(closeButton);

            // Action du bouton OK
            okButton.addActionListener(e -> {
                String nom = nomField.getText();
                String prenom = prenomField.getText();
                String age = ageField.getText();
                String ecole = ecoleField.getText();
                resultLabel.setText("[" + nom + ", " + prenom + ", " + age + ", " + ecole + "]");
            });

            add(mainPanel);
        }
    }

 // Fenêtre pour le Bouton 2
    private static class CircularColorWindow extends JFrame {
        // Déclarer les checkboxes comme des champs de la classe
        private JCheckBox redCheck;
        private JCheckBox greenCheck;
        private JCheckBox blueCheck;
        private JCheckBox alphaCheck;

        public CircularColorWindow() {
            setTitle("Couleur");
            setSize(300, 300);
            setLocationRelativeTo(null);
            setUndecorated(true);
            setShape(new Ellipse2D.Double(0, 0, 300, 300));

            JPanel mainPanel = new JPanel();
            mainPanel.setLayout(new BorderLayout());
            setBackground(Color.ORANGE);
            mainPanel.setOpaque(true);

            // Slider pour la couleur
            JSlider colorSlider = new JSlider(0, 255, 128);
            colorSlider.addChangeListener(e -> {
                int value = colorSlider.getValue();
                // Mettre à jour la couleur de fond en fonction des checkboxes
                
                setBackground(new Color(value, value, value));
                repaint();
            });

            // Initialiser les checkboxes
            redCheck = new JCheckBox("R");
            greenCheck = new JCheckBox("G");
            blueCheck = new JCheckBox("B");
            alphaCheck = new JCheckBox("Alpha");

            // Ajouter des écouteurs pour les checkboxes
            ActionListener checkboxListener = e -> {
                int value = colorSlider.getValue();
                int red = redCheck.isSelected() ? value : 0;
                int green = greenCheck.isSelected() ? value : 0;
                int blue = blueCheck.isSelected() ? value : 0;
                int alpha = alphaCheck.isSelected() ? value : 255;
                mainPanel.setBackground(new Color(red, green, blue, alpha));
                mainPanel.repaint(); // Forcer le redessin du panel
            };

            redCheck.addActionListener(checkboxListener);
            greenCheck.addActionListener(checkboxListener);
            blueCheck.addActionListener(checkboxListener);
            alphaCheck.addActionListener(checkboxListener);

            JPanel checkboxPanel = new JPanel();
            checkboxPanel.add(redCheck);
            checkboxPanel.add(greenCheck);
            checkboxPanel.add(blueCheck);
            checkboxPanel.add(alphaCheck);

            // Bouton Fermer
            JButton closeButton = new JButton("Fermer");
            closeButton.addActionListener(e -> dispose());

            mainPanel.add(colorSlider, BorderLayout.CENTER);
            mainPanel.add(checkboxPanel, BorderLayout.SOUTH);
            mainPanel.add(closeButton, BorderLayout.NORTH);

            add(mainPanel);
        }
    }

    // Fenêtre pour le Bouton 3
    private static class PolygonalWindow extends JFrame {
        public PolygonalWindow() {
            setTitle("Polygone");
            setSize(400, 400);
            setLocationRelativeTo(null);
            setUndecorated(true);

            JPanel mainPanel = new JPanel() {
                @Override
                protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    Graphics2D g2d = (Graphics2D) g;
                    int[] xPoints = {200, 350, 350, 200, 50, 50};
                    int[] yPoints = {50, 150, 200, 200, 200, 150};
                    g2d.setColor(Color.CYAN);
                    g2d.fillPolygon(xPoints, yPoints, xPoints.length);
                }
            };
            mainPanel.setLayout(null);

            // Bouton central personnalisé
            JButton closeButton = new JButton("X");
            closeButton.setBounds(0, 0, 50, 50);
            closeButton.setBackground(Color.RED);
            closeButton.setForeground(Color.WHITE);
            closeButton.addActionListener(e -> dispose());

            mainPanel.add(closeButton);
            add(mainPanel);
        }
    }

 // Méthode pour afficher le panel avec des boutons
    public void show(JPanel panel) {
    	panel.setLayout(new BorderLayout()); 
    	panel.add(panbuttons);

    }
}