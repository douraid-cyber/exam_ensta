package controller;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;


public class paint_method {
    private JPanel panpaint = new JPanel(); // Initialize panpaint
    private JPanel panDessin;
    private List<Object[]> lines = new ArrayList<>(); // List to store lines with properties
    private Color color = Color.BLACK; // Default color
    private float strokeWidth = 1.0f; // Default stroke width
    private boolean isDashed = false; // Default stroke style (continuous)
    private int lastx, lasty;

    public paint_method() {
        panpaint.setPreferredSize(new Dimension(600, 400));
        panpaint.setLayout(new BorderLayout(0, 0));

        //####################################################
        //################  PAN HAUT  ######################
        //####################################################

        JPanel panHaut = new JPanel();
        panHaut.setBackground(Color.orange);
        panHaut.setLayout(new GridLayout(1, 6, 0, 0));

        String[] listCouleurs = {"Black", "Red", "Blue", "Green"};
        String[] listTrait = {"_", ".."};
        String[] listLargeurs = {"1.0px", "2.5px", "5.0px"};

        JComboBox<String> Jcomb1 = new JComboBox<>(listCouleurs);
        Jcomb1.setBounds(0, 80, 150, 30);
        panHaut.add(Jcomb1);

        JComboBox<String> Jcomb2 = new JComboBox<>(listTrait);
        Jcomb2.setBounds(0, 80, 150, 30);
        panHaut.add(Jcomb2);

        JComboBox<String> Jcomb3 = new JComboBox<>(listLargeurs);
        Jcomb3.setBounds(0, 80, 150, 30);
        panHaut.add(Jcomb3);

        // Add ActionListener to Jcomb1 (Color)
        Jcomb1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedColor = (String) Jcomb1.getSelectedItem();
                switch (selectedColor) {
                    case "Red":
                        color = Color.RED;
                        break;
                    case "Blue":
                        color = Color.BLUE;
                        break;
                    case "Green":
                        color = Color.GREEN;
                        break;
                    default:
                        color = Color.BLACK;
                        break;
                }
            }
        });

        // Add ActionListener to Jcomb2 (Stroke Style)
        Jcomb2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedStyle = (String) Jcomb2.getSelectedItem();
                isDashed = selectedStyle.equals("..");
            }
        });

        // Add ActionListener to Jcomb3 (Stroke Width)
        Jcomb3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedWidth = (String) Jcomb3.getSelectedItem();
                strokeWidth = Float.parseFloat(selectedWidth.replace("px", ""));
            }
        });

        //####################################################
        //################  PAN Central  #####################
        //####################################################
        panDessin = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                for (Object[] line : lines) {
                    int x1 = (int) line[0];
                    int y1 = (int) line[1];
                    int x2 = (int) line[2];
                    int y2 = (int) line[3];
                    Color lineColor = (Color) line[4];
                    boolean lineIsDashed = (boolean) line[5];
                    float lineStrokeWidth = (float) line[6];

                    g2d.setColor(lineColor); // Set the color

                    // Define the dash pattern based on the line's style
                    float[] dashPattern = lineIsDashed ? new float[]{2, 6} : null; 
                    BasicStroke stroke = new BasicStroke(lineStrokeWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 10, dashPattern, 0);
                    g2d.setStroke(stroke);

                    g2d.drawLine(x1, y1, x2, y2);
                }
            }
        };
        panDessin.setPreferredSize(new Dimension(300, 200));
        panDessin.setBackground(Color.white);
        panDessin.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                lastx = e.getX();
                lasty = e.getY();
                System.out.println("lastx:" + lastx);
                System.out.println("lasty:" + lasty);
            }
        });

        panDessin.addMouseMotionListener(new MouseMotionListener() {
            @Override
            public void mouseMoved(MouseEvent e) {
                // TODO Auto-generated method stub
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();

                // Add a new line with the current properties
                lines.add(new Object[]{lastx, lasty, x, y, color, isDashed, strokeWidth});
                lastx = x;
                lasty = y;
                panDessin.repaint();
            }
        });

        JButton but_clear = new JButton("Clear");
        but_clear.setSize(100, 30);
        but_clear.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                lines.clear();
                panDessin.repaint();
            }
        });
        panHaut.add(but_clear);

        JPanel panCentre = new JPanel();
        panCentre.setLayout(new BorderLayout(0, 0));
        JScrollPane jscp = new JScrollPane(panDessin);
        panCentre.add(jscp);

        //####################################################
        //####################################################
        //####################################################

        panpaint.add(panCentre, BorderLayout.CENTER);
        panpaint.add(panHaut, BorderLayout.NORTH);
    }

    public void show(JPanel jpan) {
        jpan.setLayout(new BorderLayout()); // Assure que jpan utilise BorderLayout
        jpan.add(panpaint, BorderLayout.CENTER); // panpaint occupe tout l'espace
    }
}