package controller;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

public class texte_editor {
    private JPanel pantextedit = new JPanel(); 
    private JPanel panDessin = new JPanel(); 
    private JTextField jtf; // Champ de texte

    public texte_editor() {
        pantextedit.setPreferredSize(new Dimension(600, 400));
        pantextedit.setLayout(new BorderLayout(0, 0));

        //####################################################
        //################  PAN HAUT  ######################
        //####################################################

        JPanel panHaut = new JPanel();
        panHaut.setBackground(Color.orange);
        panHaut.setLayout(new GridLayout(3, 1, 0, 0));

        String[] listCouleursBack = {"White", "Red", "Blue", "Green"};
        String[] listCouleursPolice = {"Black", "Red", "Blue", "Green"};

        JComboBox<String> Jcomb1 = new JComboBox<>(listCouleursBack);
        Jcomb1.setPreferredSize(new Dimension(50, 30));
        panHaut.add(Jcomb1);

        JComboBox<String> Jcomb2 = new JComboBox<>(listCouleursPolice);
        Jcomb2.setPreferredSize(new Dimension(50, 30));        
        panHaut.add(Jcomb2);

        

        // Add ActionListener to Jcomb2 (Text Color)
        Jcomb2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedColor = (String) Jcomb2.getSelectedItem();
                switch (selectedColor) {
                    case "Red":
                        jtf.setForeground(Color.RED);
                        break;
                    case "Blue":
                        jtf.setForeground(Color.BLUE);
                        break;
                    case "Green":
                        jtf.setForeground(Color.GREEN);
                        break;
                    case "Black":
                        jtf.setForeground(Color.BLACK);
                        break;
                    default:
                        jtf.setForeground(Color.BLACK);
                        break;
                }
            }
        });

        //####################################################
        //################  PAN Central  #####################
        //####################################################

        JPanel panCentre = new JPanel();
        panCentre.setLayout(new BorderLayout(0, 0));
        
     

        // Créer le champ de texte
        jtf = new JTextField("Champ de texte");
        jtf.setPreferredSize(new Dimension(600, 100)); // Taille par défaut
        
     // Add ActionListener to Jcomb1 (Background Color)
        Jcomb1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedColor = (String) Jcomb1.getSelectedItem();
                switch (selectedColor) {
                    case "Red":
                    	jtf.setBackground(Color.RED);
                        break;
                    case "Blue":
                    	jtf.setBackground(Color.BLUE);
                        break;
                    case "Green":
                    	jtf.setBackground(Color.GREEN);
                        break;
                    case "White":
                    	jtf.setBackground(Color.WHITE);
                        break;
                    default:
                    	jtf.setBackground(Color.WHITE);
                        break;
                }
            }
        });

        // Encapsuler le champ de texte dans un JScrollPane
        JScrollPane jscp = new JScrollPane(jtf);
        panCentre.add(jscp, BorderLayout.CENTER);


        //####################################################
        //####################################################
        //####################################################

        pantextedit.add(panCentre, BorderLayout.CENTER);
        pantextedit.add(panHaut, BorderLayout.WEST);
    }

    public void show(JPanel jpan) {
        jpan.setLayout(new BorderLayout()); 
        jpan.add(pantextedit, BorderLayout.CENTER);
    }
}