package controller;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ButtonDragAndDrop extends JButton {

    private int startX, startY; // Coordonnées de départ du drag
    private boolean dragging = false; // Indique si le bouton est en train d'être déplacé

    public ButtonDragAndDrop(String text) {
        super(text); // Appelle le constructeur de JButton avec le texte du bouton
        setFocusable(false); // Désactive le focus pour éviter les problèmes de clavier

        // Ajouter les écouteurs de souris
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                // Enregistrer les coordonnées de départ du drag
                startX = e.getX();
                startY = e.getY();
                dragging = true;
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                dragging = false; // Arrêter le drag
            }
        });

        addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                if (dragging) {
                    // Calculer le déplacement
                    int deltaX = e.getX() - startX;
                    int deltaY = e.getY() - startY;

                    // Déplacer le bouton
                    Point newLocation = new Point(getX() + deltaX, getY() + deltaY);

                    // Vérifier que le bouton reste dans la zone dédiée
                    Container parent = getParent();
                    if (parent != null) {
                        int maxX = parent.getWidth() - getWidth();
                        int maxY = parent.getHeight() - getHeight();

                        newLocation.x = Math.max(0, Math.min(newLocation.x, maxX));
                        newLocation.y = Math.max(0, Math.min(newLocation.y, maxY));
                    }

                    setLocation(newLocation); // Mettre à jour la position du bouton
                }
            }
        });
    }
}