package vue;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controller.Button_windows;
import controller.paint_method;
import controller.texte_editor;


public class app_view {

	public static void main(String[] args) {
		JFrame frame = new JFrame("flowlayout");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(600, 400);
		
		frame.setLayout(new BorderLayout(15, 15));
		//####################################################
		
		
		JPanel panHaut = new JPanel();
		panHaut.setPreferredSize(new Dimension(400, 50));
		panHaut.setBackground(Color.red);
		panHaut.add(new JLabel("Barre du haut"));
		Button_windows ButtonWindow = new Button_windows();
		ButtonWindow.show(panHaut);
    
		
		JPanel panBas = new JPanel();
		panBas.setBackground(Color.cyan);
		panBas.setPreferredSize(new Dimension(400, 100));
		texte_editor EditeurTexte = new texte_editor();
		EditeurTexte.show(panBas);
		
		JPanel panRight = new JPanel();
		panRight.setBackground(Color.yellow);
		panRight.setPreferredSize(new Dimension(100, 250));
		
		
		JPanel panLeft = new JPanel();
		panLeft.setBackground(Color.green);
		panLeft.setPreferredSize(new Dimension(100, 250));
		
		
	
		JPanel panCent = new JPanel();
		panCent.setBackground(Color.pink);
		panCent.setPreferredSize(new Dimension(400, 250));
		paint_method paintApp = new paint_method();
        paintApp.show(panCent);
		
        
		
		frame.add(panHaut, BorderLayout.NORTH);
		frame.add(panBas, BorderLayout.SOUTH);
		frame.add(panLeft, BorderLayout.WEST);
		frame.add(panRight, BorderLayout.EAST);	
		frame.add(panCent, BorderLayout.CENTER);
		frame.setVisible(true);
	}

}
