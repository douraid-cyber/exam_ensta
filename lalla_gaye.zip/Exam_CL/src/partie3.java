import javax.swing.JFrame;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JButton;

public class partie3 extends JFrame {
    private static int mouseX=0;
    private static int mouseY=0;

    public partie3() {
        setSize(400, 200);
        setUndecorated(true);
        setLayout(null); //Pour partir sur une feuille blanche
        setBackground(new Color(0, 0, 0, 0));

        addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen()/*-mouseX*/;
                int y = e.getYOnScreen()/*-mouseY*/;
                setLocation(x, y);
            }
        });
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
            }
        });

        JButton butExit = new JButton("X");
        butExit.setBounds(300, 160, 20, 20);
        butExit.setBackground(Color.red);
        butExit.setBorderPainted(false);
        butExit.setFocusPainted(false);
        butExit.setForeground(Color.white);
        butExit.setMargin(new Insets(0, 0, 0, 0));

        butExit.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                System.exit(0);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {
                butExit.setBackground(Color.gray);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                butExit.setBackground(Color.red);
            }
        });
        add(butExit);
    }

    @Override
    public void paint(Graphics g){
        //"Paint" pour le frame et "paint component" pour les autres composants
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;
        //POur un rendu sans aliasing
        //qualité
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        //performance
        /*g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);*/

        int[] xpoints = {200, 350, 350, 200,50,50};
        int[] ypoints = {50, 150, 200,200,200,150};
        Polygon poly = new Polygon(xpoints, ypoints, ypoints.length);

        GradientPaint gradient=new GradientPaint(0,0,Color.red,300,150,Color.blue);
        g2d.setPaint(gradient);

        g2d.fill(poly);
        //setShape(poly);
    }
}
