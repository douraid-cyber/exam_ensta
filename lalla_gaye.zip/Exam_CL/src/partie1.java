import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.List;

public class partie1 {
    private static int mouseX;
    private static int mouseY;
    static int lastx;
    static int lasty;
    static List<int[]> lines = new ArrayList<>();
    static Color currentColor=Color.BLACK;
    static List<Color> lineColors = new ArrayList<>();
    static List<Boolean> dashedLines = new ArrayList<>();
    static boolean isDashedLine=false;
    static int strokeWidth = 2;
    static List<Integer> lineThicknesses = new ArrayList<>();

        public static void main(String[] args) {
            JFrame frame=new JFrame("Deuxième interface");
            frame.setSize(800,600);
            frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);

            frame.setLayout(new BorderLayout());

            JPanel tab1 = new JPanel();
            tab1.setLayout(new BorderLayout());

            ///////Drag and Drop//////////////////////////////////////////////////////
            JPanel pan1=new JPanel();
            pan1.setBackground(Color.MAGENTA);

            JButton butt1=new JButton("New");
            JButton butt2=new JButton("Circle");
            JButton butt3=new JButton("Drag me");

            draganddrop(butt1);
            draganddrop(butt2);
            draganddrop(butt3);

            butt1.addMouseListener(new MouseListener(){
                @Override
                public void mouseClicked(MouseEvent e) {
                    partie2 fra=new partie2();
                    fra.setVisible(true);
                }

                @Override
                public void mousePressed(MouseEvent e) {

                }

                @Override
                public void mouseReleased(MouseEvent e) {

                }

                @Override
                public void mouseEntered(MouseEvent e) {
                    butt1.setBackground(Color.gray);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    butt1.setBackground(Color.green);
                }
            });

            butt2.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    new partie2_cw();
                }
            });

            pan1.add(butt1);
            pan1.add(butt2);
            pan1.add(butt3);

            ////////////////////////////////////////////////////////////////

            JPanel pan2=new JPanel();
            pan2.setBackground(Color.pink);

            ///Ecriture/////////////////////////////////////////////
            JPanel pan3=new JPanel(new BorderLayout());
            pan3.setBackground(Color.lightGray);

            JTextArea jta = new JTextArea("JTextArea");
            JScrollPane scrollPane = new JScrollPane(jta);

            String[] colors = {"Black", "Red", "Blue", "Green", "Yellow", "Orange", "Pink"};
            JComboBox<String> colorList = new JComboBox<>(colors);
            colorList.addActionListener(e -> {
                String selectedColor = (String) colorList.getSelectedItem();
                switch (selectedColor) {
                    case "Red":
                        currentColor = Color.RED;
                        break;
                    case "Blue":
                        currentColor = Color.BLUE;
                        break;
                    case "Green":
                        currentColor = Color.GREEN;
                        break;
                    case "Yellow":
                        currentColor = Color.YELLOW;
                        break;
                    case "Orange":
                        currentColor = Color.ORANGE;
                        break;
                    default:
                        currentColor = Color.PINK;
                        break;
                }
            });
            JButton textColorButton = new JButton("Change Text Color");
            textColorButton.addActionListener(e -> jta.setForeground(currentColor));

            JButton backgroundColorButton = new JButton("Change Background Color");
            backgroundColorButton.addActionListener(e -> jta.setBackground(currentColor));

            JPanel buttonPanel = new JPanel();
            buttonPanel.add(textColorButton);
            buttonPanel.add(backgroundColorButton);

            pan3.add(buttonPanel, BorderLayout.SOUTH);
            pan3.add(colorList, BorderLayout.NORTH);
            pan3.add(scrollPane, BorderLayout.CENTER);

            /// ///////////////////////////////////////////////////////
            JPanel pan4=new JPanel();
            pan4.setBackground(Color.lightGray);

            ///////Panel de dessin///////////////////////////////////////////////////
            JPanel pan5=new JPanel(){
                @Override  //Pour permettre de garder son dessin en redimmensionnant la fenêtre
                protected void paintComponent(Graphics g) {
                    super.paintComponent(g);   //Garder les propriétés de base de paintComponent et en ajouter des nouvelles
                    Graphics2D g2D = (Graphics2D) g.create();
                    for (int i = 0; i < lines.size(); i++) {
                        g2D.setColor(lineColors.get(i));
                        int[] line = lines.get(i);
                        if (dashedLines.get(i)) {
                            float[] dashPattern = {3, 3};
                            g2D.setStroke(new BasicStroke(2, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, dashPattern, 0));
                            g2D.drawLine(line[0], line[1], line[2], line[3]);
                        } else {
                            g2D.setStroke(new BasicStroke(lineThicknesses.get(i)));
                        }
                        g2D.drawLine(line[0], line[1], line[2], line[3]);
                    }
                }
            };

            pan5.addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    lastx=e.getX();
                    lasty=e.getY();
                    System.out.println("lastx: "+lastx);
                    System.out.println("lasty: "+lasty);
                }
            });

            pan5.addMouseMotionListener(new MouseMotionListener() {
                @Override
                public void mouseDragged(MouseEvent e) {
                    int x=e.getX();
                    int y=e.getY();

                    var g=pan5.getGraphics();
                    g.drawLine(lastx,lasty,x,y); //draw line from lastx, lasty to x, y
                    lines.add(new int[]{lastx,lasty,x,y});
                    lineColors.add(currentColor);
                    dashedLines.add(isDashedLine);
                    lineThicknesses.add(strokeWidth);
                    lastx=x;
                    lasty=y;
                    pan5.repaint();
                }

                @Override
                public void mouseMoved(MouseEvent e) {
                }
            });

            String[] colors2 = {"Black", "Red", "Blue", "Green", "Yellow", "Orange", "Pink", "Cyan", "Magenta"};
            JComboBox<String> colorList2 = new JComboBox<>(colors2);
            colorList2.addActionListener(e -> {
                String selectedColor = (String) colorList2.getSelectedItem();
                switch (selectedColor) {
                    case "Red":
                        currentColor = Color.RED;
                        break;
                    case "Blue":
                        currentColor = Color.BLUE;
                        break;
                    case "Green":
                        currentColor = Color.GREEN;
                        break;
                    case "Yellow":
                        currentColor = Color.YELLOW;
                        break;
                    case "Orange":
                        currentColor = Color.ORANGE;
                        break;
                    case "Pink":
                        currentColor = Color.PINK;
                        break;
                    default:
                        currentColor = Color.BLACK;
                        break;
                }
            });

            String[] styles = {"Solid", "Dashed"};
            JComboBox<String> styleList = new JComboBox<>(styles);
            styleList.addActionListener(e -> isDashedLine = styleList.getSelectedItem().equals("Dashed"));

            Integer[] widths = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
            JComboBox<Integer> widthList = new JComboBox<>(widths);
            widthList.addActionListener(e -> strokeWidth = (int) widthList.getSelectedItem());

            pan5.add(colorList2);
            pan5.add(styleList);
            pan5.add(widthList);

            ///PARTIE 3///////////////////////////////////////////////////////////////////////////////////
            JPanel tab2 = new JPanel();
            tab2.setLayout(new GridLayout(10, 10));  // 10x10 grille pour 100 boutons

            for (int i = 1; i <= 100; i++) {
                JButton button = new JButton(i + "");  // Créer un bouton avec le texte i
                // Ajouter le bouton à l'onglet
                tab2.add(button);

                // Changer la couleur du 22e bouton au survol
                if (i == 22) {
                    button.addMouseListener(new MouseAdapter() {
                        @Override
                        public void mouseEntered(MouseEvent e) {
                            button.setBackground(Color.RED); // Changer la couleur au survol
                        }

                        @Override
                        public void mouseExited(MouseEvent e) {
                            button.setBackground(UIManager.getColor("Button.background")); // Réinitialiser la couleur
                        }

                        @Override
                        public void mouseClicked(MouseEvent e) {
                            partie3 fra=new partie3();
                            fra.setVisible(true);
                        }
                    });
                }
            }

            tab1.add(pan1, BorderLayout.NORTH);
            tab1.add(pan2, BorderLayout.SOUTH);
            tab1.add(pan3, BorderLayout.WEST);
            tab1.add(pan4, BorderLayout.EAST);
            tab1.add(pan5, BorderLayout.CENTER);

            JTabbedPane jtpa = new JTabbedPane();
            jtpa.add("1", tab1);
            jtpa.add("2", tab2);

            ///Mise en page////////////////////////////////////////////////////////////////////////
            frame.add(jtpa);

            frame.setVisible(true);

        }

        public static void draganddrop(JButton button){
            button.addMouseMotionListener(new MouseAdapter() {
                @Override
                public void mouseDragged(MouseEvent e) {
                    int x = e.getXOnScreen()/*-mouseX*/;
                    int y = e.getYOnScreen()/*-mouseY*/;
                    button.setLocation(x, y);
                }
            });
            button.addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    mouseX = e.getX();
                    mouseY = e.getY();
                }
            });
        }
    }
