import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;

public class partie2_cw extends JFrame {
    private JPanel colorPanel;
    private JSlider colorSlider;
    private JCheckBox redCheckBox, greenCheckBox, blueCheckBox, alphaCheckBox;
    private int red = 0, green = 0, blue = 0, alpha = 255;

    public partie2_cw() {
        setUndecorated(true);
        setSize(300, 300);
        setShape(new java.awt.geom.Ellipse2D.Double(0, 0, getWidth(), getHeight()));
        setLayout(new BorderLayout());

        colorPanel = new JPanel();
        colorPanel.setBackground(new Color(red, green, blue, alpha));
        add(colorPanel, BorderLayout.CENTER);

        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new GridLayout(5, 1));

        colorSlider = new JSlider(0, 255, 0);
        colorSlider.addChangeListener(e -> updateColor());
        controlPanel.add(colorSlider);

        redCheckBox = new JCheckBox("Red");
        greenCheckBox = new JCheckBox("Green");
        blueCheckBox = new JCheckBox("Blue");
        alphaCheckBox = new JCheckBox("Alpha");
        controlPanel.add(redCheckBox);
        controlPanel.add(greenCheckBox);
        controlPanel.add(blueCheckBox);
        controlPanel.add(alphaCheckBox);

        add(controlPanel, BorderLayout.SOUTH);

        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dispose());
        add(closeButton, BorderLayout.NORTH);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void updateColor() {
        int value = colorSlider.getValue();
        if (redCheckBox.isSelected()) red = value;
        if (greenCheckBox.isSelected()) green = value;
        if (blueCheckBox.isSelected()) blue = value;
        if (alphaCheckBox.isSelected()) alpha = value;
        colorPanel.setBackground(new Color(red, green, blue, alpha));
    }

    public void paint(Graphics g) {
        //"Paint" pour le frame et "paint component" pour les autres composants
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;
        //POur un rendu sans aliasing
        //qualité
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        //performance
        /*g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);*/

        int w = getWidth();
        int h = getHeight();

        Ellipse2D ell=new Ellipse2D.Double(0,0,w,h);
        g2d.draw(ell);
        g2d.setColor(new Color(0,127,127,127));
        g2d.fill(ell);
    }
}
