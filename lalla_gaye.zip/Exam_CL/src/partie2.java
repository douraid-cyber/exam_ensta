import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.geom.Area;
import java.awt.geom.RoundRectangle2D;

public class partie2 extends JFrame {
    private static int mouseX=0;
    private static int mouseY=0;

    public partie2() {
        setSize(800, 500);
        setUndecorated(true);
        setLayout(null); //Pour partir sur une feuille blanche
        setBackground(new Color(0, 0, 0, 0));

        addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getXOnScreen()/*-mouseX*/;
                int y = e.getYOnScreen()/*-mouseY*/;
                setLocation(x, y);
            }
        });
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
            }
        });

        JButton butExit = new JButton("X");
        butExit.setBounds(19*getWidth()/20, getHeight()/25, 20, 20);
        butExit.setBackground(Color.red);
        butExit.setBorderPainted(false);
        butExit.setFocusPainted(false);
        butExit.setForeground(Color.white);
        butExit.setMargin(new Insets(0, 0, 0, 0));

        butExit.addMouseListener(new MouseListener(){
            @Override
            public void mouseClicked(MouseEvent e) {
                System.exit(0);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {
                butExit.setBackground(Color.gray);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                butExit.setBackground(Color.red);
            }
        });
        add(butExit);

        JPanel jpa = new JPanel(new CardLayout());

        JLabel nameLabel = new JLabel("Nom:");
        nameLabel.setBounds(50, 50, 100, 30);
        JTextField nameField = new JTextField();
        nameField.setBounds(150, 50, 200, 30);
        //nameField.setForeground(Color.BLACK);

        JLabel prenomLabel = new JLabel("Prénom:");
        prenomLabel.setBounds(50, 100, 100, 30);
        JTextField prenomField = new JTextField();
        prenomField.setBounds(150, 100, 200, 30);
        //prenomField.setForeground(Color.BLACK);

        JLabel ageLabel = new JLabel("Age:");
        ageLabel.setBounds(50, 150, 100, 30);
        JTextField ageField = new JTextField();
        ageField.setBounds(150, 150, 200, 30);
        //ageField.setForeground(Color.BLACK);

        JLabel ecoleLabel = new JLabel("École:");
        ecoleLabel.setBounds(50, 200, 100, 30);
        JTextField ecoleField = new JTextField();
        ecoleField.setBounds(150, 200, 200, 30);
        //ecoleField.setForeground(Color.BLACK);

        JButton okButton = new JButton("OK");
        okButton.setBounds(150, 250, 100, 30);


        JLabel resultLabel = new JLabel();
        resultLabel.setBounds(50, 300, 400, 30);

        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String prenom = prenomField.getText();
                String age = ageField.getText();
                String ecole = ecoleField.getText();
                resultLabel.setForeground(Color.BLACK);
                resultLabel.setText("[" + name + ", " + prenom + ", " + age + ", " + ecole + "]");
            }
        });

        add(nameLabel);
        add(nameField);
        add(prenomLabel);
        add(prenomField);
        add(ageLabel);
        add(ageField);
        add(ecoleLabel);
        add(ecoleField);
        add(okButton);
        add(resultLabel);
    }

    public void paint(Graphics g) {
        //"Paint" pour le frame et "paint component" pour les autres composants
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;
        //POur un rendu sans aliasing
        //qualité
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        //performance
        /*g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);*/

        int w = getWidth();
        int h = getHeight();

        RoundRectangle2D rect= new RoundRectangle2D.Double(10, 10, w - 20, h - 20, 20, 20);
        g2d.draw(rect);
        g2d.setColor(new Color(0,127,127,127));
        g2d.fill(rect);
    }
}
