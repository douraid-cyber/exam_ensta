import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class DrawingPanel extends JPanel {
    private Color currentColor = Color.BLACK;
    private float strokeWidth = 2.0f;
    private boolean dotted = false;
    
    private List<ShapeWithStroke> shapes = new ArrayList<>();
    private Point startPoint = null;
    
    public DrawingPanel() {
        setLayout(new BorderLayout());
        
        // Panneau de contrôle
        JPanel controls = new JPanel();
        String[] colors = {"Black", "Red", "Green", "Blue"};
        JComboBox<String> colorCombo = new JComboBox<>(colors);
        controls.add(new JLabel("Couleur:"));
        controls.add(colorCombo);
        
        String[] strokeTypes = {"Continu", "Pointillé"};
        JComboBox<String> strokeCombo = new JComboBox<>(strokeTypes);
        controls.add(new JLabel("Style:"));
        controls.add(strokeCombo);
        
        String[] widths = {"1", "2", "3", "4", "5"};
        JComboBox<String> widthCombo = new JComboBox<>(widths);
        controls.add(new JLabel("Épaisseur:"));
        controls.add(widthCombo);
        
        add(controls, BorderLayout.NORTH);
        
        colorCombo.addActionListener(e -> {
            String sel = (String) colorCombo.getSelectedItem();
            switch(sel) {
                case "Red": currentColor = Color.RED; break;
                case "Green": currentColor = Color.GREEN; break;
                case "Blue": currentColor = Color.BLUE; break;
                default: currentColor = Color.BLACK;
            }
        });
        
        strokeCombo.addActionListener(e -> {
            String sel = (String) strokeCombo.getSelectedItem();
            dotted = sel.equals("Pointillé");
        });
        
        widthCombo.addActionListener(e -> {
            strokeWidth = Float.parseFloat((String) widthCombo.getSelectedItem());
        });
        
        // Zone de dessin
        DrawArea drawArea = new DrawArea();
        add(drawArea, BorderLayout.CENTER);
    }
    
    class DrawArea extends JPanel {
        public DrawArea() {
            setBackground(Color.WHITE);
            addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    startPoint = e.getPoint();
                }
                public void mouseReleased(MouseEvent e) {
                    if(startPoint != null) {
                        Point endPoint = e.getPoint();
                        shapes.add(new ShapeWithStroke(startPoint, endPoint, currentColor, strokeWidth, dotted));
                        startPoint = null;
                        repaint();
                    }
                }
            });
            addMouseMotionListener(new MouseMotionAdapter() {
                public void mouseDragged(MouseEvent e) {
                    repaint();
                }
            });
        }
        
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            for(ShapeWithStroke s : shapes) {
                s.draw(g2);
            }
            if(startPoint != null) {
                Point current = getMousePosition();
                if(current != null) {
                    g2.setColor(currentColor);
                    Stroke original = g2.getStroke();
                    if(dotted) {
                        g2.setStroke(new BasicStroke(strokeWidth, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[]{5}, 0));
                    } else {
                        g2.setStroke(new BasicStroke(strokeWidth));
                    }
                    g2.drawLine(startPoint.x, startPoint.y, current.x, current.y);
                    g2.setStroke(original);
                }
            }
        }
    }
    
    class ShapeWithStroke {
        Point start, end;
        Color color;
        float strokeWidth;
        boolean dotted;
        
        public ShapeWithStroke(Point start, Point end, Color color, float strokeWidth, boolean dotted) {
            this.start = start;
            this.end = end;
            this.color = color;
            this.strokeWidth = strokeWidth;
            this.dotted = dotted;
        }
        
        public void draw(Graphics2D g2) {
            g2.setColor(color);
            Stroke original = g2.getStroke();
            if(dotted) {
                g2.setStroke(new BasicStroke(strokeWidth, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[]{5}, 0));
            } else {
                g2.setStroke(new BasicStroke(strokeWidth));
            }
            g2.drawLine(start.x, start.y, end.x, end.y);
            g2.setStroke(original);
        }
    }
}
