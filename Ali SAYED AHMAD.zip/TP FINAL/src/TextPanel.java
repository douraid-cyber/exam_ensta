import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TextPanel extends JPanel {
    private JTextArea textArea;
    
    public TextPanel() {
        setLayout(new BorderLayout());
        textArea = new JTextArea(5, 30);
        JScrollPane scroll = new JScrollPane(textArea);
        add(scroll, BorderLayout.CENTER);
        
        JPanel controlPanel = new JPanel();
        JButton bgColorButton = new JButton("Changer fond");
        JButton textColorButton = new JButton("Changer texte");
        controlPanel.add(bgColorButton);
        controlPanel.add(textColorButton);
        add(controlPanel, BorderLayout.SOUTH);
        
        bgColorButton.addActionListener(e -> {
            Color newColor = JColorChooser.showDialog(this, "Choisir fond", textArea.getBackground());
            if(newColor != null) {
                textArea.setBackground(newColor);
            }
        });
        
        textColorButton.addActionListener(e -> {
            Color newColor = JColorChooser.showDialog(this, "Choisir couleur texte", textArea.getForeground());
            if(newColor != null) {
                textArea.setForeground(newColor);
            }
        });
    }
}
