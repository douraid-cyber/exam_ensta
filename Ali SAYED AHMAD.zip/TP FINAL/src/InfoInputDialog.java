import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class InfoInputDialog extends JDialog {
    public InfoInputDialog(Window owner) {
        super(owner, "Informations de l'étudiant", ModalityType.APPLICATION_MODAL);
        setSize(300, 250);
        setLocationRelativeTo(owner);
        setUndecorated(true);
        
        // Panneau à bords arrondis
        JPanel panel = new RoundedPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel labelNom = new JLabel("Nom:");
        JTextField tfNom = new JTextField();
        JLabel labelPrenom = new JLabel("Prénom:");
        JTextField tfPrenom = new JTextField();
        JLabel labelAge = new JLabel("Âge:");
        JTextField tfAge = new JTextField();
        JLabel labelEcole = new JLabel("École:");
        JTextField tfEcole = new JTextField();
        
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(labelNom, gbc);
        gbc.gridx = 1; gbc.gridy = 0;
        panel.add(tfNom, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(labelPrenom, gbc);
        gbc.gridx = 1; gbc.gridy = 1;
        panel.add(tfPrenom, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(labelAge, gbc);
        gbc.gridx = 1; gbc.gridy = 2;
        panel.add(tfAge, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(labelEcole, gbc);
        gbc.gridx = 1; gbc.gridy = 3;
        panel.add(tfEcole, gbc);
        
        JButton okButton = new JButton("OK");
        JButton closeButton = new JButton("Fermer");
        
        JLabel resultLabel = new JLabel(" ");
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        panel.add(resultLabel, gbc);
        
        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 1;
        panel.add(okButton, gbc);
        gbc.gridx = 1; gbc.gridy = 5;
        panel.add(closeButton, gbc);
        
        okButton.addActionListener(e -> {
            String nom = tfNom.getText();
            String prenom = tfPrenom.getText();
            String age = tfAge.getText();
            String ecole = tfEcole.getText();
            resultLabel.setText("[" + nom + ", " + prenom + ", " + age + ", " + ecole + "]");
        });
        
        closeButton.addActionListener(e -> dispose());
        
        add(panel);
    }
    
    // Panneau personnalisé pour afficher des bords arrondis
    class RoundedPanel extends JPanel {
        public RoundedPanel() {
            setOpaque(false);
        }
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
            g2.dispose();
            super.paintComponent(g);
        }
    }
}
