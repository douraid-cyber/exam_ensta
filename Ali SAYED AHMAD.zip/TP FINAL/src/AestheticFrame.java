import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;

public class AestheticFrame extends JFrame {
    private float gradientProgress = 0f; // For gradient animation
    private int rotationAngle = 0; // For spinning text
    private Timer gradientTimer, rotationTimer; // Timers for animations
    private JLabel spinningLabel; // Label for spinning text

    public AestheticFrame() {
        setTitle("Nouvelle IHM");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Main panel with animated gradient background
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;

                // Animated gradient
                Color color1 = Color.getHSBColor(gradientProgress, 1, 1);
                Color color2 = Color.getHSBColor(gradientProgress + 0.5f, 1, 1);
                GradientPaint gp = new GradientPaint(0, 0, color1, getWidth(), getHeight(), color2);
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());

                // Spinning text
                AffineTransform oldTransform = g2.getTransform();
                g2.rotate(Math.toRadians(rotationAngle), getWidth() / 2.0, getHeight() / 2.0);
                spinningLabel.setForeground(Color.WHITE);
                spinningLabel.setFont(new Font("Arial", Font.BOLD, 24));
                spinningLabel.setBounds(0, 0, getWidth(), getHeight());
                spinningLabel.paint(g2);
                g2.setTransform(oldTransform);
            }
        };
        panel.setLayout(new BorderLayout());

        // Spinning label
        spinningLabel = new JLabel("Bienvenue dans la nouvelle IHM", SwingConstants.CENTER);
        panel.add(spinningLabel, BorderLayout.CENTER);

        // Surprise button
        JButton surpriseButton = new JButton("Cliquez-moi pour une surprise !");
        surpriseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startConfettiAnimation(panel);
            }
        });
        panel.add(surpriseButton, BorderLayout.SOUTH);

        add(panel);

        // Start gradient animation
        gradientTimer = new Timer(50, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gradientProgress += 0.01f;
                if (gradientProgress > 1f) gradientProgress = 0f;
                panel.repaint();
            }
        });
        gradientTimer.start();

        // Start spinning text animation
        rotationTimer = new Timer(20, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                rotationAngle = (rotationAngle + 2) % 360;
                panel.repaint();
            }
        });
        rotationTimer.start();
    }

    // Confetti animation
    private void startConfettiAnimation(JPanel panel) {
        Timer confettiTimer = new Timer(100, new ActionListener() {
            private int frame = 0;

            @Override
            public void actionPerformed(ActionEvent e) {
                frame++;
                if (frame > 30) { // Stop after 30 frames
                    ((Timer) e.getSource()).stop();
                }
                Graphics2D g2 = (Graphics2D) panel.getGraphics();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Draw random confetti
                for (int i = 0; i < 50; i++) {
                    int x = (int) (Math.random() * panel.getWidth());
                    int y = (int) (Math.random() * panel.getHeight());
                    Color color = new Color((int) (Math.random() * 0x1000000));
                    g2.setColor(color);
                    g2.fillOval(x, y, 10, 10);
                }
            }
        });
        confettiTimer.start();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AestheticFrame frame = new AestheticFrame();
            frame.setVisible(true);
        });
    }
}