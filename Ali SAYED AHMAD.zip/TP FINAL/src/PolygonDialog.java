import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Window;
import java.awt.Dialog.ModalityType;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;

class PolygonDialog extends JDialog {
    public PolygonDialog(Window parent) {
        super(parent, "Fenêtre Polygone", ModalityType.APPLICATION_MODAL);
        setUndecorated(true);
        setSize(400, 400);
        setLocationRelativeTo(parent);

        // Définition des dimensions du carré central
        int squareSize = 120;
        int squareX = (getWidth() - squareSize) / 2; // 140
        int squareY = (getHeight() - squareSize) / 2; // 140

        // Panneau personnalisé pour dessiner la forme et positionner les boutons
        JPanel polygonPanel = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Fond de la forme
                g2d.setColor(Color.DARK_GRAY);

                // Dessin du carré central
                int squareSize = 120;
                int squareX = (getWidth() - squareSize) / 2;
                int squareY = (getHeight() - squareSize) / 2;
                g2d.fill(new Rectangle2D.Double(squareX, squareY, squareSize, squareSize));

                // Dimensions du cercle
                int circleSize = 100;
                // 1) Cercle en dessous et à gauche du carré
                int circle1X = squareX - circleSize / 2;              // 140 - 50 = 90
                int circle1Y = squareY + squareSize - circleSize / 2;   // 140 + 120 - 50 = 210

                // 2) Cercle en haut à droite du carré
                int circle2X = squareX + squareSize - circleSize / 2;   // 140 + 120 - 50 = 210
                int circle2Y = squareY - circleSize / 2;                // 140 - 50 = 90

                // 3) Cercle adjacent au cercle 2, en union : chevauchement de 10px
                int circle3X = circle2X + circleSize - 30;              // 210 + 100 - 10 = 300
                int circle3Y = circle2Y-50;                                // même hauteur que cercle 2

                // Dessin des cercles
                g2d.fill(new Ellipse2D.Double(circle1X, circle1Y, circleSize, circleSize));
                g2d.fill(new Ellipse2D.Double(circle2X, circle2Y, circleSize, circleSize));
                g2d.fill(new Ellipse2D.Double(circle3X, circle3Y, circleSize, circleSize));
            }
        };
        polygonPanel.setLayout(null);
        //note bien : j ai moidifie plusieurs Fois, donc les commentaires ne sont pas valables
        // Calculs des positions pour les boutons centrés sur chaque forme
        // Pour le cercle 1
        int circle1X = squareX - 50;               // 90
        int circle1Y = squareY + squareSize - 50;    // 210
        int circle1CenterX = circle1X + 50;          // 140
        int circle1CenterY = circle1Y + 50;          // 260

        // Pour le cercle 2
        int circle2X = squareX + squareSize - 50;    // 210
        int circle2Y = squareY - 50;                 // 90
        int circle2CenterX = circle2X + 50;          // 260
        int circle2CenterY = circle2Y + 50;          // 140

        // Pour le cercle 3 (union avec cercle 2)
        int circle3X = circle2X + 100 - 10;          // 210 + 100 - 10 = 300
        int circle3Y = circle2Y-50;                     // 90
        int circle3CenterX = circle3X +30;          // 350
        int circle3CenterY = circle3Y + 50;          // 140

        // Bouton pour le cercle 1 (par exemple "X")
        JButton buttonX = createHoverButton("X");
        buttonX.setBounds(circle1CenterX - 15, circle1CenterY - 15, 30, 30);
        
        // Bouton pour le cercle 2 (par exemple "Y")
        JButton buttonY = createHoverButton("Y");
        buttonY.setBounds(circle2CenterX - 15, circle2CenterY - 15, 30, 30);
        
        // Bouton pour le cercle 3 (par exemple "O")
        JButton buttonO = createHoverButton("O");
        buttonO.setBounds(circle3CenterX - 15, circle3CenterY - 15, 30, 30);
        
        // Bouton central (dans le carré) : une étoile jaune qui ferme la fenêtre au clic
        JButton centerButton = new JButton("★") {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Fond de l'étoile : un cercle jaune couvrant toute la surface du bouton
                g2d.setColor(Color.YELLOW);
                g2d.fillOval(0, 0, getWidth(), getHeight());
                
                // Dessin d'une étoile noire au centre
                g2d.setColor(Color.BLACK);
                Font font = new Font("Arial", Font.BOLD, 60);
                g2d.setFont(font);
                FontMetrics fm = g2d.getFontMetrics();
                int x = (getWidth() - fm.stringWidth("★")) / 2;
                int y = (getHeight() + fm.getAscent()) / 2 - 5;
                g2d.drawString("★", x, y);
            }
        };
        // Pour centrer le bouton dans le carré central
        centerButton.setBounds(squareX + 20, squareY + 20, 80, 80);
        centerButton.setFocusPainted(false);
        centerButton.setContentAreaFilled(false);
        centerButton.setBorderPainted(false);
        centerButton.addActionListener(e -> dispose());

        // Ajout des boutons au panneau
        polygonPanel.add(buttonX);
        polygonPanel.add(buttonY);
        polygonPanel.add(buttonO);
        polygonPanel.add(centerButton);

        add(polygonPanel);
        setVisible(true);
    }

    // Création d'un bouton qui change de couleur au survol
    private JButton createHoverButton(String text) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);
        button.setBackground(Color.LIGHT_GRAY);
        button.setForeground(Color.BLACK);
        button.setBorder(BorderFactory.createRaisedBevelBorder());

        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(Color.YELLOW);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(Color.LIGHT_GRAY);
            }
        });
        return button;
    }

    public static void main(String[] args) {
        new PolygonDialog(null);
    }
}
