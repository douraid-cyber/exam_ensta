import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DraggableButtonsPanel extends JPanel {
    private Point initialClick;

    public DraggableButtonsPanel() {
        setLayout(null); // Positionnement absolu pour autoriser le déplacement
        setPreferredSize(new Dimension(800, 100));
        
        // Bouton 1
        JButton button1 = new JButton("Bouton 1");
        button1.setBounds(20, 20, 120, 30);
        add(button1);
        makeDraggable(button1);
        button1.addActionListener(e -> {
            new InfoInputDialog(SwingUtilities.getWindowAncestor(this)).setVisible(true);
        });
        
        // Bouton 2
        JButton button2 = new JButton("Bouton 2");
        button2.setBounds(160, 20, 120, 30);
        add(button2);
        makeDraggable(button2);
        button2.addActionListener(e -> {
            new ColorSliderDialog(SwingUtilities.getWindowAncestor(this)).setVisible(true);
        });
        
        // Bouton 3
        JButton button3 = new JButton("Bouton 3");
        button3.setBounds(300, 20, 120, 30);
        add(button3);
        makeDraggable(button3);
        button3.addActionListener(e -> {
            new PolygonDialog(SwingUtilities.getWindowAncestor(this)).setVisible(true);
        });
    }
    
    private void makeDraggable(final JButton button) {
        button.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                initialClick = e.getPoint();
            }
        });
        button.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                int thisX = button.getLocation().x;
                int thisY = button.getLocation().y;
                int xMoved = e.getX() - initialClick.x;
                int yMoved = e.getY() - initialClick.y;
                int X = thisX + xMoved;
                int Y = thisY + yMoved;
                Rectangle parentBounds = button.getParent().getBounds();
                if(X < 0) X = 0;
                if(Y < 0) Y = 0;
                if(X + button.getWidth() > parentBounds.width) X = parentBounds.width - button.getWidth();
                if(Y + button.getHeight() > parentBounds.height) Y = parentBounds.height - button.getHeight();
                button.setLocation(X, Y);
            }
        });
    }
}
