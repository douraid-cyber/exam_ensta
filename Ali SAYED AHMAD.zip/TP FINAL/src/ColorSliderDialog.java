import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Ellipse2D;

public class ColorSliderDialog extends JDialog {
    private JSlider slider;
    private JCheckBox cbR, cbG, cbB, cbAlpha;
    private JPanel colorPanel;
    private int r = 128, g = 128, b = 128, a = 255; // Default color values

    public ColorSliderDialog(Window owner) {
        super(owner, "Color Slider", ModalityType.APPLICATION_MODAL);
        setSize(300, 300);
        setLocationRelativeTo(owner);
        setUndecorated(true);

        // Enable transparency for the circular window
        setBackground(new Color(0, 0, 0, 0));
        setShape(new Ellipse2D.Double(0, 0, 300, 300));

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setOpaque(false);

        // Slider configuration
        slider = new JSlider(0, 255, 128);
        slider.setMajorTickSpacing(50);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);
        mainPanel.add(slider, BorderLayout.CENTER);

        // Checkbox panel
        JPanel cbPanel = new JPanel(new FlowLayout());
        cbR = new JCheckBox("R");
        cbG = new JCheckBox("G");
        cbB = new JCheckBox("B");
        cbAlpha = new JCheckBox("Alpha");
        cbPanel.add(cbR);
        cbPanel.add(cbG);
        cbPanel.add(cbB);
        cbPanel.add(cbAlpha);
        mainPanel.add(cbPanel, BorderLayout.NORTH);

        // Close button
        JButton closeButton = new JButton("Close");
        mainPanel.add(closeButton, BorderLayout.SOUTH);

        // Color preview panel
        colorPanel = new JPanel();
        colorPanel.setPreferredSize(new Dimension(50, 50));
        colorPanel.setBackground(new Color(r, g, b, a));
        mainPanel.add(colorPanel, BorderLayout.WEST);

        // Event listeners
        slider.addChangeListener(e -> updateColor());
        closeButton.addActionListener(e -> dispose());

        // Checkbox listeners
        cbR.addActionListener(e -> updateColor());
        cbG.addActionListener(e -> updateColor());
        cbB.addActionListener(e -> updateColor());
        cbAlpha.addActionListener(e -> updateColor());

        add(mainPanel);
    }

    private void updateColor() {
        int value = slider.getValue();

        // Update only the selected component(s)
        if (cbR.isSelected()) r = value;
        if (cbG.isSelected()) g = value;
        if (cbB.isSelected()) b = value;
        if (cbAlpha.isSelected()) a = value;

        // Create the new color
        Color newColor = new Color(r, g, b, a);
        colorPanel.setBackground(newColor);
        getContentPane().setBackground(newColor);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame();
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(400, 400);
            frame.setVisible(true);

            JButton openButton = new JButton("Open Color Slider");
            openButton.addActionListener(e -> {
                ColorSliderDialog dialog = new ColorSliderDialog(frame);
                dialog.setVisible(true);
            });
            frame.add(openButton);
        });
    }
}