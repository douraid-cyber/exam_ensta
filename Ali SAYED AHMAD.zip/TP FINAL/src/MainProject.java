import javax.swing.*;
import java.awt.*;

public class MainProject {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Projet de Fin de cours - IHM Java");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(1000, 700);
            
            JTabbedPane tabbedPane = new JTabbedPane();
            
            // Onglet 1 : Interface principale avec cinq zones
            MainPanel mainPanel = new MainPanel();
            tabbedPane.addTab("Interface Principale", mainPanel);
            
            // Onglet 2 : 100 boutons
            HundredButtonsPanel hundredPanel = new HundredButtonsPanel();
            tabbedPane.addTab("100 Boutons", hundredPanel);
            
            frame.add(tabbedPane);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}
