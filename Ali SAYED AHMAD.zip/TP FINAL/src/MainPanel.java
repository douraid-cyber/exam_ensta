import javax.swing.*;
import java.awt.*;

public class MainPanel extends JPanel {
    public MainPanel() {
        setLayout(new BorderLayout(10, 10));
        
        // Zone Haut : Trois boutons déplaçables et leurs actions.
        DraggableButtonsPanel northPanel = new DraggableButtonsPanel();
        northPanel.setBackground(Color.LIGHT_GRAY);
        add(northPanel, BorderLayout.NORTH);
        
        // Zone Bas : Panneau de texte avec options de couleur et barre de défilement.
        TextPanel southPanel = new TextPanel();
        southPanel.setBackground(Color.PINK);
        add(southPanel, BorderLayout.SOUTH);
        
        // Zone Centre : Espace de dessin avec liste déroulante pour couleur, style et épaisseur.
        DrawingPanel centerPanel = new DrawingPanel();
        centerPanel.setBackground(Color.WHITE);
        add(centerPanel, BorderLayout.CENTER);
        
        // Zone Droite (vide) : Fond d'une couleur différente.
        JPanel eastPanel = new JPanel();
        eastPanel.setBackground(Color.ORANGE);
        eastPanel.setPreferredSize(new Dimension(150, 100));
        add(eastPanel, BorderLayout.EAST);
        
        // Zone Gauche (vide) : Fond d'une autre couleur.
        JPanel westPanel = new JPanel();
        westPanel.setBackground(Color.CYAN);
        westPanel.setPreferredSize(new Dimension(150, 100));
        add(westPanel, BorderLayout.WEST);
    }
}
