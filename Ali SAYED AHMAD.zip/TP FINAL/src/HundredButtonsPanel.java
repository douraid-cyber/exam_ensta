import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class HundredButtonsPanel extends JPanel {
    public HundredButtonsPanel() {
        setLayout(new GridLayout(10, 10, 5, 5));
        
        for(int i = 1; i <= 100; i++) {
            JButton btn = new JButton(String.valueOf(i));
            if(i == 22) {
                btn.addMouseListener(new MouseAdapter() {
                    Color original;
                    public void mouseEntered(MouseEvent e) {
                        original = btn.getBackground();
                        btn.setBackground(Color.RED);
                    }
                    public void mouseExited(MouseEvent e) {
                        btn.setBackground(original);
                    }
                });
                btn.addActionListener(e -> {
                    new AestheticFrame().setVisible(true);
                });
            }
            add(btn);
        }
    }
}
