package exam_ensta;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.RenderingHints;
import javax.swing.JButton;

class StarButton extends JButton {
    private boolean hovered = false;

    public StarButton(String text) {
        super(text);
        setFocusPainted(false);
        setBorderPainted(false);
        setContentAreaFilled(false);
        setOpaque(false);
        setFont(new Font("Comic Sans MS", Font.BOLD, 20));
        setForeground(Color.BLACK);

        addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                hovered = true;
                repaint();
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                hovered = false;
                repaint();
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Couleur de fond (change au survol)
        g2d.setColor(hovered ? Color.ORANGE : Color.YELLOW);
        g2d.fill(getStarShape());

        // Dessiner le contour de l'étoile
        g2d.setColor(Color.BLACK);
        g2d.draw(getStarShape());

        // Dessiner le texte au centre
        g2d.setFont(getFont());
        int textWidth = g2d.getFontMetrics().stringWidth(getText());
        int textHeight = g2d.getFontMetrics().getAscent();
        g2d.setColor(Color.BLACK);
        g2d.drawString(getText(), getWidth() / 2 - textWidth / 2, getHeight() / 2 + textHeight / 4);

        super.paintComponent(g);
    }

    // Création de la forme d'une étoile
    private Polygon getStarShape() {
        int[] xPoints = {25, 35, 50, 37, 40, 25, 10, 13, 0, 15};
        int[] yPoints = {0, 15, 15, 25, 40, 30, 40, 25, 15, 15};
        Polygon star = new Polygon(xPoints, yPoints, xPoints.length);

        // Ajuster la taille et la position de l'étoile
        for (int i = 0; i < xPoints.length; i++) {
            star.xpoints[i] = xPoints[i] * getWidth() / 50;
            star.ypoints[i] = yPoints[i] * getHeight() / 50;
        }
        return star;
    }
}
