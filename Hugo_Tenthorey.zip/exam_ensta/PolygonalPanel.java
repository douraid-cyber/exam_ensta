package exam_ensta;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;

class PolygonalPanel extends JPanel {
    private JDialog parentDialog;
    private JButton centerButton, circleButton1, circleButton2, circleButton3;

    public PolygonalPanel(JDialog dialog) {
        this.parentDialog = dialog;
        setLayout(null);
        setOpaque(false); // Fond transparent

        // Boutons positionnés au centre des formes
        centerButton = new StarButton("*");
        centerButton.setBounds(160, 160, 50, 50);
        centerButton.addActionListener(e -> parentDialog.dispose()); // Fermer la fenêtre
        add(centerButton);
        circleButton1 = createButton("X", 85, 245, 30, 30, false);
        circleButton2 = createButton("O", 255, 95, 30, 30, false);
        circleButton3 = createButton("Y", 285, 55, 30, 30, false);

        centerButton.addActionListener(e -> parentDialog.dispose()); // Fermer la fenêtre

        add(centerButton);
        add(circleButton1);
        add(circleButton2);
        add(circleButton3);
    }

    private JButton createButton(String text, int x, int y, int w, int h, boolean isCentral) {
        JButton button = new JButton(text);
        button.setBounds(x, y, w, h);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(true);
        button.setBackground(Color.YELLOW);

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(Color.GREEN);
            }
            public void mouseExited(MouseEvent e) {
                button.setBackground(Color.YELLOW);
            }
        });

        if (isCentral) {
            button.setFont(new Font("Comic Sans MS", Font.BOLD, 20));
            button.setForeground(Color.YELLOW);
        }

        return button;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.DARK_GRAY);

        // Dessiner le fond polygonal
        g2d.fill(new Rectangle2D.Double(100, 100, 150, 150)); // Carré
        g2d.fill(new Ellipse2D.Double(60, 220, 80, 80)); // Cercle bas gauche
        g2d.fill(new Ellipse2D.Double(230, 70, 80, 80)); // Cercle haut droite
        g2d.fill(new Ellipse2D.Double(260, 30, 80, 80)); // Cercle 2 haut droite
        
        g2d.setColor(Color.WHITE);
        g2d.fill(new Ellipse2D.Double(160, 160, 40, 40)); // Cercle pour le bouton central
    }
}
