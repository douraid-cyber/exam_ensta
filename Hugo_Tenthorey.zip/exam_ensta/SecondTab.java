package exam_ensta;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class SecondTab extends JPanel {
    public SecondTab() {
        setLayout(new GridLayout(10, 10));
        for (int i = 1; i <= 100; i++) {
            JButton button = new JButton("Bouton " + i);
            if (i == 22) {
                button.addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseEntered(java.awt.event.MouseEvent evt) {
                        button.setBackground(Color.RED);
                    }
                    public void mouseExited(java.awt.event.MouseEvent evt) {
                        button.setBackground(null);
                    }
                    public void mouseClicked(java.awt.event.MouseEvent evt) {
                        openNewWindow();
                    }
                });
            }
            add(button);
        }
    }

    private void openNewWindow() {
        JFrame newFrame = new JFrame("Félicitations !");
        newFrame.setSize(400, 300);
        newFrame.setLocationRelativeTo(null);
        newFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBackground(new Color(50, 150, 250));
        
        JLabel messageLabel = new JLabel("", SwingConstants.CENTER);
        messageLabel.setFont(new Font("Arial", Font.BOLD, 16));
        messageLabel.setForeground(Color.WHITE);
        
        panel.add(messageLabel, BorderLayout.CENTER);
        newFrame.add(panel);
        
        panel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                messageLabel.setText("Bravo, vous avez trouvé le bouton 22 !");
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                messageLabel.setText("");
            }
        });
        
        newFrame.setVisible(true);
    }
}
