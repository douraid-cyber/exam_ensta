package exam_ensta;
import javax.swing.*;
import java.awt.*;

public class main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame());
    }
}

class MainFrame extends JFrame {
    public MainFrame() {
        setTitle("Application avec Onglets");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Onglet 1", new FirstTab());
        tabbedPane.addTab("Onglet 2", new SecondTab());

        add(tabbedPane);
        setVisible(true);
    }
}