package exam_ensta;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class FirstTab extends JPanel {
    public FirstTab() {
        setLayout(new BorderLayout());
        
        // Ajout des différentes zones
        add(new TopPanel(), BorderLayout.NORTH);
        add(new BottomPanel(), BorderLayout.SOUTH);
        add(new LeftPanel(), BorderLayout.WEST);
        add(new RightPanel(), BorderLayout.EAST);
        add(new CenterPanel(), BorderLayout.CENTER);
    }
}

// Classe pour la zone haute
class TopPanel extends JPanel {
    private JButton button1, button2, button3;
    private Point initialClick;

    public TopPanel() {
        setBackground(Color.LIGHT_GRAY);
        setPreferredSize(new Dimension(0, 100));
        setLayout(null);

        // Création des boutons
        button1 = createDraggableButton("Bouton 1", 50, 30);
        button2 = createDraggableButton("Bouton 2", 200, 30);
        button3 = createDraggableButton("Bouton 3", 350, 30);

        add(button1);
        add(button2);
        add(button3);

        // Ajout des actions aux boutons
        setupButtonActions();
    }

    private void setupButtonActions() {
        button1.addActionListener(e -> openInfoWindow());
        button2.addActionListener(e -> openColorWindow());
        button3.addActionListener(e -> openPolygonalWindow());

    }

    private void openPolygonalWindow() {
        JDialog dialog = new JDialog();
        dialog.setUndecorated(true); // Suppression des bordures
        dialog.setSize(400, 400);
        dialog.setLocationRelativeTo(this);

        // Définir la forme avec Area
        Area customShape = createCustomShape();
        dialog.setShape(customShape);

        PolygonalPanel panel = new PolygonalPanel(dialog);
        dialog.setContentPane(panel);

        dialog.setVisible(true);
    }
    
    private Area createCustomShape() {
        Area shape = new Area(new Rectangle2D.Double(100, 100, 150, 150)); // Carré central

        // Ajouter les cercles en les fusionnant avec `add()`
        shape.add(new Area(new Ellipse2D.Double(60, 220, 80, 80))); // Cercle bas gauche
        shape.add(new Area(new Ellipse2D.Double(230, 70, 80, 80))); // Cercle haut droite
        shape.add(new Area(new Ellipse2D.Double(260, 30, 80, 80))); // Cercle 2 haut droite

        return shape;
    }

    private void openColorWindow() {
        // Création de la fenêtre circulaire
        JDialog dialog = new JDialog();
        dialog.setUndecorated(true); // Pas de bordures
        dialog.setSize(400, 400);
        dialog.setShape(new java.awt.geom.Ellipse2D.Double(0, 0, 400, 400));
        dialog.setLocationRelativeTo(this);

        // Panel principal prenant toute la fenêtre
        JPanel colorPanel = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(getBackground());
                g.fillOval(0, 0, getWidth(), getHeight()); // Assurer un fond circulaire
            }
        };
        colorPanel.setBackground(new Color(127, 127, 127, 255));

        // Slider au centre
        JSlider colorSlider = new JSlider(0, 255, 127);
        colorSlider.setBounds(100, 180, 200, 40);
        colorSlider.setMajorTickSpacing(50);
        colorSlider.setPaintTicks(true);

        // Checkboxes positionnées en bas
        JCheckBox checkR = new JCheckBox("Rouge");
        JCheckBox checkG = new JCheckBox("Vert");
        JCheckBox checkB = new JCheckBox("Bleu");
        JCheckBox checkA = new JCheckBox("Transparence");

        JPanel checkBoxPanel = new JPanel();
        checkBoxPanel.setOpaque(false);
        checkBoxPanel.setBounds(80, 250, 240, 30);
        checkBoxPanel.add(checkR);
        checkBoxPanel.add(checkG);
        checkBoxPanel.add(checkB);
        checkBoxPanel.add(checkA);

        // Bouton de fermeture en bas
        JButton closeButton = new JButton("Fermer");
        closeButton.setBounds(150, 300, 100, 30);
        closeButton.addActionListener(e -> dialog.dispose());

        // Action du slider
        colorSlider.addChangeListener(e -> {
            int value = colorSlider.getValue();
            Color currentColor = colorPanel.getBackground();
            int r = checkR.isSelected() ? value : currentColor.getRed();
            int g = checkG.isSelected() ? value : currentColor.getGreen();
            int b = checkB.isSelected() ? value : currentColor.getBlue();
            int a = checkA.isSelected() ? value : currentColor.getAlpha();

            // Si aucune checkbox n'est sélectionnée, faire varier toute la couleur
            if (!checkR.isSelected() && !checkG.isSelected() && !checkB.isSelected() && !checkA.isSelected()) {
                r = g = b = value; // Variation uniforme du spectre
                a = 255;
            }

            colorPanel.setBackground(new Color(r, g, b, a));
            colorPanel.repaint();
        });

        // Ajout des composants
        colorPanel.add(colorSlider);
        colorPanel.add(checkBoxPanel);
        colorPanel.add(closeButton);

        dialog.setContentPane(colorPanel);
        dialog.setVisible(true);
    }


	private void openInfoWindow() {
        JDialog dialog = new JDialog();
        dialog.setSize(400, 350);
        dialog.setLayout(new GridBagLayout());
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;

        dialog.getContentPane().setBackground(Color.LIGHT_GRAY);

        // Champs de saisie
        JTextField nomField = new JTextField(15);
        JTextField prenomField = new JTextField(15);
        JTextField ageField = new JTextField(5);
        JTextField ecoleField = new JTextField(15);
        JLabel resultLabel = new JLabel(" ");

        // Ajout des composants
        dialog.add(new JLabel("Nom:"), gbc);
        gbc.gridx = 1;
        dialog.add(nomField, gbc);

        gbc.gridx = 0; gbc.gridy++;
        dialog.add(new JLabel("Prénom:"), gbc);
        gbc.gridx = 1;
        dialog.add(prenomField, gbc);

        gbc.gridx = 0; gbc.gridy++;
        dialog.add(new JLabel("Âge:"), gbc);
        gbc.gridx = 1;
        dialog.add(ageField, gbc);

        gbc.gridx = 0; gbc.gridy++;
        dialog.add(new JLabel("École:"), gbc);
        gbc.gridx = 1;
        dialog.add(ecoleField, gbc);

        // Bouton OK
        gbc.gridx = 0; gbc.gridy++;
        gbc.gridwidth = 2;
        JButton okButton = new JButton("OK");
        dialog.add(okButton, gbc);

        // Label pour afficher le résultat
        gbc.gridy++;
        dialog.add(resultLabel, gbc);

        // Bouton Fermer
        gbc.gridy++;
        JButton closeButton = new JButton("Fermer");
        dialog.add(closeButton, gbc);

        // Actions des boutons
        okButton.addActionListener(e -> {
            String info = String.format("[%s, %s, %s, %s]",
                    nomField.getText(),
                    prenomField.getText(),
                    ageField.getText(),
                    ecoleField.getText()
            );
            resultLabel.setText(info);
        });

        closeButton.addActionListener(e -> dialog.dispose());

        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

	private JButton createDraggableButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 100, 40);

        button.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                initialClick = e.getPoint();
            }
        });

        button.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) {
                int x = button.getX() + e.getX() - initialClick.x;
                int y = button.getY() + e.getY() - initialClick.y;
                
                // Assurer que le bouton reste dans la zone TopPanel
                int maxX = getWidth() - button.getWidth();
                int maxY = getHeight() - button.getHeight();
                
                x = Math.max(0, Math.min(x, maxX));
                y = Math.max(0, Math.min(y, maxY));
                
                button.setLocation(x, y);
            }
        });
        
        return button;
    }
}

// Classe pour la zone basse
class BottomPanel extends JPanel {
    private JTextArea textArea;
    private JComboBox<String> bgColorSelector, textColorSelector;

    public BottomPanel() {
        setBackground(Color.GREEN);
        setPreferredSize(new Dimension(0, 100));
        setLayout(new BorderLayout());

        textArea = new JTextArea(3, 30);
        JScrollPane scrollPane = new JScrollPane(textArea);
        add(scrollPane, BorderLayout.CENTER);

        JPanel controlPanel = new JPanel();
        String[] colors = {"Blanc", "Jaune", "Cyan", "Rose", "Vert"};
        Color[] colorValues = {Color.WHITE, Color.YELLOW, Color.CYAN, Color.PINK, Color.GREEN};

        bgColorSelector = new JComboBox<>(colors);
        bgColorSelector.addActionListener(e -> textArea.setBackground(colorValues[bgColorSelector.getSelectedIndex()]));
        controlPanel.add(new JLabel("Fond:"));
        controlPanel.add(bgColorSelector);

        textColorSelector = new JComboBox<>(colors);
        textColorSelector.addActionListener(e -> textArea.setForeground(colorValues[textColorSelector.getSelectedIndex()]));
        controlPanel.add(new JLabel("Texte:"));
        controlPanel.add(textColorSelector);

        add(controlPanel, BorderLayout.SOUTH);
    }
}

// Classe pour la zone gauche
class LeftPanel extends JPanel {
    public LeftPanel() {
        setBackground(Color.BLUE);
        setPreferredSize(new Dimension(100, 0));
    }
}

// Classe pour la zone droite
class RightPanel extends JPanel {
    public RightPanel() {
        setBackground(Color.RED);
        setPreferredSize(new Dimension(100, 0));
    }
}

// Classe pour la zone centrale
class CenterPanel extends JPanel {
    public CenterPanel() {
        setBackground(Color.LIGHT_GRAY);
        setLayout(new BorderLayout());

        FalsePaintApp paintApp = new FalsePaintApp();
        add(paintApp, BorderLayout.CENTER);
        add(paintApp.getControlPanel(), BorderLayout.SOUTH);
    }
}