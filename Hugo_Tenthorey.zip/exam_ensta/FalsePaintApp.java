package exam_ensta;

// Classe réutilisée depuis les TP effectués en cours

import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class FalsePaintApp extends JPanel {
    private int lastx, lasty;
    private final List<int[]> lines = new ArrayList<>();
    private final List<Color> lineColors = new ArrayList<>();
    private final List<Float> lineThicknesses = new ArrayList<>();
    private final List<float[]> linePatterns = new ArrayList<>();
    private Color currentColor = Color.BLACK;
    private float currentThickness = 2.0f;
    private float[] currentPattern = null; // null means solid line

    public FalsePaintApp() {
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(800, 600));

        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                lastx = e.getX();
                lasty = e.getY();
            }
        });

        addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();

                lines.add(new int[]{lastx, lasty, x, y});
                lineColors.add(currentColor);
                lineThicknesses.add(currentThickness);
                linePatterns.add(currentPattern);

                lastx = x;
                lasty = y;
                repaint();
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g.create();
        for (int i = 0; i < lines.size(); i++) {
            int[] line = lines.get(i);
            g2d.setColor(lineColors.get(i));

            if (linePatterns.get(i) != null) {
                g2d.setStroke(new BasicStroke(lineThicknesses.get(i), BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, linePatterns.get(i), 0.0f));
            } else {
                g2d.setStroke(new BasicStroke(lineThicknesses.get(i)));
            }
            g2d.drawLine(line[0], line[1], line[2], line[3]);
        }
    }

    public JPanel getControlPanel() {
        JButton butClear = new JButton("Clear");
        butClear.addActionListener(e -> {
            lines.clear();
            lineColors.clear();
            lineThicknesses.clear();
            linePatterns.clear();
            repaint();
        });

        String[] colors = {"Black", "Red", "Green", "Blue", "Yellow"};
        Color[] colorValues = {Color.BLACK, Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW};
        JComboBox<String> colorSelector = new JComboBox<>(colors);
        colorSelector.addActionListener(e -> {
            int index = colorSelector.getSelectedIndex();
            currentColor = colorValues[index];
        });

        JSlider thicknessSlider = new JSlider(1, 10, 2);
        thicknessSlider.addChangeListener(e -> currentThickness = thicknessSlider.getValue());

        String[] lineTypes = {"Continu", "Pointillés"};
        float[][] patterns = {null, new float[]{10.0f, 10.0f}};
        JComboBox<String> lineTypeSelector = new JComboBox<>(lineTypes);
        lineTypeSelector.addActionListener(e -> {
            int index = lineTypeSelector.getSelectedIndex();
            currentPattern = patterns[index];
        });

        JPanel controlPanel = new JPanel();
        controlPanel.add(colorSelector);
        controlPanel.add(thicknessSlider);
        controlPanel.add(lineTypeSelector);
        controlPanel.add(butClear);

        return controlPanel;
    }
}
