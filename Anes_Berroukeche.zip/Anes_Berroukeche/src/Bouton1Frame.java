import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Bouton1Frame extends JFrame {
    public Bouton1Frame() {
        setTitle("Bouton 1 - Informations Personnelles");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        // Panel avec bordure arrondie
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2, true));
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Création des champs de saisie
        JTextField nomField = new JTextField(15);
        JTextField prenomField = new JTextField(15);
        JTextField ageField = new JTextField(15);
        JTextField ecoleField = new JTextField(15);
        
        // Placement des labels et champs
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Nom:"), gbc);
        gbc.gridx = 1;
        panel.add(nomField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Prénom:"), gbc);
        gbc.gridx = 1;
        panel.add(prenomField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Âge:"), gbc);
        gbc.gridx = 1;
        panel.add(ageField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(new JLabel("École:"), gbc);
        gbc.gridx = 1;
        panel.add(ecoleField, gbc);
        
        // Bouton OK et label d'affichage
        JButton okButton = new JButton("OK");
        JLabel displayLabel = new JLabel("");
        gbc.gridx = 0; gbc.gridy = 4;
        gbc.gridwidth = 2;
        panel.add(okButton, gbc);
        gbc.gridy = 5;
        panel.add(displayLabel, gbc);
        
        okButton.addActionListener(e -> {
            String info = "[" + nomField.getText() + ", " + prenomField.getText() + ", " 
                    + ageField.getText() + ", " + ecoleField.getText() + "]";
            displayLabel.setText(info);
        });
        
        // Bouton de fermeture
        JButton closeButton = new JButton("Fermer");
        gbc.gridy = 6;
        panel.add(closeButton, gbc);
        closeButton.addActionListener(e -> dispose());
        
        add(panel);
        setVisible(true);
    }
}
