import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

import javax.swing.JButton;
import javax.swing.JPanel;

public class NorthPanel extends JPanel {
    public NorthPanel() {
        setBackground(Color.LIGHT_GRAY);
        setLayout(new FlowLayout());
        
        // Bouton 1 : Ouvre Bouton1Frame
        JButton btn1 = new JButton("Bouton 1");
        btn1.addActionListener(e -> new Bouton1Frame());
        btn1.addMouseMotionListener(new DragListener());
        add(btn1);
        
        // Bouton 2 : Ouvre Bouton2Frame
        JButton btn2 = new JButton("Bouton 2");
        btn2.addActionListener(e -> new Bouton2Frame());
        btn2.addMouseMotionListener(new DragListener());
        add(btn2);
        
        // Bouton 3 : Ouvre Bouton3Frame
        JButton btn3 = new JButton("Bouton 3");
        btn3.addActionListener(e -> new Bouton3Frame());
        btn3.addMouseMotionListener(new DragListener());
        add(btn3);
    }
    
    // Classe interne pour le drag and drop dans la zone
    private class DragListener extends MouseMotionAdapter {
        @Override
        public void mouseDragged(MouseEvent e) {
            JButton source = (JButton) e.getSource();
            int newX = Math.max(0, Math.min(source.getX() + e.getX(), getWidth() - source.getWidth()));
            int newY = Math.max(0, Math.min(source.getY() + e.getY(), getHeight() - source.getHeight()));
            source.setLocation(newX, newY);
        }
    }
}
