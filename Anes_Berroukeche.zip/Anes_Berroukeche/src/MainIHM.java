import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainIHM extends JFrame {
    public MainIHM() {
        setTitle("Projet IHM Java");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        
        // Création d'un JTabbedPane pour deux onglets
        JTabbedPane tabbedPane = new JTabbedPane();
        
        // Onglet IHM Principale
        JPanel mainPanel = new JPanel(new BorderLayout(10,10));
        mainPanel.add(new NorthPanel(), BorderLayout.NORTH);
        mainPanel.add(new SouthPanel(), BorderLayout.SOUTH);
        mainPanel.add(new WestPanel(), BorderLayout.WEST);
        mainPanel.add(new EastPanel(), BorderLayout.EAST);
        mainPanel.add(new CenterPanel(), BorderLayout.CENTER);
        tabbedPane.addTab("IHM Principale", mainPanel);
        
        // Onglet avec 100 boutons
        tabbedPane.addTab("100 Boutons", new HundredButtonsPanel());
        
        add(tabbedPane);
        setVisible(true);
    }
    
    public static void main(String[] args) {
        new MainIHM();
    }
}
