import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;

public class CenterPanel extends JPanel {
    public CenterPanel() {
        setLayout(new BorderLayout());

        // Panel de dessin
        DrawingPanel drawingPanel = new DrawingPanel();
        add(drawingPanel, BorderLayout.CENTER);

        // Contrôles (couleur, type de trait, largeur)
        JPanel controls = new JPanel();
        JComboBox<String> colorCombo = new JComboBox<>(new String[]{"Noir", "Rouge", "Vert", "Bleu"});
        JComboBox<String> strokeCombo = new JComboBox<>(new String[]{"Continu", "Pointillé"});
        JSlider widthSlider = new JSlider(1, 10, 1);

        colorCombo.addActionListener(e -> {
            String selectedColor = (String) colorCombo.getSelectedItem();
            switch (selectedColor) {
                case "Noir" -> drawingPanel.setCurrentColor(Color.BLACK);
                case "Rouge" -> drawingPanel.setCurrentColor(Color.RED);
                case "Vert" -> drawingPanel.setCurrentColor(Color.GREEN);
                case "Bleu" -> drawingPanel.setCurrentColor(Color.BLUE);
            }
        });

        strokeCombo.addActionListener(e -> {
            String selectedStroke = (String) strokeCombo.getSelectedItem();
            drawingPanel.setDashed(selectedStroke.equals("Pointillé"));
        });

        widthSlider.addChangeListener(e -> drawingPanel.setStrokeWidth(widthSlider.getValue()));

        controls.add(new JLabel("Couleur:"));
        controls.add(colorCombo);
        controls.add(new JLabel("Trait:"));
        controls.add(strokeCombo);
        controls.add(new JLabel("Largeur:"));
        controls.add(widthSlider);

        add(controls, BorderLayout.SOUTH);
    }
}