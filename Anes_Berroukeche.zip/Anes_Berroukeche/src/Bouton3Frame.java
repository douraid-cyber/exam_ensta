import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Bouton3Frame extends JFrame {
    
    public Bouton3Frame() {
        setTitle("Bouton 3 - Forme Personnalisée");
        setSize(300, 300);
        setUndecorated(true);  // Fenêtre sans bordure
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        // 1) Créer la forme personnalisée (un carré central + cercles autour).
        //    Ici : un carré de 100×100, centré approximativement, et 3 cercles autour (top, right, bottom).
        //    Ajustez selon vos besoins (coordonnées, tailles, etc.).
        
        // Carré central (x=100, y=100, w=100, h=100)
        Area shape = new Area(new Rectangle2D.Double(100, 100, 100, 100));
        
        // Cercle du haut (diamètre 50) centré sur x=150, y=75
        Ellipse2D topCircle = new Ellipse2D.Double(125, 50, 50, 50);
        shape.add(new Area(topCircle));
        
        // Cercle de droite (diamètre 50) centré sur x=225, y=150
        Ellipse2D rightCircle = new Ellipse2D.Double(200, 125, 50, 50);
        shape.add(new Area(rightCircle));
        
        // Cercle du bas (diamètre 50) centré sur x=150, y=225
        Ellipse2D bottomCircle = new Ellipse2D.Double(125, 200, 50, 50);
        shape.add(new Area(bottomCircle));
        
        // On applique la forme à la fenêtre
        setShape(shape);
        
        // 2) Créer un JPanel principal transparent (layout null) pour y placer les boutons manuellement.
        JPanel mainPanel = new JPanel(null); // Pas de layout manager => on positionne tout à la main
        mainPanel.setOpaque(false);          // Fond transparent (on verra la forme de la fenêtre)
        add(mainPanel);
        
        // 3) Bouton central (étoile) qui ferme la fenêtre.
        //    On crée un JButton personnalisé qui dessine une étoile dans paintComponent.
        JButton starButton = new JButton() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                int w = getWidth();
                int h = getHeight();
                
                // Fond circulaire (optionnel)
                g2d.setColor(Color.WHITE);
                g2d.fillOval(0, 0, w, h);
                
                // Dessin de l'étoile
                g2d.setColor(Color.YELLOW);
                Polygon star = createStar(w/2, h/2, w/2 - 5, w/6, 5);
                g2d.fill(star);
                
                g2d.dispose();
            }
        };
        starButton.setBorderPainted(false);
        starButton.setFocusPainted(false);
        starButton.setContentAreaFilled(false);
        
        // Positionnement du bouton étoile (au centre du carré)
        starButton.setBounds(135, 135, 30, 30);
        
        // Action : fermer la fenêtre
        starButton.addActionListener(e -> dispose());
        
        // Effet de survol : changer la couleur de fond ou autre
        starButton.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseEntered(MouseEvent e) {
                starButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                starButton.setCursor(Cursor.getDefaultCursor());
            }
        });
        
        mainPanel.add(starButton);
        
        // 4) Créer les trois petits boutons X, O, Y placés sur chaque cercle.
        
        // Bouton du haut (centré dans le cercle topCircle)
        JButton topBtn = createRoundButton("Y");
        topBtn.setBounds(140, 60, 30, 30);
        mainPanel.add(topBtn);
        
        // Bouton de droite
        JButton rightBtn = createRoundButton("O");
        rightBtn.setBounds(215, 140, 30, 30);
        mainPanel.add(rightBtn);
        
        // Bouton du bas
        JButton bottomBtn = createRoundButton("X");
        bottomBtn.setBounds(140, 210, 30, 30);
        mainPanel.add(bottomBtn);
                
        // 5) Rendre la fenêtre visible
        setVisible(true);
    }
    
    /**
     * Crée un bouton rond avec un texte donné, qui change de couleur au survol.
     */
    private JButton createRoundButton(String text) {
        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setMargin(new Insets(0,0,0,0));
        btn.setContentAreaFilled(false);
        btn.setOpaque(false);
        btn.setBorderPainted(false);
        
        // Survol : changer la couleur de fond
        btn.addMouseListener(new MouseAdapter(){
            Color hoverColor = Color.CYAN;
            @Override
            public void mouseEntered(MouseEvent e){
                btn.setBackground(hoverColor);
                btn.setOpaque(true);
            }
            @Override
            public void mouseExited(MouseEvent e){
                btn.setOpaque(false);
            }
        });
        
        return btn;
    }
    
    /**
     * Méthode utilitaire pour créer une étoile à 5 branches.
     * @param centerX Coordonnée X du centre
     * @param centerY Coordonnée Y du centre
     * @param radius1 Rayon "externe" (pointe de l'étoile)
     * @param radius2 Rayon "interne" (creux de l'étoile)
     * @param numRays Nombre de branches (5 pour une étoile classique)
     * @return Polygon représentant l'étoile
     */
    private Polygon createStar(int centerX, int centerY, double radius1, double radius2, int numRays) {
        Polygon polygon = new Polygon();
        double angle = Math.PI / numRays;
        
        for (int i = 0; i < 2 * numRays; i++) {
            double r = (i % 2 == 0) ? radius1 : radius2;
            double x = centerX + r * Math.cos(i * angle);
            double y = centerY + r * Math.sin(i * angle);
            polygon.addPoint((int) x, (int) y);
        }
        return polygon;
    }
}
