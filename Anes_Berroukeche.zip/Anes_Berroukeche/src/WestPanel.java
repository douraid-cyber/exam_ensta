import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class WestPanel extends JPanel {
    public WestPanel() {
        setLayout(new BorderLayout());
        setBackground(Color.CYAN);

        // Zone de texte avec barre de défilement
        JTextArea textArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(textArea);
        add(scrollPane, BorderLayout.CENTER);

        // Contrôles pour modifier la couleur du fond et du texte
        JPanel colorControls = new JPanel();
        JComboBox<String> bgColorCombo = new JComboBox<>(new String[]{"Blanc", "Jaune", "Rose"});
        JComboBox<String> textColorCombo = new JComboBox<>(new String[]{"Noir", "Rouge", "Bleu"});

        bgColorCombo.addActionListener(e -> {
            String selectedColor = (String) bgColorCombo.getSelectedItem();
            switch (selectedColor) {
                case "Blanc" -> textArea.setBackground(Color.WHITE);
                case "Jaune" -> textArea.setBackground(Color.YELLOW);
                case "Rose" -> textArea.setBackground(Color.PINK);
            }
        });

        textColorCombo.addActionListener(e -> {
            String selectedColor = (String) textColorCombo.getSelectedItem();
            switch (selectedColor) {
                case "Noir" -> textArea.setForeground(Color.BLACK);
                case "Rouge" -> textArea.setForeground(Color.RED);
                case "Bleu" -> textArea.setForeground(Color.BLUE);
            }
        });

        colorControls.add(new JLabel("Fond:"));
        colorControls.add(bgColorCombo);
        colorControls.add(new JLabel("Texte:"));
        colorControls.add(textColorCombo);

        add(colorControls, BorderLayout.SOUTH);
    }
}