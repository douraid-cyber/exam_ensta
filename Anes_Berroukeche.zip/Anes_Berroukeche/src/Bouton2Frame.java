import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Bouton2Frame extends JFrame {

    private JSlider colorSlider;
    private JRadioButton rButton, vButton, bButton;

    // Couleur actuelle de la fenêtre
    private Color currentColor = Color.WHITE;

    public Bouton2Frame() {
        super("Bouton 2 - Fenêtre Circulaire");

        // 1) Fenêtre ronde, sans bordure
        setUndecorated(true);
        setSize(400, 400);
        setShape(new Ellipse2D.Double(0, 0, 400, 400));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // 2) Panneau principal qui contient le slider et les boutons
        //    On le rend transparent pour voir la couleur du "cadre" derrière
        JPanel content = new JPanel(new BorderLayout());
        content.setOpaque(false);
        setContentPane(content);

        // 3) Slider 0..255
        colorSlider = new JSlider(0, 255, 0);
        colorSlider.setPaintTicks(true);
        colorSlider.setPaintLabels(true);
        colorSlider.setMajorTickSpacing(50);
        colorSlider.setMinorTickSpacing(10);
        content.add(colorSlider, BorderLayout.CENTER);

        // 4) Panel pour les RadioButtons (R, V, B), également transparent
        JPanel radioPanel = new JPanel();
        radioPanel.setOpaque(false);

        rButton = new JRadioButton("R");
        vButton = new JRadioButton("V");
        bButton = new JRadioButton("B");

        // Groupement pour exclusivité
        ButtonGroup group = new ButtonGroup();
        group.add(rButton);
        group.add(vButton);
        group.add(bButton);

        radioPanel.add(rButton);
        radioPanel.add(vButton);
        radioPanel.add(bButton);
        content.add(radioPanel, BorderLayout.NORTH);

        // 5) Bouton "Fermer" (transparent)
        JButton closeButton = new JButton("Fermer");
        closeButton.setOpaque(false);
        closeButton.addActionListener(e -> dispose());
        content.add(closeButton, BorderLayout.SOUTH);

        // 6) Listeners pour mettre à jour la couleur
        //    - Slider
        colorSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                updateColor();
            }
        });

        //    - RadioButtons
        ActionListener radioListener = e -> updateColor();
        rButton.addActionListener(radioListener);
        vButton.addActionListener(radioListener);
        bButton.addActionListener(radioListener);

        // 7) Couleur initiale
        updateColor();

        setVisible(true);
    }

    /**
     * Calcule la couleur en fonction du slider et du RadioButton sélectionné
     * puis force la fenêtre à se repeindre.
     */
    private void updateColor() {
        int value = colorSlider.getValue();

        if (rButton.isSelected()) {
            currentColor = new Color(value, 0, 0);
        } else if (vButton.isSelected()) {
            currentColor = new Color(0, value, 0);
        } else if (bButton.isSelected()) {
            currentColor = new Color(0, 0, value);
        } else {
            // Si aucun bouton n'est coché : petit dégradé HSB
            float hue = value / 255f;
            currentColor = Color.getHSBColor(hue, 1f, 1f);
        }

        repaint();  // Redessine la fenêtre
    }

    /**
     * On redéfinit paint(Graphics) pour peindre la fenêtre (le "cadre") dans la couleur actuelle.
     */
    @Override
    public void paint(Graphics g) {
        // Peinture du fond
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setColor(currentColor);
        // Remplit tout l'espace de la fenêtre
        g2d.fillRect(0, 0, getWidth(), getHeight());
        
        // On laisse ensuite Swing dessiner le contenu (slider, boutons, etc.)
        super.paint(g2d);
        g2d.dispose();
    }
}
