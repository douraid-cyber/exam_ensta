import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;

public class SouthPanel extends JPanel {
    public SouthPanel() {
        setBackground(Color.ORANGE);
        setPreferredSize(new Dimension(0, 50));
    }
}