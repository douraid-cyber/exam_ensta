import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class HundredButtonsPanel extends JPanel {
    public HundredButtonsPanel() {
        setLayout(new GridLayout(10,10,5,5));
        
        for (int i = 1; i <= 100; i++){
            JButton btn = new JButton("Bouton " + i);
            if(i == 22) {
                btn.addMouseListener(new MouseAdapter(){
                    Color original = btn.getBackground();
                    @Override
                    public void mouseEntered(MouseEvent e){
                        btn.setBackground(Color.RED);
                    }
                    @Override
                    public void mouseExited(MouseEvent e){
                        btn.setBackground(original);
                    }
                });
                btn.addActionListener(e -> new CustomIHM());
            }
            add(btn);
        }
    }
}
