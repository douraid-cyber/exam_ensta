import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;

public class EastPanel extends JPanel {
    public EastPanel() {
        setBackground(Color.MAGENTA);
        setPreferredSize(new Dimension(100, 0));
    }
}