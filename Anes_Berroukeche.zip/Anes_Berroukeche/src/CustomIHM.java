import java.awt.Color;
import java.awt.Dimension;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class CustomIHM extends JFrame {
    public CustomIHM() {
        setTitle("Personnalisation Esthétique");
        setSize(1000, 1000);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Panel principal
        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);  // Couleur de fond neutre

        // Chargement de l'image (assurez-vous que l'image se trouve dans le même répertoire)
        ImageIcon icon = new ImageIcon(getClass().getResource("/15643813-bougies-d-anniversaire-montrant-n-°-22.jpg"));
        
        // Label pour afficher l'image
        JLabel imageLabel = new JLabel(icon);
        imageLabel.setPreferredSize(new Dimension(900,900));
        panel.add(imageLabel);

        // Ajout du panel à la fenêtre
        add(panel);
        setVisible(true);
    }
}
