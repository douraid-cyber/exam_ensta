import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JPanel;

public class SecondTabPanel extends JPanel {
    public SecondTabPanel() {
        setLayout(new GridLayout(10, 10));
        for (int i = 1; i <= 100; i++) {
            JButton btn = new JButton(String.valueOf(i));
            if (i == 22) {
                btn.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseEntered(MouseEvent e) {
                        btn.setBackground(Color.RED);
                    }
                    @Override
                    public void mouseExited(MouseEvent e) {
                        btn.setBackground(null);
                    }
                });
                btn.addActionListener(e -> new CustomIHM());
            }
            add(btn);
        }
    }
}