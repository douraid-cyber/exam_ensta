
package examen;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

public class ExamProject {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ExamProject().createAndShowGUI());
    }

    JFrame frame;

    public void createAndShowGUI() {
        frame = new JFrame("Projet Java - Examen");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 700);

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.add("Interface Principale", new MainInterfacePanel());
        tabbedPane.add("100 Boutons", new HundredButtonsPanel());

        frame.add(tabbedPane);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    // -------------------------------------------------------------------------
    //  1) Le panneau principal (BorderLayout) : haut=3 boutons déplaçables,
    //     centre=zone de dessin, bas=zone de texte, gauche/droite panneaux colorés
    // -------------------------------------------------------------------------
    class MainInterfacePanel extends JPanel {
        public MainInterfacePanel() {
            setLayout(new BorderLayout(5, 5));

            // Zone Haut : boutons déplaçables
            add(new DraggableButtonsPanel(), BorderLayout.NORTH);

            // Zone Bas : zone de texte avec contrôles de couleur
            add(new TextControlPanel(), BorderLayout.SOUTH);

            // Zone Centre : panneau de dessin
            add(new DrawingPanel(), BorderLayout.CENTER);

            // Zone Gauche : panneau coloré
            JPanel left = new JPanel();
            left.setBackground(Color.CYAN);
            left.setPreferredSize(new Dimension(150, 0));
            add(left, BorderLayout.WEST);

            // Zone Droite : panneau coloré
            JPanel right = new JPanel();
            right.setBackground(Color.ORANGE);
            right.setPreferredSize(new Dimension(150, 0));
            add(right, BorderLayout.EAST);
        }
    }

    // -------------------------------------------------------------------------
    //  2) Panneau du haut : contient 3 boutons déplaçables (Bouton 1,2,3)
    // -------------------------------------------------------------------------
    class DraggableButtonsPanel extends JPanel {
        public DraggableButtonsPanel() {
            setLayout(null);
            setPreferredSize(new Dimension(800, 100));

            // Bouton 1 => ouvre InfoDialog
            JButton btn1 = new JButton("Bouton 1");
            btn1.setBounds(20, 20, 120, 30);
            add(btn1);
            makeDraggable(btn1);
            btn1.addActionListener(e -> new InfoDialog(frame).setVisible(true));

            // Bouton 2 => ouvre ColorDialog
            JButton btn2 = new JButton("Bouton 2");
            btn2.setBounds(160, 20, 120, 30);
            add(btn2);
            makeDraggable(btn2);
            btn2.addActionListener(e -> new ColorDialog(frame).setVisible(true));

            // Bouton 3 => ouvre la fenêtre polygonale via openPolygonalWindow()
            JButton btn3 = new JButton("Bouton 3");
            btn3.setBounds(300, 20, 120, 30);
            add(btn3);
            makeDraggable(btn3);
            // *** On remplace l'ancienne classe PolygonDialog par :
            btn3.addActionListener(e -> openPolygonalWindow());
        }

        private void makeDraggable(JButton btn) {
            final Point[] origin = new Point[1];
            btn.addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    origin[0] = e.getPoint();
                }
            });
            btn.addMouseMotionListener(new MouseMotionAdapter() {
                public void mouseDragged(MouseEvent e) {
                    Point p = btn.getLocation();
                    int x = p.x + e.getX() - origin[0].x;
                    int y = p.y + e.getY() - origin[0].y;
                    // Contrainte aux limites du panneau
                    if (x < 0) x = 0;
                    if (y < 0) y = 0;
                    if (x + btn.getWidth() > getWidth()) x = getWidth() - btn.getWidth();
                    if (y + btn.getHeight() > getHeight()) y = getHeight() - btn.getHeight();
                    btn.setLocation(x, y);
                }
            });
        }

        // ---------------------------------------------------------------------
        //  Nouvelle méthode pour ouvrir la fenêtre polygonale
        // ---------------------------------------------------------------------
        private void openPolygonalWindow() {
            // 1) Créer un JDialog sans bordures
            JDialog dialog = new JDialog(frame, "Fenêtre Polygonale", true);
            dialog.setUndecorated(true);
            dialog.setSize(400, 400);
            // on peut centrer par rapport à la fenêtre principale
            dialog.setLocationRelativeTo(frame);

            // 2) Définir la forme via un Area (carré central + 3 cercles)
            Area customShape = createCustomShape();
            dialog.setShape(customShape);

            // 3) Contenu : un PolygonalPanel avec 4 boutons
            PolygonalPanel panel = new PolygonalPanel(dialog);
            dialog.setContentPane(panel);

            // 4) Afficher
            dialog.setVisible(true);
        }

        /**
         * Construit un Area avec :
         *  - Un carré (100,100, 150×150)
         *  - Un cercle bas gauche
         *  - Deux cercles en haut à droite
         */
        private Area createCustomShape() {
            // Carré central
            Area shape = new Area(new Rectangle2D.Double(100, 100, 150, 150));

            // Cercle bas gauche
            shape.add(new Area(new Ellipse2D.Double(60, 220, 80, 80)));

            // Cercle haut droite
            shape.add(new Area(new Ellipse2D.Double(230, 70, 80, 80)));

            // Deuxième cercle haut droite
            shape.add(new Area(new Ellipse2D.Double(260, 30, 80, 80)));

            return shape;
        }

        /**
         * Panneau polygonal (layout null) qui contient
         * 4 boutons : X, O, Y, et l'étoile.
         */
        class PolygonalPanel extends JPanel {
            private final JDialog parentDialog;

            public PolygonalPanel(JDialog dialog) {
                this.parentDialog = dialog;
                setLayout(null);
                setBackground(new Color(120,120,120));

                initButtons();
            }

            private void initButtons() {
                // Bouton X (bas gauche)
                JButton boutonX = new JButton("X");
                boutonX.setBounds(70, 240, 40, 40);
                configurerBoutonSurvol(boutonX, Color.RED, Color.LIGHT_GRAY);
                boutonX.addActionListener(e ->
                    JOptionPane.showMessageDialog(this, "Bouton X cliqué !")
                );
                add(boutonX);

                // Bouton O (haut droite)
                JButton boutonO = new JButton("O");
                boutonO.setBounds(240, 80, 40, 40);
                configurerBoutonSurvol(boutonO, Color.CYAN, Color.LIGHT_GRAY);
                boutonO.addActionListener(e ->
                    JOptionPane.showMessageDialog(this, "Bouton O cliqué !")
                );
                add(boutonO);

                // Bouton Y (2ᵉ cercle haut droite)
                JButton boutonY = new JButton("Y");
                boutonY.setBounds(270, 40, 40, 40);
                configurerBoutonSurvol(boutonY, Color.BLUE, Color.LIGHT_GRAY);
                boutonY.addActionListener(e ->
                    JOptionPane.showMessageDialog(this, "Bouton Y cliqué !")
                );
                add(boutonY);

                // Bouton Étoile (ferme la fenêtre)
                JButton boutonEtoile = new JButton("★");
                boutonEtoile.setBounds(160, 150, 50, 50);
                boutonEtoile.setForeground(Color.YELLOW);
                boutonEtoile.setFont(new Font("Dialog", Font.BOLD, 20));
                configurerBoutonSurvol(boutonEtoile, new Color(255,215,0), Color.GRAY);
                boutonEtoile.addActionListener(e -> parentDialog.dispose());
                add(boutonEtoile);
            }

            /**
             * Méthode utilitaire : changer la couleur du bouton au survol
             */
            private void configurerBoutonSurvol(JButton btn, Color over, Color base) {
                btn.setBackground(base);
                btn.setOpaque(true);
                btn.setBorderPainted(false);

                btn.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseEntered(MouseEvent e) {
                        btn.setBackground(over);
                    }
                    @Override
                    public void mouseExited(MouseEvent e) {
                        btn.setBackground(base);
                    }
                });
            }
        }
    }

    // -------------------------------------------------------------------------
    // Fenêtre de saisie (Bouton 1)
    // -------------------------------------------------------------------------
    class InfoDialog extends JDialog {
        public InfoDialog(Frame owner) {
            super(owner, "Formulaire d'information", true);
            setSize(300, 250);
            setLocationRelativeTo(owner);
            setUndecorated(true);

            JPanel panel = new RoundedPanel();
            panel.setLayout(new GridLayout(6, 2, 5, 5));

            panel.add(new JLabel("Nom:"));
            JTextField tfNom = new JTextField();
            panel.add(tfNom);

            panel.add(new JLabel("Prénom:"));
            JTextField tfPrenom = new JTextField();
            panel.add(tfPrenom);

            panel.add(new JLabel("Âge:"));
            JTextField tfAge = new JTextField();
            panel.add(tfAge);

            panel.add(new JLabel("École:"));
            JTextField tfEcole = new JTextField();
            panel.add(tfEcole);

            JButton btnOK = new JButton("OK");
            JButton btnClose = new JButton("Fermer");
            JLabel lblResult = new JLabel(" ");
            panel.add(btnOK);
            panel.add(btnClose);
            panel.add(lblResult);

            btnOK.addActionListener(e -> {
                String info = "[" + tfNom.getText() + ", " + tfPrenom.getText() + ", " +
                              tfAge.getText() + ", " + tfEcole.getText() + "]";
                lblResult.setText(info);
            });
            btnClose.addActionListener(e -> dispose());

            add(panel);
        }

        // Petit panneau arrondi pour le style
        class RoundedPanel extends JPanel {
            public RoundedPanel() {
                setOpaque(false);
            }
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
                super.paintComponent(g);
            }
        }
    }

    // -------------------------------------------------------------------------
    //  Fenêtre circulaire (Bouton 2)
    // -------------------------------------------------------------------------
    class ColorDialog extends JDialog {
        public ColorDialog(Frame owner) {
            super(owner, "Modifier Couleur", true);
            setSize(300, 300);
            setLocationRelativeTo(owner);
            setUndecorated(true);

            // Forme circulaire
            setShape(new Ellipse2D.Double(0, 0, 300, 300));

            JPanel panel = new JPanel(new BorderLayout());
            JSlider slider = new JSlider(0, 255, 128);
            panel.add(slider, BorderLayout.CENTER);

            JPanel checkPanel = new JPanel(new FlowLayout());
            JCheckBox chkR = new JCheckBox("R");
            JCheckBox chkG = new JCheckBox("G");
            JCheckBox chkB = new JCheckBox("B");
            JCheckBox chkA = new JCheckBox("Alpha");
            checkPanel.add(chkR);
            checkPanel.add(chkG);
            checkPanel.add(chkB);
            checkPanel.add(chkA);
            panel.add(checkPanel, BorderLayout.NORTH);

            JPanel colorPanel = new JPanel();
            colorPanel.setPreferredSize(new Dimension(50, 50));
            colorPanel.setBackground(new Color(128, 128, 128));
            panel.add(colorPanel, BorderLayout.WEST);

            JButton btnClose = new JButton("Fermer");
            panel.add(btnClose, BorderLayout.SOUTH);

            slider.addChangeListener(e -> {
                int val = slider.getValue();
                Color c = colorPanel.getBackground();
                int r = c.getRed(), g = c.getGreen(), b = c.getBlue(), a = c.getAlpha();

                if (chkR.isSelected()) r = val;
                if (chkG.isSelected()) g = val;
                if (chkB.isSelected()) b = val;
                if (chkA.isSelected()) a = val;

                Color newColor = new Color(r, g, b, a);
                colorPanel.setBackground(newColor);
                panel.setBackground(newColor);
            });

            btnClose.addActionListener(e -> dispose());
            add(panel);
        }
    }

    // -------------------------------------------------------------------------
    //  6) Panneau de dessin (Centre)
    // -------------------------------------------------------------------------
    class DrawingPanel extends JPanel {
        private Color drawColor = Color.BLACK;
        private float drawWidth = 2.0f;
        private boolean dashed = false;
        private Point startPoint;
        private List<LineSegment> segments = new ArrayList<>();

        public DrawingPanel() {
            setLayout(new BorderLayout());

            // Panneau de contrôle en haut
            JPanel controls = new JPanel();
            String[] colors = {"Black", "Red", "Green", "Blue"};
            JComboBox<String> colorCombo = new JComboBox<>(colors);
            controls.add(new JLabel("Couleur:"));
            controls.add(colorCombo);

            String[] styles = {"Continu", "Pointillé"};
            JComboBox<String> styleCombo = new JComboBox<>(styles);
            controls.add(new JLabel("Style:"));
            controls.add(styleCombo);

            String[] widths = {"1", "2", "3", "4", "5"};
            JComboBox<String> widthCombo = new JComboBox<>(widths);
            controls.add(new JLabel("Épaisseur:"));
            controls.add(widthCombo);

            add(controls, BorderLayout.NORTH);

            // Listeners pour changer la couleur, style, épaisseur
            colorCombo.addActionListener(e -> {
                String sel = (String) colorCombo.getSelectedItem();
                if ("Red".equals(sel))        drawColor = Color.RED;
                else if ("Green".equals(sel)) drawColor = Color.GREEN;
                else if ("Blue".equals(sel))  drawColor = Color.BLUE;
                else                          drawColor = Color.BLACK;
            });
            styleCombo.addActionListener(e -> {
                String sel = (String) styleCombo.getSelectedItem();
                dashed = "Pointillé".equals(sel);
            });
            widthCombo.addActionListener(e -> {
                drawWidth = Float.parseFloat((String) widthCombo.getSelectedItem());
            });

            DrawArea area = new DrawArea();
            add(area, BorderLayout.CENTER);
        }

        class DrawArea extends JPanel {
            public DrawArea() {
                setBackground(Color.WHITE);
                addMouseListener(new MouseAdapter() {
                    public void mousePressed(MouseEvent e) {
                        startPoint = e.getPoint();
                    }
                    public void mouseReleased(MouseEvent e) {
                        if (startPoint != null) {
                            segments.add(new LineSegment(
                                    startPoint, e.getPoint(),
                                    drawColor, drawWidth, dashed));
                            startPoint = null;
                            repaint();
                        }
                    }
                });
                addMouseMotionListener(new MouseMotionAdapter() {
                    public void mouseDragged(MouseEvent e) {
                        repaint();
                    }
                });
            }

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                // Dessiner les segments déjà tracés
                for (LineSegment seg : segments) {
                    seg.draw(g2);
                }
                // Dessiner la ligne en cours
                if (startPoint != null) {
                    g2.setColor(drawColor);
                    Stroke old = g2.getStroke();

                    if (dashed) {
                        g2.setStroke(new BasicStroke(drawWidth,
                                                     BasicStroke.CAP_BUTT,
                                                     BasicStroke.JOIN_BEVEL,
                                                     0, new float[]{5}, 0));
                    } else {
                        g2.setStroke(new BasicStroke(drawWidth));
                    }

                    Point current = getMousePosition();
                    if (current != null) {
                        g2.drawLine(startPoint.x, startPoint.y, current.x, current.y);
                    }
                    g2.setStroke(old);
                }
            }
        }

        class LineSegment {
            Point p1, p2;
            Color color;
            float width;
            boolean dashed;

            public LineSegment(Point p1, Point p2, Color color,
                               float width, boolean dashed) {
                this.p1 = p1;
                this.p2 = p2;
                this.color = color;
                this.width = width;
                this.dashed = dashed;
            }

            public void draw(Graphics2D g2) {
                g2.setColor(color);
                Stroke old = g2.getStroke();
                if (dashed) {
                    g2.setStroke(new BasicStroke(width,
                                                 BasicStroke.CAP_BUTT,
                                                 BasicStroke.JOIN_BEVEL,
                                                 0, new float[]{5}, 0));
                } else {
                    g2.setStroke(new BasicStroke(width));
                }
                g2.drawLine(p1.x, p1.y, p2.x, p2.y);
                g2.setStroke(old);
            }
        }
    }

    // -------------------------------------------------------------------------
    //  7) Panneau de texte avec scroll + 2 boutons de changement de couleur
    // -------------------------------------------------------------------------
    class TextControlPanel extends JPanel {
        public TextControlPanel() {
            setLayout(new BorderLayout());
            JTextArea textArea = new JTextArea(5, 30);
            JScrollPane scroll = new JScrollPane(textArea);
            add(scroll, BorderLayout.CENTER);

            JPanel controls = new JPanel();
            JButton bgButton = new JButton("Fond");
            JButton textButton = new JButton("Texte");
            controls.add(bgButton);
            controls.add(textButton);
            add(controls, BorderLayout.SOUTH);

            bgButton.addActionListener(e -> {
                Color c = JColorChooser.showDialog(this, "Couleur de fond", textArea.getBackground());
                if (c != null) textArea.setBackground(c);
            });
            textButton.addActionListener(e -> {
                Color c = JColorChooser.showDialog(this, "Couleur du texte", textArea.getForeground());
                if (c != null) textArea.setForeground(c);
            });
        }
    }

    // -------------------------------------------------------------------------
    //  8) Onglet "100 boutons", dont le 22ᵉ ouvre AestheticFrame
    // -------------------------------------------------------------------------
    class HundredButtonsPanel extends JPanel {
        public HundredButtonsPanel() {
            setLayout(new GridLayout(10, 10, 5, 5));
            for (int i = 1; i <= 100; i++) {
                JButton btn = new JButton(String.valueOf(i));
                if (i == 22) {
                    btn.addMouseListener(new MouseAdapter() {
                        Color orig;
                        public void mouseEntered(MouseEvent e) {
                            orig = btn.getBackground();
                            btn.setBackground(Color.RED);
                        }
                        public void mouseExited(MouseEvent e) {
                            btn.setBackground(orig);
                        }
                    });
                    btn.addActionListener(e -> new AestheticFrame().setVisible(true));
                }
                add(btn);
            }
        }
    }

    // -------------------------------------------------------------------------
    //  9) 
    // -------------------------------------------------------------------------
    class AestheticFrame extends JFrame {
        public AestheticFrame() {
            setTitle("Nouvelle IHM esthétique");
            setSize(500, 400);
            setLocationRelativeTo(frame);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            JPanel panel = new JPanel() {
                @Override
                protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    Graphics2D g2 = (Graphics2D) g;
                    GradientPaint gp = new GradientPaint(
                            0, 0, Color.CYAN,
                            getWidth(), getHeight(), Color.MAGENTA);
                    g2.setPaint(gp);
                    g2.fillRect(0, 0, getWidth(), getHeight());
                }
            };
            panel.setLayout(new BorderLayout());

            JLabel label = new JLabel("Bienvenue dans la nouvelle IHM!", SwingConstants.CENTER);
            label.setFont(new Font("Arial", Font.BOLD, 18));
            panel.add(label, BorderLayout.CENTER);
            add(panel);
        }
    }
}
