package swingComponent;

import javax.swing.*;
import java.awt.*;

public class OngletPrincipal extends JPanel {

    public OngletPrincipal() {
    	// constructeur de l'interface principale
    	
    	// organiser les composants selon les bords
        setLayout(new BorderLayout());
        
        add(new ZoneHaut(), BorderLayout.NORTH);
        add(new ZoneBas(), BorderLayout.SOUTH);
        add(new ZoneGauche(), BorderLayout.WEST);
        add(new ZoneDroite(), BorderLayout.EAST);
        add(new ZoneCentre(), BorderLayout.CENTER);
    }
}
