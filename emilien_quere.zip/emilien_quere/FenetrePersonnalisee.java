package swingComponent;

import javax.swing.*;
import java.awt.*;

public class FenetrePersonnalisee extends JFrame {

    public FenetrePersonnalisee() {
    	
    	// classe pour la fenetre secr�te qui s'ouvre dans l'interface des boutons
    	
        setTitle("Fen�tre secr�te");
        setSize(400, 200);
        setLocationRelativeTo(null);
   
        // panneau pour l'affichage 
        JPanel panel = new JPanel() {
        	
        	
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                
             // coloration du fond en vert
                g.setColor(new Color(0, 255, 0));
                
                g.fillRect(0, 0, getWidth(), getHeight());

                // message secret
                g.setColor(Color.BLACK);
                g.setFont(new Font("Courier New", Font.BOLD, 24)); // police type hacking
                g.drawString("Connecting to ENSTA Secret Network... "
                		+ "Access Denied: Professor is too powerful.", 20, 100); // x = 20; y = 100 :position du texte
            }
        };

        setContentPane(panel);
    }
}
