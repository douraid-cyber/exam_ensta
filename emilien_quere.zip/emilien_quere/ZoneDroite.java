package swingComponent;
import javax.swing.*;
import java.awt.*;

public class ZoneDroite extends JPanel {

    private JTextArea zoneTexte;
    private JComboBox<String> couleurTexteBox; // liste d�roulante pour la couleur du texte 
    private JComboBox<String> couleurFondBox; // liste d�roulante pour la couleur du fond (impl�mentation non-aboutie)
    
    
    public ZoneDroite() {
        setPreferredSize(new Dimension(200, 0));
        setLayout(new BorderLayout());

        // zone de texte avec scrollbar (verticale et horizontale)
        zoneTexte = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(zoneTexte, 
            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, 
            JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);  


        add(scrollPane, BorderLayout.CENTER);

        // panneau de configg en haut
        JPanel panelConfig = new JPanel();


        couleurTexteBox = new JComboBox<>(new String[]{"Noir", "Rouge", "Vert", "Bleu", "Cyan", "Magenta"});
        couleurFondBox = new JComboBox<>(new String[]{"Blanc", "Jaune", "Gris Clair", "Rose"});

        panelConfig.add(new JLabel("Texte :"));
        panelConfig.add(couleurTexteBox);
        
        // probl�me : la liste ne s'affiche pas ?
        panelConfig.add(new JLabel("Fond :"));
        panelConfig.add(couleurFondBox);

        add(panelConfig, BorderLayout.NORTH);

        // listeners pour changement de couleur
        couleurTexteBox.addActionListener(e -> mettreAJourCouleurs());
        couleurFondBox.addActionListener(e -> mettreAJourCouleurs());

        // initialisation des couleurs
        mettreAJourCouleurs();
    }

    private void mettreAJourCouleurs() {
// on distingue tous les cas 
        switch ((String) couleurTexteBox.getSelectedItem()) {
            case "Rouge":
                zoneTexte.setForeground(Color.RED);
                break;
            case "Vert":
                zoneTexte.setForeground(Color.GREEN);
                break;
            case "Bleu":
                zoneTexte.setForeground(Color.BLUE);
                break;
            case "Cyan":
                zoneTexte.setForeground(Color.CYAN);
                break;
            case "Magenta":
                zoneTexte.setForeground(Color.MAGENTA);
                break;
            default:
                zoneTexte.setForeground(Color.BLACK);
                break;
        }

        // couleur du fond
        Color couleurChoisie;
        switch ((String) couleurFondBox.getSelectedItem()) {
            case "Jaune":
                couleurChoisie = Color.YELLOW;
                break;
            case "Gris Clair":
                couleurChoisie = Color.LIGHT_GRAY;
                break;
            case "Rose":
                couleurChoisie = Color.PINK;
                break;
            default:
                couleurChoisie = Color.WHITE;
                break;
        }

        // probl�me : la couleur ne s'affiche pas ? 
        zoneTexte.setBackground(couleurChoisie);
    }
}
