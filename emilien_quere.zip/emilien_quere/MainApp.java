package swingComponent;

public class MainApp {

    public static void main(String[] args) {

            MainFrame mainFrame = new MainFrame();
            mainFrame.setVisible(true);
        
    }
}
