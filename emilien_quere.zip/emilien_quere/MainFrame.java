package swingComponent;

import javax.swing.*;

public class MainFrame extends JFrame {
	

    public MainFrame() {
    	// constructeur de la fen�tre principale.
    	
        setTitle("Projet IHM");
        setSize(800, 600);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
     // pour centrer la fenetre
        setLocationRelativeTo(null);

     // conteneur pour les onglets de l'interface
        JTabbedPane onglets = new JTabbedPane();

     // 1er onglet : contient l'interface principale
        onglets.addTab("Interface principale", new OngletPrincipal());
        
     //2eme onglet : contient la grille de 100 bouton
        onglets.addTab("100 Boutons", new OngletBoutons());

        setContentPane(onglets);
    }
}
