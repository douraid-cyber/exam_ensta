package swingComponent;

import javax.swing.*;
import java.awt.*;

public class ZoneBas extends JPanel {
    public ZoneBas() {
    	
    	// constructeur pour une zone vide
        setPreferredSize(new Dimension(0, 100));
        setBackground(Color.GRAY);

        JLabel label = new JLabel("Zone Bas - Footer ou Infos");
        add(label);
    }
}
