package swingComponent;

import javax.swing.*;
import java.awt.*;

public class FenetreCercle extends JFrame {

    private CerclePanel cerclePanel;
    private JSlider sliderCouleur; // slider pour les d�grad�s de couleur
    private JCheckBox checkRouge, checkVert, checkBleu, checkAlpha; // pour activer ou d�sactiver les "param�tres"

    public FenetreCercle() {
    	
    	
        setSize(300, 350);
        setUndecorated(true); // pour supprimer la bordure
        setLocationRelativeTo(null);
        setLayout(new BorderLayout()); // pour organiser les �l�ments


        cerclePanel = new CerclePanel();
        add(cerclePanel, BorderLayout.CENTER);

        // slider et checkboxes pour modifier la couleur
        sliderCouleur = new JSlider(0, 255, 0); // valeur max=255
   
     // les cases � cocher pour les couleurs
        JPanel controles = new JPanel(new GridLayout(2, 2));
        checkRouge = new JCheckBox("R", true);
        checkVert = new JCheckBox("G", true);
        checkBleu = new JCheckBox("B", true);
        checkAlpha = new JCheckBox("Alpha");

        controles.add(checkRouge);
        controles.add(checkVert);
        controles.add(checkBleu);
        controles.add(checkAlpha);

        
         // panneau sup�rieur: checkboxes et le slider
        
        JPanel panelHaut = new JPanel(new BorderLayout());
        panelHaut.add(controles, BorderLayout.NORTH);
        panelHaut.add(sliderCouleur, BorderLayout.SOUTH);
        add(panelHaut, BorderLayout.NORTH);

        // bouton Fermer 
        JButton boutonFermer = new JButton("Fermer");
        boutonFermer.addActionListener(e -> dispose());  // ferme la fen�tre
        add(boutonFermer, BorderLayout.SOUTH);

        //  met � jour la couleur du cercle
        sliderCouleur.addChangeListener(e -> updateColor());

        // fermer la fen�tre en cliquant sur le cercle aussi
        cerclePanel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                dispose();
            }
        });
    }

    private void updateColor() {
        int value = sliderCouleur.getValue(); //r�cup�re la valeur de l'intensti� 
        int r = checkRouge.isSelected() ? value : 0;
        int g = checkVert.isSelected() ? value : 0;
        int b = checkBleu.isSelected() ? value : 0;
        int alpha = checkAlpha.isSelected() ? value : 255;

        cerclePanel.setCouleur(new Color(r, g, b, alpha));
    }

    //  classe interne pour le dessin du cercle
    private class CerclePanel extends JPanel {
        private Color couleurActuelle = Color.BLACK; // couleur par f�faut 

        public void setCouleur(Color couleur) {
            this.couleurActuelle = couleur;
            repaint(); // "force" le rafraichissement 
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g); // garantit "l'effacement" du dessin
            Graphics2D g2d = (Graphics2D) g;
            
            // antialiasing pour la fluidit�
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            
            int taille = Math.min(getWidth(), getHeight()) - 20; // on laisse une marge de 20 pixels
            
         // on centre le cercle
            int x = (getWidth() - taille) / 2;
            int y = (getHeight() - taille) / 2;

            g2d.setColor(couleurActuelle);
            g2d.fillOval(x, y, taille, taille);
        }
    }
}
