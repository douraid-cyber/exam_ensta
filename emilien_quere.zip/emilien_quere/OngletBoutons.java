package swingComponent;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class OngletBoutons extends JPanel {

    public OngletBoutons() {
    	
    	// constructeur de la grille des boutons 
    	
    	
    	// GridLayout pour simuler la grille 
        setLayout(new GridLayout(10, 10));

        for (int i = 1; i <= 100; i++) {
            JButton bouton = new JButton("Bouton " + i);
            
            if (i == 22) {
                youfoundasecret(bouton);
            }
            add(bouton);
        }
    }

    private void youfoundasecret(JButton bouton) {
        bouton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
            	// changement de couleur au survol
                bouton.setBackground(Color.RED);
            }

            @Override
            public void mouseExited(MouseEvent e) {
            	// couleur "par d�faut" (absence de survol)
                bouton.setBackground(UIManager.getColor("Button.background"));
            }
            @Override
            public void mouseClicked(MouseEvent e) {
            	// fen�tre cach�e
                new FenetrePersonnalisee().setVisible(true);
            }
        });
    }
}
