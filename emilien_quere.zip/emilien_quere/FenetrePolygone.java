package swingComponent;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FenetrePolygone extends JFrame {

    private JButton boutonX, boutonY, boutonCentral;
    private Polygon polygone; // pour "stocker" le polygone 

    public FenetrePolygone() {
    	
    	
        setSize(300, 300);
        setUndecorated(true); // bordure supprimée
        setLocationRelativeTo(null); // fenetre centrée
        setBackground(new Color(0, 0, 0, 0)); // fond transparent

        setLayout(null); // placement manuel des boutons

        creerPolygone();
        creerBoutons();

        setShape(polygone); // la fenetre a la forme du polygone
    }

    private void creerPolygone() {
    	
    	// paramètres géométriques 
        int[] x = {100, 200, 200, 250, 250, 200, 200, 100, 100, 50, 50, 100};
        int[] y = {50, 50, 0, 0, 100, 100, 200, 200, 250, 250, 100, 100};

        polygone = new Polygon(x, y, x.length);
    }

    private void creerBoutons() {
        boutonX = creerBouton("X");
        boutonY = creerBouton("Y");

        boutonX.setBounds(60, 210, 40, 40);  // en bas à gauche
        boutonY.setBounds(210, 60, 40, 40);  // en haut à droite

     
        boutonCentral = creerBoutonCentral();
        boutonCentral.setBounds(120, 120, 40, 40); // milieu
        
        // on désactive le relief et la bordure par défaut 
        boutonCentral.setFocusPainted(false);
        boutonCentral.setBorderPainted(false);
        
        // on modifie le curseur 
        boutonCentral.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        boutonCentral.addActionListener(e -> dispose());


        // apparition de la couleur pendant le survol
        ajouterEffetSurvol(boutonX);
        ajouterEffetSurvol(boutonY);
        ajouterEffetSurvol(boutonCentral);

        // ajout des boutons à la fenetre
        add(boutonX);
        add(boutonY);
        add(boutonCentral);
    }
    
    private JButton creerBoutonCentral() {
        return new JButton() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // fond jaune 
                g2d.setColor(Color.YELLOW);
                g2d.fillOval(0, 0, getWidth(), getHeight());

                // dessin de l'étoile 
                g2d.setColor(Color.BLACK);
                dessinerEtoile(g2d, getWidth() / 2, getHeight() / 2, 15, 5);
            }
        };
    }
    
    
    // fonction créée avec chatgpt
    private void dessinerEtoile(Graphics2D g2d, int x, int y, int rayon, int nombreBranches) {
        double angle = Math.PI / nombreBranches;

        int[] xPoints = new int[nombreBranches * 2];
        int[] yPoints = new int[nombreBranches * 2];

        for (int i = 0; i < nombreBranches * 2; i++) {
            double currentAngle = i * angle;
            int currentRayon = (i % 2 == 0) ? rayon : rayon / 2;

            xPoints[i] = x + (int) (Math.cos(currentAngle) * currentRayon);
            yPoints[i] = y + (int) (Math.sin(currentAngle) * currentRayon);
        }

        g2d.fillPolygon(xPoints, yPoints, nombreBranches * 2);
    }


    private JButton creerBouton(String texte) {
        JButton bouton = new JButton(texte);
        bouton.setFocusPainted(false);
        bouton.setBorderPainted(false);
        bouton.setBackground(Color.GRAY);
        return bouton;
    }

    private void ajouterEffetSurvol(JButton bouton) {
        bouton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                bouton.setBackground(Color.DARK_GRAY);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                bouton.setBackground(Color.GRAY);
            }
        });
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g); // on redéfinit la méthode pour dessiner correctement le polygone
        Graphics2D g2d = (Graphics2D) g;

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2d.setColor(new Color(50, 50, 50));  // gris foncé comme sur l'illusatration 
        g2d.fill(polygone);
    }
}
