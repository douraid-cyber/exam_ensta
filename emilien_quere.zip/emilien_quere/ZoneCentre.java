package swingComponent;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Line2D;
import java.util.ArrayList;
import java.util.List;

public class ZoneCentre extends JPanel {

    // enregistrement des traits 
    private List<Trait> traits = new ArrayList<>();

    // options choisies
    private Color couleurActuelle = Color.BLACK;
    private float epaisseurActuelle = 1.0f;
    private boolean traitPointille = false;

    // coordonn�es pour sauvegarder les traits  (suivre la postion du curseur)
    private int xDernier, yDernier;

    // composants barr ed'outils
    private JComboBox<String> couleurBox;
    private JComboBox<String> typeBox;
    private JComboBox<Integer> largeurBox;

    public ZoneCentre() {
        setBackground(Color.WHITE);
        setLayout(new BorderLayout());

        // barre de config en haut de la zone
        JPanel panelConfig = new JPanel();

        // choix de la couleur
        couleurBox = new JComboBox<>(new String[]{"Noir", "Rouge", "Vert", "Bleu", "Cyan", "Magenta"});
        panelConfig.add(new JLabel("Couleur :"));
        panelConfig.add(couleurBox);

        // choix du type de trait
        typeBox = new JComboBox<>(new String[]{"Continu", "Pointill�"});
        panelConfig.add(new JLabel("Type :"));
        panelConfig.add(typeBox);

        // choix de la taille
        largeurBox = new JComboBox<>(new Integer[]{1, 2, 3, 5, 8});
        panelConfig.add(new JLabel("Taille :"));
        panelConfig.add(largeurBox);

        add(panelConfig, BorderLayout.NORTH);

        // gestion des �v�nements "souris" pour le dessin 
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
            	
            	// on enregistre le "1er point"
                xDernier = e.getX();
                yDernier = e.getY();
                mettreAJourConfiguration(); // on r�cup�re la config actuelle
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
            	
            	// on d�place la souris = nouveau segment 
                int x = e.getX();
                int y = e.getY();

                traits.add(new Trait(xDernier, yDernier, x, y, couleurActuelle, epaisseurActuelle, traitPointille));

                xDernier = x;
                yDernier = y;
                repaint(); // on redessine tout 
            }
        });
    }

    // mise � jour des param�tres
    private void mettreAJourConfiguration() {
    	
    	// tous les cas possibles 
        switch ((String) couleurBox.getSelectedItem()) {
            case "Rouge":
                couleurActuelle = Color.RED;
                break;
            case "Vert":
                couleurActuelle = Color.GREEN;
                break;
            case "Bleu":
                couleurActuelle = Color.BLUE;
                break;
            case "Cyan":
                couleurActuelle = Color.CYAN;
                break;
            case "Magenta":
                couleurActuelle = Color.MAGENTA;
                break;
            default:
                couleurActuelle = Color.BLACK;
                break;
        }

        // mis � jour des param�tres
        epaisseurActuelle = ((Integer) largeurBox.getSelectedItem());
        traitPointille = "Pointill�".equals(typeBox.getSelectedItem());
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        for (Trait trait : traits) {
        	
        	// on parcoure la liste des traits d�j� dessin�s 
        	
        	// on applique les param�tres 
            g2d.setColor(trait.couleur);
            g2d.setStroke(trait.getStroke());
            g2d.draw(new Line2D.Float(trait.x1, trait.y1, trait.x2, trait.y2));
        }
    }

    // classe interne pour stocker les trait
    private static class Trait {
    	
        int x1, y1, x2, y2;
        Color couleur;
        float epaisseur;
        boolean pointille;

        Trait(int x1, int y1, int x2, int y2, Color couleur, float epaisseur, boolean pointille) {
        	// constructeur pour toutes les propri�t�s du trait
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
            this.couleur = couleur;
            this.epaisseur = epaisseur;
            this.pointille = pointille;
        }

        Stroke getStroke() {
        	 // retourne le style du trait
            if (pointille) {
                float[] dash = {10.0f, 10.0f};  // trait pointill�= 10 pixels visibles et 10 "invisibles"
                return new BasicStroke(epaisseur, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 10.0f, dash, 0.0f);
            } else {
                return new BasicStroke(epaisseur, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND); 
                // sinon trait continu
            }
        }
    }
}
