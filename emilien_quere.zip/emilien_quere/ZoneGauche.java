package swingComponent;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JPanel;

public class ZoneGauche extends JPanel {
    private JButton bouton1, bouton2, bouton3;

    public ZoneGauche() {
        setPreferredSize(new Dimension(150, 0));
        setBackground(Color.CYAN);
        setLayout(null);  // on positionne les boutons o� on veut

        initButtons();
    }

    private void initButtons() {
    	// cr�ation des boutons
        bouton1 = createDraggableButton("Bouton 1", 20, 20);
        bouton2 = createDraggableButton("Bouton 2", 20, 70);
        bouton3 = createDraggableButton("Bouton 3", 20, 120);

        add(bouton1);
        add(bouton2);
        add(bouton3);

        // gestion des clics pour les 3 fenetres
        bouton1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new FenetreFormulaire().setVisible(true);
            }
        });

        bouton2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new FenetreCercle().setVisible(true);
            }
        });

        bouton3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new FenetrePolygone().setVisible(true);
            }
        });
    }

    private JButton createDraggableButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 100, 30);

        // gestion du clic initial
        button.addMouseListener(new MouseAdapter() {
            private Point clickPoint;

            @Override
            public void mousePressed(MouseEvent e) {
            	// on clique sur le bouton pour m�moriser la position
                clickPoint = e.getPoint();
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            	// on v�rifie si le bouton est sorti de la zone 
                Point newLocation = button.getLocation();
                if (newLocation.x < 0 || newLocation.y < 0 ||
                    newLocation.x + button.getWidth() > getWidth() ||
                    newLocation.y + button.getHeight() > getHeight()) {
                    // si le bouton sort on le remet � sa position initiale
                    button.setLocation(x, y);
                }
            }
        });

        
        // gestion du drag 
        button.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                Point location = button.getLocation(); // position actuelle 
                int newX = location.x + e.getX() - button.getWidth() / 2;
                int newY = location.y + e.getY() - button.getHeight() / 2;

                // on emp�che le bouton de sortir de la zone
                if (newX < 0) newX = 0;
                if (newY < 0) newY = 0;
                if (newX + button.getWidth() > getWidth()) newX = getWidth() - button.getWidth();
                if (newY + button.getHeight() > getHeight()) newY = getHeight() - button.getHeight();
                
                
                // mis � jour
                button.setLocation(newX, newY);
            }
        });

        return button;
    }
}
