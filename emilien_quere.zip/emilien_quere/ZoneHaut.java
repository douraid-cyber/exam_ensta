package swingComponent;

import javax.swing.*;
import java.awt.*;

public class ZoneHaut extends JPanel {
    public ZoneHaut() {
       	// constructeur pour une zone vide
        setPreferredSize(new Dimension(0, 100));
        setBackground(Color.LIGHT_GRAY);
        setLayout(new FlowLayout(FlowLayout.LEFT));

        JLabel label = new JLabel("Zone Haut");
        add(label);
    }
}
