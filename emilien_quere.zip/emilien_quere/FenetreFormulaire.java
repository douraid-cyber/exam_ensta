package swingComponent;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FenetreFormulaire extends JFrame {

    private JTextField champNom, champPrenom, champAge, champEcole; // champs de texte 
    private JLabel labelResultat; // affichage des infos 

    public FenetreFormulaire() 
    
    {
        setTitle("Formulaire");
        setSize(300, 200);
        setLayout(new GridLayout(5, 2));
        setLocationRelativeTo(null); // centrage
 
        // cr�ation des composants 
        champNom = new JTextField();
        champPrenom = new JTextField();
        champAge = new JTextField();
        champEcole = new JTextField();
        
        labelResultat = new JLabel("Remplissez les champs");

        
        // ajout des composants 
        add(new JLabel("Nom :"));
        add(champNom);
        add(new JLabel("Pr�nom :"));
        add(champPrenom);
        add(new JLabel("�ge :"));
        add(champAge);
        add(new JLabel("�cole :"));
        add(champEcole);

        
        // cr�ation des boutons 
        JButton boutonOK = new JButton("OK");
        JButton boutonFermer = new JButton("Fermer");

        add(boutonOK);
        add(boutonFermer);

        add(labelResultat);

        boutonOK.addActionListener(e -> {
        	// on clique sur "ok" et on r�cup�re le texte des champs 
            String texte = String.format("[%s, %s, %s, %s]", champNom.getText(), champPrenom.getText(),
                    champAge.getText(), champEcole.getText());
            labelResultat.setText(texte); // mis � jour du label
        });

        boutonFermer.addActionListener(e -> dispose());
    }
}
