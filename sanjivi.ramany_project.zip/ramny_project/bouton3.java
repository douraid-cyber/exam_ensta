package ramny_project;


import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Area;

import javax.swing.JButton;
import javax.swing.JFrame;

public class bouton3 extends JFrame{
	private static int mouseX; //avec static, pas besoin de getter et setter
	private static int mouseY;
	
	public bouton3()
	{
		setSize(600, 600); //définition de la JFrame
		setUndecorated(true);
		setLayout(null); //null quand on part d'une feuille blanche
		setBackground(new Color(0,0,0,0)); //premier 0 permet la transparence
		
		addMouseMotionListener(new MouseAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) //la fenêtre suit la souris cliquée
			{
				int x=e.getXOnScreen()-mouseX; //pour que souris reste où elle est
				int y=e.getYOnScreen()-mouseY;
				setLocation(x,y);
			}
		});
		addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				mouseX=e.getX();
				mouseY=e.getY();
			}
		});
		JButton butExit=new JButton("X");
		butExit.setBounds(375,375,40,40);
		butExit.setBackground(Color.red);
		//butExit.setBackground(new Color(255,0,0)); //autre alternative
		butExit.setBorderPainted(false); //plus de gras au bord
		butExit.setFocusPainted(false); //plus de surbrillance quand souris passe dessus
		butExit.setForeground(Color.white);
		butExit.setMargin(new Insets(0,0,0,0));
		butExit.addMouseListener(new MouseListener() { //si new au lieu de adapter, donne toutes les méthodes
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				butExit.setBackground(Color.red);
				
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				butExit.setBackground(Color.DARK_GRAY);
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose(); // juste fermer la fenêtre
				
			}
		});
		
		add(butExit);	
	
	
	
	}
	// Classe Cercle qui encapsule les propriétés d'un cercle
    class Cercle {
        private int x, y, rayon;

        // Constructeur
        public Cercle(int x, int y, int rayon) {
            this.x = x;
            this.y = y;
            this.rayon = rayon;
        }

        // Méthode pour dessiner le cercle
        public void dessiner(Graphics2D g2d) {
            g2d.setColor(Color.GRAY);  // Définir la couleur du cercle
            g2d.fillOval(x - rayon, y - rayon, rayon * 2, rayon * 2);  // Dessiner un cercle (ellipse)
        }
    }

	
@Override
	
	public void paint(Graphics g)
	{
		super.paint(g);
		
		Graphics2D g2d=(Graphics2D) g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
		
		
		Cercle cercle1=new Cercle(400,400,50);
		Cercle cercle2=new Cercle(450,450,50);
		
		
		
		g2d.fillRect(375,375,70,70); //Remplissage du rectangle principal
		g2d.setColor(Color.GRAY);
			
		
		
	}
	

}

