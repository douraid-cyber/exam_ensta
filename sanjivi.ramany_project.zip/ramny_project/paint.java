package ramny_project;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;

public class paint extends JPanel {
    static int lastx;
    static int lasty;
    static List<int[]> lines = new ArrayList<>();

    private Color drawingColor = Color.BLACK; // Couleur du trait
    private float strokeWidth = 1.0f; // Largeur du trait
    private boolean dashed = false; // Type du trait (false = continu, true = pointillé)

    public paint() {
        setBackground(Color.white);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                lastx = e.getX();
                lasty = e.getY();
            }
        });

        addMouseMotionListener(new MouseMotionListener() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                lines.add(new int[]{lastx, lasty, x, y});
                lastx = x;
                lasty = y;
                repaint();
            }

            @Override
            public void mouseMoved(MouseEvent e) {}
        });

        addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {}

            @Override
            public void keyReleased(KeyEvent e) {}

            @Override
            public void keyPressed(KeyEvent e) {
                if (e.isControlDown() && e.getKeyCode() == KeyEvent.VK_Z) {
                    if (!lines.isEmpty()) {
                        lines.remove(lines.size() - 1);
                        repaint();
                    }
                }
            }
        });

        setFocusable(true);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g.create();
        
        // Définir le type de trait
        Stroke stroke;
        if (dashed) {
            stroke = new BasicStroke(strokeWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 
                    10, new float[]{10, 10}, 0); // Trait pointillé
        } else {
            stroke = new BasicStroke(strokeWidth); // Trait continu
        }
        
        g2d.setStroke(stroke);
        g2d.setColor(drawingColor);

        for (int[] line : lines) {
            g2d.drawLine(line[0], line[1], line[2], line[3]);
        }
    }

    // Méthodes pour modifier les paramètres du dessin
    public void setDrawingColor(Color color) {
        this.drawingColor = color;
        repaint();
    }

    public void setStrokeType(int selectedType) {
        this.dashed = true ; // Définir si le trait est pointillé
        repaint();
    }

    public void setStrokeWidth(int selectedWidth) {
        this.strokeWidth = selectedWidth; // Définir la largeur du trait
        repaint();
}}
