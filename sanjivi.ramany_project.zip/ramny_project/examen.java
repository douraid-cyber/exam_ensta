package ramny_project;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;

public class examen {

	public static void main(String[] args) {
		JFrame frame = new JFrame("examen");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //
		frame.setSize(600,400);
		
		//##########################################################
		
		frame.setLayout(new BorderLayout(15,15)); // espace entre les panel dans le premier onglet
		
		JPanel pan = new JPanel(new BorderLayout());
		
		JPanel pan1 = new JPanel(new BorderLayout());
		pan1.setBackground(Color.ORANGE);
		pan1.setPreferredSize(new Dimension(600,20));
		pan.add(pan1, BorderLayout.NORTH);
		
		JPanel pan2 = new JPanel(new BorderLayout());
		pan2.setBackground(Color.CYAN);
		pan2.setPreferredSize(new Dimension(600,100));
		JButton but1=new JButton("1");
		JButton but2=new JButton("2");
		JButton but3=new JButton("3");
		pan2.add(but1);
		pan2.add(but2);
		pan2.add(but3);
		// Définir un MouseAdapter pour gérer le drag and release
		MouseAdapter mouseAdapter = new MouseAdapter() {
		    private int offsetX, offsetY;
		    private JButton draggedButton;

		    @Override
		    public void mousePressed(MouseEvent e) {
		        draggedButton = (JButton) e.getSource();
		        offsetX = e.getX();
		        offsetY = e.getY();
		    }

		    @Override
		    public void mouseDragged(MouseEvent e) {
		        if (draggedButton != null) {
		            int x = draggedButton.getX() + e.getX() - offsetX;
		            int y = draggedButton.getY() + e.getY() - offsetY;

		            // Limiter le mouvement dans pan2
		            int maxX = pan2.getWidth() - draggedButton.getWidth();
		            int maxY = pan2.getHeight() - draggedButton.getHeight();
		            x = Math.max(0, Math.min(x, maxX));
		            y = Math.max(0, Math.min(y, maxY));

		            draggedButton.setLocation(x, y);
		        }
		    }

		    @Override
		    public void mouseReleased(MouseEvent e) {
		        draggedButton = null; // Réinitialiser après le drag
		    }
		};

		// Appliquer le MouseListener et le MouseMotionListener aux boutons
		but1.addMouseListener(mouseAdapter);
		but1.addMouseMotionListener(mouseAdapter);

		but2.addMouseListener(mouseAdapter);
		but2.addMouseMotionListener(mouseAdapter);

		but3.addMouseListener(mouseAdapter);
		but3.addMouseMotionListener(mouseAdapter);

		// Définir pan2 avec un null Layout pour permettre le déplacement libre
		pan2.setLayout(null);

		// Définir les positions initiales et tailles des boutons
		but1.setBounds(50, 30, 60, 30);
		but2.setBounds(150, 30, 60, 30);
		but3.setBounds(250, 30, 60, 30);
		
		but2.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseClicked(MouseEvent e) {
				circle c= new circle();           //instancier un objet de classe polyv2 au click
				c.setVisible(true);
				
				
			}
		});
		
		but3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				bouton3 b= new bouton3();           //instancier un objet de classe polyv2 au click
				b.setVisible(true);
			
			}});

		pan.add(pan2, BorderLayout.SOUTH);
		
		
		
		JPanel pan3 = new JPanel(new BorderLayout());
		// Créer un objet paint et l'ajouter dans pan3
        paint paintPanel = new paint(); // Créer une instance de paint
        pan3.add(paintPanel, BorderLayout.CENTER); // Ajouter PaintPanel dans pan3
        pan3.setPreferredSize(new Dimension(300, 300)); // Définir la taille souhaitée pour pan3
        pan.add(pan3, BorderLayout.EAST);
		
		
		
		JPanel pan4 = new JPanel();
		pan4.setLayout(new BoxLayout(pan4, BoxLayout.Y_AXIS)); // Disposition verticale du panel
		pan4.setBackground(Color.gray);
		pan4.add(new JLabel("Choisissez la couleur de la zone de texte:")); // Ajouter un label
		JRadioButton jrb1 = new JRadioButton("Rouge"); // case ronde à cocher
        JRadioButton jrb2 = new JRadioButton("Vert");
        JRadioButton jrb3 = new JRadioButton("Bleu");
        ButtonGroup rb1 = new ButtonGroup(); // les options ne sont pas cochables ensembles
        rb1.add(jrb1);
        rb1.add(jrb2);
        rb1.add(jrb3);
        
        //Ajouter les boutons pour changer la couleur de fond
        pan4.add(jrb1);
        pan4.add(jrb2);
        pan4.add(jrb3);
        
        pan4.add(new JLabel("Choisissez la couleur du texte:"));
        
        // Créer trois boutons pour changer la couleur du texte
        JRadioButton btnBlack = new JRadioButton("Noir");
        JRadioButton btnPink = new JRadioButton("Rose");
        JRadioButton btnBlue = new JRadioButton("Bleu");
        ButtonGroup rb2 = new ButtonGroup(); // les options ne sont pas cochables ensembles
        rb2.add(btnBlack);
        rb2.add(btnPink);
        rb2.add(btnBlue);
        

        // Ajouter les boutons pour changer la couleur du texte
        pan4.add(btnBlack);
        pan4.add(btnPink);
        pan4.add(btnBlue);
        pan.add(pan4,BorderLayout.WEST);
		
		
		
		JPanel pan5 = new JPanel(new BorderLayout());
        JTextArea jta = new JTextArea();
        JScrollPane jscp = new JScrollPane(jta);
        pan5.add(jscp, BorderLayout.CENTER);
        pan.add(pan5, BorderLayout.CENTER);
        
        //ActionListeners pour changer la couleur du fond de la zone de texte
        jrb1.addActionListener(new ActionListener() {  
            @Override
            public void actionPerformed(ActionEvent e) {
                jta.setBackground(Color.RED); // Changer la couleur de fond en rouge
            }
        });
        jrb2.addActionListener(new ActionListener() {  // on change la couleur de pan5 en cliquant sur le bouton
            @Override
            public void actionPerformed(ActionEvent e) {
                jta.setBackground(Color.GREEN); // Changer la couleur de fond en vert
            }
        });
        jrb3.addActionListener(new ActionListener() {  // on change la couleur de pan5 en cliquant sur le bouton
            @Override
            public void actionPerformed(ActionEvent e) {
                jta.setBackground(Color.BLUE); // Changer la couleur de fond en bleu
            }
        });
        
     // ActionListeners pour changer la couleur du texte dans jta
        btnBlack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jta.setForeground(Color.BLACK); // Changer la couleur du texte en noir
            }
        });

        btnPink.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jta.setForeground(Color.PINK); // Changer la couleur du texte en rose
            }
        });

        btnBlue.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jta.setForeground(Color.BLUE); // Changer la couleur du texte en bleu
            }
        });
        // Liste pour la couleur du trait (zone paint de pan3)
        String[] colors = {"Noir", "Rouge", "Bleu"};
        JComboBox<String> colorList = new JComboBox<>(colors);
        pan4.add(new JLabel("Couleur du trait:"));
        pan4.add(colorList);

        // Liste pour la forme du trait (continu ou pointillé)
        String[] strokeTypes = {"Continu", "Pointillés"};
        JComboBox<String> strokeTypeList = new JComboBox<>(strokeTypes);
        pan4.add(new JLabel("Type du trait:"));
        pan4.add(strokeTypeList);

        // Liste pour la largeur du trait
        String[] strokeWidths = {"1", "3", "5"};
        JComboBox<String> strokeWidthList = new JComboBox<>(strokeWidths);
        pan4.add(new JLabel("Largeur du trait:"));
        pan4.add(strokeWidthList);
        
     // ActionListener (avec une disjonction de cas) pour la couleur du trait
        colorList.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedColor = (String) colorList.getSelectedItem();
                switch (selectedColor) {
                    case "Noir":
                        paintPanel.setDrawingColor(Color.BLACK);
                        break;
                    case "Rouge":
                        paintPanel.setDrawingColor(Color.RED);
                        break;
                    case "Bleu":
                        paintPanel.setDrawingColor(Color.BLUE);
                        break;
                }
            }
        });

        // ActionListener pour le type de trait
        strokeTypeList.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                paintPanel.setStrokeType((int) strokeTypeList.getSelectedItem());
            }
        });

        // ActionListener pour la largeur du trait
        strokeWidthList.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                paintPanel.setStrokeWidth((int)strokeWidthList.getSelectedItem());
            }
        });

		JPanel pane = new JPanel();
		
		pane.setLayout(new GridLayout(10, 10, 5, 5)); // grille de taille 10x10 (100 boutons)
        
        // Crée 100 boutons numérotés de 1 à 100
        for (int i = 1; i <= 100; i++) {
            JButton button = new JButton(String.valueOf(i)); // Créer un bouton numéroté avec l'indice
            button.setBorderPainted(false); //on enlève le gras du bord
            button.setFocusPainted(false); //on enlève le focus du bouton
            pane.add(button); // Ajouter le bouton au panel
            if (i==22) {
            	button.addMouseListener(new MouseListener() { 
        			
        			@Override
        			public void mouseReleased(MouseEvent e) {
        				// TODO Auto-generated method stub
        				
        			}
        			
        			@Override
        			public void mousePressed(MouseEvent e) {
        				// TODO Auto-generated method stub
        				
        			}
        			
        			@Override
        			public void mouseExited(MouseEvent e) {
        				button.setBackground(null); // le bouton retrouve sa couleur par défaut
        				
        				
        			}
        			
        			@Override
        			public void mouseEntered(MouseEvent e) { //le bouton devient rouge au survol
        				button.setBackground(Color.red);
        				
        			}
        			
        			@Override
        			public void mouseClicked(MouseEvent e) {
        				polyv2 plv2= new polyv2();           //instancier un objet de classe polyv2 au click
        				plv2.setVisible(true);               // afficher polyv2
        				
        				
        			}
        		});
            	
            }
        }
        
				
		
		JTabbedPane jtpa = new JTabbedPane(); 
		jtpa.add("1",pan); //pan dans le 1er onglet
		jtpa.add("2",pane); //pane dans le 2ème onglet
		
		frame.add(jtpa);
		
		frame.setVisible(true);
		
		

	}

}

