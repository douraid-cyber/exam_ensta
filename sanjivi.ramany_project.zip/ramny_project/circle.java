package ramny_project;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;

public class circle extends JFrame{
	private static int mouseX; //avec static, pas besoin de getter et setter
	private static int mouseY;
	
	public circle()
	{
		setSize(400, 200); //définition de la JFrame
		setUndecorated(true);
		setLayout(null); //null quand on part d'une feuille blanche
		
		addMouseMotionListener(new MouseAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) //la fenêtre suit la souris cliquée
			{
				int x=e.getXOnScreen()-mouseX; //pour que souris reste où elle est
				int y=e.getYOnScreen()-mouseY;
				setLocation(x,y);
			}
		});
		addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				mouseX=e.getX();
				mouseY=e.getY();
			}
		});
		JCheckBox jcb1=new JCheckBox("transparence"); //case à cocher pour la transparence
		jcb1.setBounds(190,75,20,20);
		//Ajout d'un ItemListener pour activer la transparence avec la checkbox
		jcb1.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (jcb1.isSelected()) {
                    setBackground(new Color(0, 0, 0, 0)); // La fenêtre devient transparente si la case est cochée
                } else {
                    setBackground(new Color(255, 255, 255)); // Sinon, la fenêtre a un fond blanc
                }
            }
        });
		
		add(jcb1);
		
		
		JButton butExit=new JButton("X");
		butExit.setBounds(150,75,20,20); //Positionnement du bouton de sortie
		butExit.setBackground(Color.red);
		//butExit.setBackground(new Color(255,0,0)); //autre alternative
		butExit.setBorderPainted(false); //suppression de gras au bord
		butExit.setFocusPainted(false); //suppression de la surbrillance quand la souris passe dessus
		butExit.setForeground(Color.white);
		butExit.setMargin(new Insets(0,0,0,0));
		butExit.addMouseListener(new MouseListener() { 
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				butExit.setBackground(Color.red);
				
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				butExit.setBackground(Color.DARK_GRAY);
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose(); // juste fermer la fenêtre
				
			}
		});
		
		add(butExit);	
	
	
	
	}
	
@Override
	
	public void paint(Graphics g)
	{
		super.paint(g);
		
		Graphics2D g2d=(Graphics2D) g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
		
		
		// Dessiner un cercle rempli avec un rayon de 100
        int centreX = 150; // Position X du centre du cercle
        int centreY = 100;  // Position Y du centre du cercle
        int rayon = 100;  // Rayon du cercle
        g2d.fillOval(centreX - rayon, centreY - rayon, 2 * rayon, 2 * rayon); // Dessin du cercle rempli
    
		
		
		}
		
		
		
		
		
	}
	


